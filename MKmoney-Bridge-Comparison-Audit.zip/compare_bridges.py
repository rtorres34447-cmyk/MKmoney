#!/usr/bin/env python3
"""Inspect—not mutate—assembled MKmoney and proven diagnostic widget sources."""
from pathlib import Path
import sys,zipfile,tempfile,hashlib,difflib,re,json
root=Path(sys.argv[1]); labzip=Path(sys.argv[2]); out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
if not labzip.is_file():raise SystemExit('Missing working Widget Lab archive: '+str(labzip))
with tempfile.TemporaryDirectory() as d:
    lab=Path(d)
    with zipfile.ZipFile(labzip) as z:z.extractall(lab)
    extensions={'.java','.kt','.xml','.html','.js'}
    def grab(source):
        return {str(p.relative_to(source)):p.read_text(errors='replace') for p in source.rglob('*') if p.is_file() and p.suffix.lower() in extensions and 'build/' not in str(p)}
    A=grab(root);B=grab(lab)
    tokens=['addJavascriptInterface','@JavascriptInterface','AppWidgetProvider','RemoteViews','onReceive','SharedPreferences','mkmoneySyncWidget','MKmoneyNativeSync','AndroidRecords','syncWidget','updateAppWidget']
    def scan(files):
        records=[]
        for name,content in files.items():
            found=[s for s in tokens if s.lower() in content.lower()]
            if found:
                lines=[f'{i}: {line.strip()[:220]}' for i,line in enumerate(content.splitlines(),1) if any(t.lower() in line.lower() for t in tokens)]
                records.append((name,found,lines[:100]))
        return records
    SA=scan(A);SB=scan(B)
    lines=['# MKmoney native-widget integration evidence','','## Summary',f'MKmoney source text files: {len(A)}',f'Working widget lab text files: {len(B)}',f'MKmoney files containing bridge/widget hooks: {len(SA)}',f'Lab files containing bridge/widget hooks: {len(SB)}','','This report does NOT claim that widget data delivery is working. It identifies concrete source paths and bridge entry points to reconcile.','','## MKmoney source evidence']
    for name,found,entries in SA:
        lines += [f'### {name}','Matched: '+', '.join(found),'```text',*entries,'```']
    lines+=['','## Proven lab source evidence']
    for name,found,entries in SB:
        lines += [f'### {name}','Matched: '+', '.join(found),'```text',*entries,'```']
    (out/'BRIDGE-COMPARISON.md').write_text('\n'.join(lines),encoding='utf-8')
    # Only source text of Lab, excludes binaries. This is sufficient to compare tested native code.
    with zipfile.ZipFile(out/'Working-Widget-Lab-Text-Source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for n,v in B.items():z.writestr(n,v)
    print('Wrote source evidence to',out)
    if not SA or not SB:raise SystemExit('No widget bridge evidence identified in one source; report uploaded for inspection')

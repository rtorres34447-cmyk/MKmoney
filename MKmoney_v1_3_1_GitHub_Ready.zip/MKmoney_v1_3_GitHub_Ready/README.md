# MKmoney v1.3.1 fix

- **Add Bill** form does not contain occurrence scope options.
- **Edit Bill** offers occurrence scope after Save Changes, not in the form.
- **Delete Bill** offers occurrence scope after choosing Delete.
- Bill recurrence can end on a selected date or continue indefinitely.
- Launcher icons generated for all Android densities, including round icons, and the manifest is patched during the workflow build.
- Header now displays the same app logo.

## Upload

Upload `MKmoney_v1_3_1_GitHub_Ready.zip` to the **root** of your GitHub repository (not inside a folder), replacing any file of the same name if necessary.
Copy `build-apk.yml` into `.github/workflows/build-apk.yml`, replacing the old workflow. Commit changes to trigger Actions.

The workflow uses existing `PayCycle_v1_2_Android_Source.zip` and the new ZIP. The existing Android package must support `app/src/main/assets/index.html`. A real Android build and device tests are still required.

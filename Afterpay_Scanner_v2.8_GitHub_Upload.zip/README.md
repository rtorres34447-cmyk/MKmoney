# Afterpay Screenshot Scanner v2.8

Upload the **contents** of this folder to the root of a GitHub repository (or extract the ZIP before uploading). Turn on **Settings → Pages → Deploy from branch → main / (root)** to publish the static web app. Open the Pages URL on your phone and use the browser menu **Add to Home screen** to use the included logo as the app icon.

## Files
- `index.html` — latest scanner with long-image tiling, date selection, correction review and date tabs
- `logo.svg` and `logo.png` — app logo
- `icons/icon-192.png`, `icons/icon-512.png` — home-screen app icons
- `manifest.webmanifest` — web app metadata

## Important notes
- OCR uses Tesseract.js **loaded via internet/CDN on first use** and may require connectivity if browser cache is cleared; this is not a fully self-contained offline OCR installation. Screenshots are processed in your browser.
- Payment records are stored via browser `localStorage` and may not transfer to a new origin/browser. Export **Save records (JSON)** from your old version, then import in the new version when needed.
- Inspect OCR totals against the original Afterpay screenshots.
- This ZIP contains a **web app / GitHub Pages project**, not an Android APK.

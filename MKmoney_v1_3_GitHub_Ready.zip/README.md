# MKmoney v1.3 — browser implementation and Android asset pack

## Included
- `index.html` – offline-friendly finance application.
- `assets/mk-money-icon.png` – app/site icon.
- `android-icons/` – Android legacy launcher density PNGs.

## Changes
- Repeat until: never (default) or inclusive end date.
- Weekly, fortnightly, monthly, quarterly, yearly, and one-off bills.
- Save Changes -> this occurrence / this and future; Delete -> same choices with confirmation.
- CSV export/import includes `end_date`; older CSV records without that column continue indefinitely.
- CSV fallback with copyable contents if downloading fails in WebView.

## Web testing
Open `index.html` in a browser. Records are stored with localStorage in that browser profile. Back up using Settings > Export CSV.

## Android build note
This ZIP is **not an APK**. Integrate `index.html` in the existing Android WebView assets, integrate the icons into the Android app's resources, and build with your existing GitHub Actions/Gradle setup. The WebView JavaScript interface `AndroidRecords.exportCsv(csv,filename)` must use the Android Storage Access Framework `ACTION_CREATE_DOCUMENT` to show the Save As picker and persist the file; a browser-only HTML file cannot guarantee a native Android folder picker. Reinstalling a differently signed app may remove its stored records.

## Publish
1. Upload the unpacked folder to your GitHub repository (GitHub's Add file > Upload files), or use git commit/push with a credentials-enabled machine.
2. Integrate changed web and icon assets into your Android source ZIP/project.
3. Run your GitHub Android build workflow to generate an APK.

Status: JavaScript syntax checked; functional Android tests and APK build not performed. GitHub write connection returned 403, so nothing has been pushed from this chat.

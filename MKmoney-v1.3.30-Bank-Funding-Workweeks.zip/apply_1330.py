from pathlib import Path
import sys,re
root=Path(sys.argv[1]);p=root/'app/src/main/assets/index.html'
if not p.is_file():raise SystemExit('Missing index.html')
s=p.read_text(encoding='utf-8')
if 'MKmoney v1.3.30' in s:raise SystemExit('v1.3.30 already applied')
script=Path(__file__).with_name('dashboard_1330.js').read_text(encoding='utf-8')
if not re.search(r'</body\s*>',s,re.I):raise SystemExit('Closing body tag missing')
s,n=re.subn(r'</body\s*>',lambda m:'<script>\n'+script+'\n</script>\n'+m.group(0),s,count=1,flags=re.I)
assert n==1
p.write_text(s,encoding='utf-8')
print('Added Friday/Sunday funding and collapsible workweeks without changing Java or CSV import code')

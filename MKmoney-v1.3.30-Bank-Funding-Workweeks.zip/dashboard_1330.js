/* MKmoney v1.3.30 – non-invasive bank funding and weekly folding */
(()=>{
'use strict';
if(window.__mk1330)return; window.__mk1330=true;
const css=document.createElement('style');css.textContent=`
#mk1330Funding{border:1px solid #45536a;border-radius:14px;margin:12px 0;padding:12px;background:#151e2c;color:#f2f6ff;font:14px system-ui,sans-serif}
#mk1330Funding h3{font-size:16px;margin:0 0 8px}#mk1330Funding .mkGrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
#mk1330Funding .mkCell{padding:10px;background:#233044;border-radius:10px;min-width:0}
#mk1330Funding .mkCell strong{display:block;overflow-wrap:anywhere}#mk1330Funding .mkAmount{font-size:20px;font-weight:750}
#mk1330Funding small{opacity:.78}#mk1330Funding .mkNote{font-size:12px;opacity:.85;margin-top:9px}
.mk1330WeekToggle{font:inherit;padding:5px 10px;margin-left:8px;border:1px solid #8392aa;border-radius:8px;background:transparent;color:inherit}
`;document.head.appendChild(css);
const money=n=>new Intl.NumberFormat('en-AU',{style:'currency',currency:'AUD'}).format(n);
const dateISO=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
const readDate=x=>{if(!x)return null;let d=x instanceof Date?x:new Date(String(x).length===10?String(x)+'T12:00:00':x);return isNaN(+d)?null:d};
const add=(d,n)=>new Date(d.getFullYear(),d.getMonth(),d.getDate()+n,12);
const dates=()=>{let t=new Date(),d=new Date(t.getFullYear(),t.getMonth(),t.getDate(),12),day=d.getDay();let fri=add(d,(5-day+7)%7),sun=add(d,(7-day)%7);return {today:d,fri,sun}};
function stateCandidates(){let a=[];for(let key of ['state','data','appData','store','model','db']){try{let v=window[key]||eval('typeof '+key+'!=="undefined"?'+key+':undefined');if(v&&typeof v==='object')a.push(v)}catch(e){}}
for(let k of ['mkmoney','MKmoney','mkmoney_data','mkMoneyData','paycycle_data']){try{let v=JSON.parse(localStorage.getItem(k)||'null');if(v&&typeof v==='object')a.push(v)}catch(e){}}
for(let i=0;i<localStorage.length;i++){let key=localStorage.key(i);if(!/money|paycycle|bill|bank/i.test(key))continue;try{let v=JSON.parse(localStorage.getItem(key));if(v&&typeof v==='object')a.push(v)}catch(e){}}
return a;}
function getBanks(){let names=['Bank 1','Bank 2'];for(let s of stateCandidates()){
let candidates=[s.bankNames,s.banks,s.settings?.bankNames,s.settings?.banks,s.config?.bankNames];
for(let b of candidates){if(Array.isArray(b)){for(let i=0;i<2;i++){let x=b[i];let n=typeof x==='string'?x:x&&(x.customName||x.name||x.label);if(n&&String(n).trim())names[i]=String(n).trim()}}
else if(b&&typeof b==='object')for(let i=0;i<2;i++){let x=b['bank'+(i+1)]??b['bank_'+(i+1)]??b[i+1]??b[i];let n=typeof x==='string'?x:x&&(x.customName||x.name||x.label);if(n&&String(n).trim())names[i]=String(n).trim()}}
for(let i=0;i<2;i++){let n=s['bank'+(i+1)+'Name']??s.settings?.['bank'+(i+1)+'Name'];if(n&&String(n).trim())names[i]=String(n).trim()}}
for(let i=0;i<2;i++){let n=localStorage.getItem('bank'+(i+1)+'Name')||localStorage.getItem('mkmoney_bank'+(i+1)+'_name');if(n)names[i]=n}
return names;}
function getBills(){for(let s of stateCandidates()){let lists=[s.bills,s.entries,s.records,s.transactions,s.data?.bills,s.data?.entries];for(let list of lists)if(Array.isArray(list)&&list.length&&list.some(x=>x&&typeof x==='object'&&('amount' in x||'cost' in x||'value' in x)))return list; if(Array.isArray(s)&&s.length&&s.some(x=>x&&typeof x==='object'&&'amount'in x))return s}return null}
function bankIndex(b,names){let bstr=String(b??'').trim().toLowerCase();if(['1','bank 1','bank1','bank_1'].includes(bstr)||bstr===names[0].toLowerCase())return 0;if(['2','bank 2','bank2','bank_2'].includes(bstr)||bstr===names[1].toLowerCase())return 1;return -1}
function occurrences(b,from,to){let first=readDate(b.due??b.dueDate??b.date??b.nextDue??b.startDate);if(!first)return [];
let stop=readDate(b.until??b.endDate);let every=String(b.repeat??b.frequency??b.interval??b.recurrence??'once').toLowerCase();let count=0;let ds=[];
for(let d=first;d<=to&&count<1500;count++){
if(d>=from&&(!stop||d<=stop))ds.push(d);
if(stop&&d>=stop)break;
if(/fortnight|biweekly|2.week/.test(every))d=add(d,14);
else if(/weekly|every.week/.test(every))d=add(d,7);
else if(/quarter|3.month/.test(every)){let day=d.getDate(),n=new Date(d.getFullYear(),d.getMonth()+3,1,12);d=new Date(n.getFullYear(),n.getMonth(),Math.min(day,new Date(n.getFullYear(),n.getMonth()+1,0).getDate()),12)}
else if(/month/.test(every)){let day=d.getDate(),n=new Date(d.getFullYear(),d.getMonth()+1,1,12);d=new Date(n.getFullYear(),n.getMonth(),Math.min(day,new Date(n.getFullYear(),n.getMonth()+1,0).getDate()),12)}
else break;
}return ds}
function renderFunding(){let days=dates(),names=getBanks(),bills=getBills();let holder=document.getElementById('mk1330Funding');if(!holder){holder=document.createElement('section');holder.id='mk1330Funding';let dashboard=document.querySelector('[id*=dashboard i],[class*=dashboard i],main')||document.body;dashboard.insertBefore(holder,dashboard.firstChild)}
let friday=[0,0],sunday=[0,0],missing=0; if(bills){for(let b of bills){if(b.paid===true||b.archived===true||b.isArchived===true||b.status==='archived')continue;let idx=bankIndex(b.bank??b.bankId??b.sourceBank??b.bankSource??b.account,names);if(idx<0){missing++;continue}let amount=Number(String(b.amount??b.cost??b.value??0).replace(/[$,]/g,''));if(!Number.isFinite(amount)||amount<0)continue;for(let when of occurrences(b,days.today,days.sun)){if(when<=days.fri)friday[idx]+=amount;else sunday[idx]+=amount;}}}
const fmtDate=d=>d.toLocaleDateString('en-AU',{weekday:'long',day:'numeric',month:'short'});
holder.innerHTML='<h3>Required bank funding</h3><div class="mkGrid">'+names.map((n,i)=>'<div class="mkCell"><strong>'+escapeHtml(n)+'</strong><small>By '+fmtDate(days.fri)+'</small><div class="mkAmount">'+(bills?money(friday[i]):'—')+'</div><small>After Friday, by '+fmtDate(days.sun)+'</small><div class="mkAmount">'+(bills?money(sunday[i]):'—')+'</div></div>').join('')+'</div><div class="mkNote">'+(bills?'Bills due from today, separated into Friday and weekend funding. These are required bill amounts, not bank balances.':'Bill data was not located; amounts are hidden rather than guessed.')+(missing?' '+missing+' entries have no recognised bank allocation.':'')+' Automatically refreshes after midnight.</div>';
// Update only labels in existing bank summary nodes (do not replace text inside editable inputs).
for(let el of document.querySelectorAll('[data-bank-label],.bank-label,.bankNameLabel')){if(el.closest('#mk1330Funding')||el.matches('input,textarea'))continue;let txt=el.textContent.trim();if(/^Bank\s*[12]$/i.test(txt)){let i=/2/.test(txt)?1:0;el.textContent=names[i]}}
}
function escapeHtml(t){return String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function collapseWeeks(){let d=dates().today;let wMon=add(d,-((d.getDay()+6)%7));let wEnd=add(wMon,6);let headings=[...document.querySelectorAll('h2,h3,h4,.week-header,[class*=weekTitle],[class*=week-title]')];
for(let h of headings){if(h.closest('#mk1330Funding')||h.dataset.mk1330Processed)continue;let label=h.textContent.trim();if(!/work\s*week|weekend|week\s*\d|\bmon\b.*\bfri\b/i.test(label))continue;let parent=h.parentElement;if(!parent||parent.children.length<2)continue;
let datesIn=(label.match(/\d{4}-\d{2}-\d{2}/g)||[]).map(readDate).filter(Boolean);let current=datesIn.some(x=>x>=wMon&&x<=wEnd);
// Preserve state within this session; default to collapsed only for clearly non-current dated headings.
let content=[...parent.children].filter(n=>n!==h&&!n.contains(h));if(!content.length)continue;let btn=document.createElement('button');btn.type='button';btn.className='mk1330WeekToggle';let open=current||datesIn.length===0;
function update(){btn.textContent=open?'Minimise':'Expand';btn.setAttribute('aria-expanded',String(open));for(let n of content)n.hidden=!open}
btn.addEventListener('click',()=>{open=!open;update()});h.appendChild(btn);h.dataset.mk1330Processed='1';update();}}
let lastDay='';function tick(){let today=dateISO(new Date());if(lastDay!==today){lastDay=today;renderFunding()}collapseWeeks()}
const ready=()=>{tick();setInterval(tick,60000);document.addEventListener('change',()=>setTimeout(renderFunding,100));document.addEventListener('click',()=>setTimeout(tick,200));};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
})();
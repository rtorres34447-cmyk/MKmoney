#!/usr/bin/env python3
"""Conservative MKmoney v2.0 bridge integration; refuses unknown main activity shape."""
from pathlib import Path
import re, shutil, xml.etree.ElementTree as ET
import sys
root=Path(sys.argv[1]).resolve(); src=Path(__file__).resolve().parent
if not (root/'app/src/main/AndroidManifest.xml').exists(): raise RuntimeError('Missing assembled v1.3.47 Android source')
main=root/'app/src/main'
java=list((main/'java').rglob('MainActivity.java'))
if len(java)!=1: raise RuntimeError('Expected exactly one MKmoney MainActivity.java; found '+str(len(java)))
activity=java[0]
body=activity.read_text()
package=re.search(r'package\s+([\w.]+)\s*;',body)
if not package: raise RuntimeError('Cannot determine MKmoney Java package')
package=package.group(1)
# Inject exactly at the existing WebView enable JavaScript expression; variable inferred from line
hit=re.search(r'\b([A-Za-z_$][\w$]*)\.getSettings\(\)\.setJavaScriptEnabled\(true\)\s*;',body)
if not hit: raise RuntimeError('MKmoney WebView initialization not recognized; refusing to change the app')
var=hit.group(1)
body=body[:hit.end()] + '\n        '+var+'.addJavascriptInterface(new MKCalendarBridge(this), "MKCalendarBridge");\n' + body[hit.end():]
if 'MKCalendarBridge(this)' in activity.read_text(): raise RuntimeError('Calendar add-on already integrated')
activity.write_text(body)
out=activity.parent
for source,target in [('LabStore.java','MKCalendarStore.java'),('LabWidget.java','MKCalendarWidget.java')]:
 t=(src/source).read_text()
 t=t.replace('package com.mk.widgetlab;',f'package {package};').replace('LabStore','MKCalendarStore').replace('LabWidget','MKCalendarWidget')
 t=t.replace('R.layout.widget','R.layout.mk_calendar_widget').replace('calendar_lab_v2','mkmoney_widget_v2')
 # Keep distinct broadcast action to avoid collision
 t=t.replace('com.mk.widgetlab.ACTION_WIDGET', package+'.CALENDAR_ACTION_WIDGET')
 (out/target).write_text(t)
bridge=(src/'MKCalendarBridge.java').read_text().replace('package com.mkmoney.app;',f'package {package};')
(out/'MKCalendarBridge.java').write_text(bridge)
for directory,filename,newfilename in [('layout','widget.xml','mk_calendar_widget.xml'),('xml','widget_info.xml','mk_calendar_widget_info.xml')]:
 dest=main/'res'/directory;dest.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(src/filename,dest/newfilename)
# Preserve lab widget background under a distinct name.
(main/'res/drawable').mkdir(parents=True,exist_ok=True)
shutil.copyfile(src/'bg.xml',main/'res/drawable/mk_calendar_bg.xml')
widget_layout=main/'res/layout/mk_calendar_widget.xml'
widget_layout.write_text(widget_layout.read_text().replace('@drawable/bg','@drawable/mk_calendar_bg'))
provider=main/'res/xml/mk_calendar_widget_info.xml'
provider.write_text(provider.read_text().replace('@layout/widget','@layout/mk_calendar_widget'))
# The XML is from the tested Widget Lab v2.1, preserving sizing and date-tap behavior.
manifest=main/'AndroidManifest.xml'
mt=manifest.read_text()
if '<application' not in mt:raise RuntimeError('Android manifest has no application')
if 'MKCalendarWidget' in mt: raise RuntimeError('MKmoney v2 widget already registered')
receiver='''\n        <receiver android:name=".MKCalendarWidget" android:exported="true">\n            <intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="' + package + '.CALENDAR_ACTION_WIDGET"/></intent-filter>\n            <meta-data android:name="android.appwidget.provider" android:resource="@xml/mk_calendar_widget_info"/>\n        </receiver>\n'''
# Ensure package-qualified receiver (works even if activity package differs from manifest namespace)
receiver=receiver.replace('android:name=".MKCalendarWidget"','android:name="'+package+'.MKCalendarWidget"')
receiver=receiver.replace("' + package + '", package)
mt=mt.replace('</application>',receiver+'</application>')
manifest.write_text(mt)
# Inject bridge-specific adapter, leaving existing app HTML untouched.
htmls=list((main/'assets').glob('*.html'))
index=main/'assets/index.html'
if not index.exists(): raise RuntimeError('MKmoney index.html not found; refusing to overwrite assets')
s=index.read_text()
if '</body>' not in s:raise RuntimeError('Expected index.html with </body>')
s=s.replace('</body>','<script>'+ (src/'widget-adapter.js').read_text()+'</script>\n</body>')
index.write_text(s)
# Increase version without changing package name (preserve existing app data)
gradle=root/'app/build.gradle'
g=gradle.read_text()
g=re.sub(r'versionName\s+["\'][^"\']+["\']','versionName "2.0"',g,count=1)
g=re.sub(r'versionCode\s+(\d+)',lambda m:'versionCode '+str(max(200,int(m.group(1))+1)),g,count=1)
gradle.write_text(g)
print('Added v2.0 widget to verified MKmoney v1.3.47 source:', activity, 'package:', package)

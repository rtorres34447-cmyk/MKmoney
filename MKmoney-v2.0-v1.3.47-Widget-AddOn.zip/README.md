# MKmoney v2.0 ADD-ON to assembled v1.3.47

This is **not** a replacement finance dashboard. It assembles the exact v1.3.47 patch chain from successful GitHub build #65, then injects Widget Lab v2.1 as a new Android calendar widget.

## Key cautions
- The existing native calendar widget remains installed as well; select **MKmoney v2 calendar** after build. The old widget is not removed, avoiding breaking the original.
- The payment adapter currently scans saved JSON data and may not understand all recurrence rules or MKmoney's internal schema. It does NOT modify the application's saved bills.
- This APK must be validated on a separate/test install or with an export backup because signing compatibility and existing data persistence aren't verified.
- This source is structurally checked but has **not** been compiled here. GitHub Actions compilation is the authoritative check.
- Require a screenshot of dashboard and widget, showing payments, before considering the release complete.

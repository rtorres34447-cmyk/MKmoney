# MKmoney v2.0 Integration Kit

Integration **patch** for existing MKmoney Android source, not a standalone source archive. Designed to preserve MKmoney's package and existing HTML. Reuses proven Widget Lab v2.1 calendar provider and adds a `MKCalendarBridge` JavaScript interface.

Important limitation: automatic payment extraction recognises persisted records with conventional `date` / `dueDate` and `amount` / `name` fields. It does not yet expand all recurring entries; the dashboard data schema must be verified and a canonical exporter written to guarantee full accuracy. The action stops before compiling if base project structure is unexpected.

Run `python3 kit/integrate.py` with the original MKmoney source extracted in `project/`. Build `project/` with Gradle. The accompanying workflow fetches the publicly committed 1.3.19 full source archive from the MKmoney repository, so later source patches are not included. Avoid installing the build over a newer MKmoney app without first backing up/exporting data.

from pathlib import Path
import sys,re
root=Path(sys.argv[1]); base=Path(sys.argv[2]);
assert (root/'app/src/main/assets/index.html').is_file(), 'Missing base index.html'
assert (root/'app/src/main/AndroidManifest.xml').is_file(), 'Missing AndroidManifest.xml'
java=list((root/'app/src/main/java').rglob('MainActivity.java'))
original=list((base/'app/src/main/java').rglob('MainActivity.java'))
assert len(java)==1 and len(original)==1, 'Unexpected MainActivity files'
assert java[0].read_bytes()==original[0].read_bytes(), 'Native Java changed; CSV import must remain untouched'
html=(root/'app/src/main/assets/index.html').read_text()
assert '<html' in html.lower(), 'Invalid HTML'
print('Verified: original v1.3.10 native Java retained; app HTML present')

MKmoney v1.3.27 clean v1.3.10 rebuild

Upload this ZIP alongside the separate blank.yml into the MKmoney repo root.
The workflow uses the EXISTING v1.3.8 logo-restored Android project, v1.3.10 Today/Workweek HTML, and earlier feature update ZIPs v1.3.14, v1.3.15 and v1.3.16. It does NOT apply v1.3.21-v1.3.26 Java/CSV patches.

The build fails explicitly if any feature patch is incompatible. An APK build and functional device test are not yet verified.

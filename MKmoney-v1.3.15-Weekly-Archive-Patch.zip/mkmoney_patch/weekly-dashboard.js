
/* MKmoney weekly dashboard: Monday-Sunday calendar weeks, payday cut-off, archive by elapsed dates.
 No bills are deleted. */
(()=>{
const key='mkmoney.weekly.archive.visible';
const msDay=86400000;
const day=(v)=>{if(!v)return null;const m=String(v).match(/^(\d{4})-(\d\d)-(\d\d)/);if(m)return new Date(+m[1],+m[2]-1,+m[3]);const d=new Date(v);return isNaN(+d)?null:new Date(d.getFullYear(),d.getMonth(),d.getDate())};
const iso=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const plus=(d,n)=>new Date(d.getFullYear(),d.getMonth(),d.getDate()+n);
const monday=d=>plus(d,-((d.getDay()+6)%7));
const money=v=>'$'+v.toLocaleString('en-AU',{minimumFractionDigits:2,maximumFractionDigits:2});
const frequency=(b)=>String(b.interval??b.repeat??b.frequency??b.recurrence??'').toLowerCase();
const due=(b,d)=>{
 const start=day(b.due??b.dueDate??b.date??b.nextDue??b.startDate??b.start);if(!start||d<start)return false;
 const end=day(b.until??b.endDate??b.repeatUntil);if(end&&d>end)return false;
 const days=Math.round((Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())-Date.UTC(start.getFullYear(),start.getMonth(),start.getDate()))/msDay);
 const f=frequency(b);
 if(/fortnight|biweek|2.week|14.day/.test(f))return days%14===0;
 if(/weekly|week|7.day/.test(f))return days%7===0;
 if(/quarter|month|annual|year/.test(f)){
  const step=/quarter/.test(f)?3:/annual|year/.test(f)?12:1;
  for(let n=0;n<=240;n+=step){const x=new Date(start.getFullYear(),start.getMonth()+n,1);
    x.setDate(Math.min(start.getDate(),new Date(x.getFullYear(),x.getMonth()+1,0).getDate()));
    if(+x===+d)return true;if(x>d)break;}return false;
 }
 return days===0;
};
const collect=(o,out,dep=0)=>{
 if(!o||typeof o!=='object'||dep>9)return;
 if(Array.isArray(o)){o.forEach(x=>collect(x,out,dep+1));return}
 if((o.amount!==undefined||o.cost!==undefined||o.value!==undefined)&&(o.due!==undefined||o.dueDate!==undefined||o.nextDue!==undefined||o.date!==undefined)){out.push(o);return}
 Object.entries(o).forEach(([k,v])=>{if(!/backup|history|archive/i.test(k))collect(v,out,dep+1)})
};
const read=()=>{
 const data=[];const configs=[];
 for(let i=0;i<localStorage.length;i++){
   const k=localStorage.key(i);if(!k||k===key||/^mk_bill_reminder/i.test(k))continue;
   try{const o=JSON.parse(localStorage.getItem(k));collect(o,data);configs.push(o)}catch(e){}
 }
 return {data,configs};
};
const findPay=(configs,today)=>{
 const values=[];
 const inspect=(o,level=0)=>{
  if(!o||typeof o!=='object'||level>3)return;
  for(const [k,v] of Object.entries(o)){
   if(/pay(?:day|date)|nextpay/i.test(k)&&typeof v==='string'){const d=day(v);if(d)values.push(d)}
   else if(v&&typeof v==='object')inspect(v,level+1);
  }
 };configs.forEach(x=>inspect(x));
 // Use user-configured pay date only. Never invent a payment schedule.
 const future=values.filter(x=>x>=today).sort((a,b)=>a-b);
 return future[0]||null;
};
function totals(bills,start,end){
 const t={bank1:0,bank2:0,other:0};const names=[];
 for(let d=new Date(start);d<=end;d=plus(d,1)){
  for(const b of bills){if(b.paid===true||b.deleted===true||b.active===false||!due(b,d))continue;
   const a=Number(b.amount??b.cost??b.value);if(!Number.isFinite(a)||a<=0)continue;
   const bank=String(b.bank??b.bankName??b.sourceBank??b.bankAccount??b.account??b.fromBank??b.paymentBank??'').toLowerCase().replace(/\s+/g,'');
   const k=/^(?:bank)?1$/.test(bank)?'bank1':/^(?:bank)?2$/.test(bank)?'bank2':'other';
   t[k]+=a;names.push({name:String(b.name??b.title??b.merchant??'Bill'),amount:a,bank:k,date:iso(d)});
  }
 }
 return {t,names};
}
const styles=`#mkmoney-weekview{border:1px solid #62739a;border-radius:14px;padding:15px;margin:16px 8px;background:#101b30;color:#eff4ff;font:14px system-ui,sans-serif}#mkmoney-weekview h3{margin:0 0 10px;font-size:17px}#mkmoney-weekview .week{border-top:1px solid #334563;padding:12px 0}#mkmoney-weekview .banks{display:flex;gap:12px;margin:8px 0}#mkmoney-weekview .banks>span{flex:1;padding:9px;border-radius:8px;background:#263754}#mkmoney-weekview small{color:#aabbdb}#mkmoney-weekview button{padding:7px 10px;color:#fff;background:#344c72;border:0;border-radius:7px}#mkmoney-weekview details{margin-top:10px}#mkmoney-weekview .archive{opacity:.65}`;
const mount=()=>{
 if(!document.getElementById('mkmoney-weekview-style')){const s=document.createElement('style');s.id='mkmoney-weekview-style';s.textContent=styles;document.head.append(s)}
 let el=document.getElementById('mkmoney-weekview');
 if(!el){el=document.createElement('section');el.id='mkmoney-weekview';const target=document.querySelector('#dashboard')||document.querySelector('[data-tab="dashboard"]')||document.querySelector('main')||document.body;target.prepend(el)}
 const now=new Date(),today=new Date(now.getFullYear(),now.getMonth(),now.getDate()),begin=monday(today),sunday=plus(begin,6);
 const {data,configs}=read(),pay=findPay(configs,today);
 const current=totals(data,begin,sunday);
 const archived=[],upcoming=[];
 // Calendar weeks are archived once their Sunday has passed.
 if(pay){for(let d=begin;d<=pay;d=plus(d,7)){const end=plus(d,6);upcoming.push({start:d,end,summary:totals(data,d,end< pay?end:pay)});if(upcoming.length>70)break;}}
 // 12 historical weeks, folded by default (read-only archive).
 for(let n=12;n>=1;n--){const d=plus(begin,-n*7);archived.push({start:d,end:plus(d,6),summary:totals(data,d,plus(d,6))})}
 const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const bankRow=r=>`<div class="banks"><span>Bank 1<br><strong>${money(r.t.bank1)}</strong></span><span>Bank 2<br><strong>${money(r.t.bank2)}</strong></span></div>${r.t.other?`<small>Unassigned bank: ${money(r.t.other)}</small>`:''}`;
 const detail=r=>r.names.length?`<details><summary>Bill details (${r.names.length})</summary>${r.names.map(x=>`<div><small>${esc(x.date)} · ${esc(x.name)} · ${esc(x.bank)}</small> ${money(x.amount)}</div>`).join('')}</details>`:'<small>No bills due in this week</small>';
 const range=x=>`${iso(x.start)} – ${iso(x.end)}`;
 el.innerHTML=`<h3>Current week · Mon–Sun</h3><small>${iso(begin)} to ${iso(sunday)} · bank funding required this week</small>${bankRow(current)}${detail(current)}
 <h3>Remaining weeks before payday</h3>${pay?upcoming.map((x,i)=>`<div class="week"><strong>${i===0?'This week':`Week ${i+1}`} · ${range(x)}</strong>${i===0?'<small>Current week totals above</small>':bankRow(x.summary)+detail(x.summary)}</div>`).join(''):`<p>Set your next payday in MKmoney to see the remaining weeks. No payday has been assumed.</p>`}
 <details id="mkmoney-archive"><summary>Archived completed weeks (${archived.length} shown)</summary>${archived.map(x=>`<div class="week archive"><strong>${range(x)}</strong>${bankRow(x.summary)}${detail(x.summary)}</div>`).join('')}</details>`;
};
const start=()=>{mount();document.addEventListener('visibilitychange',()=>{if(!document.hidden)mount()});setInterval(mount,60000)};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();

from pathlib import Path
import re,sys,xml.etree.ElementTree as ET
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
app=root/'app/src/main'
assets=app/'assets'; manifest=app/'AndroidManifest.xml'
assert (assets/'index.html').exists() and manifest.exists(), 'Missing existing MKmoney Android project'
html=(assets/'index.html').read_text(encoding='utf-8')
assert 'dashboardToday' in html, 'This patch requires the MKmoney v1.3.10 Today/Workweek update applied first'
js=(Path(__file__).parent/'reminder.js').read_text()
weekly=(Path(__file__).parent/'weekly-dashboard.js').read_text()
marker='<!-- MKMONEY-8PM-BILLS-REMINDER -->'
weekmarker='<!-- MKMONEY-WEEKLY-ARCHIVE -->'
if weekmarker not in html:
    html=html.replace('</body>',weekmarker+'\n<script>'+weekly+'</script>\n</body>')
if marker not in html:
    html=html.replace('</body>',marker+'\n<script>'+js+'</script>\n</body>')
    (assets/'index.html').write_text(html,encoding='utf-8')
(assets/'index.html').write_text(html,encoding='utf-8')
NS='{http://schemas.android.com/apk/res/android}'
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
tree=ET.parse(manifest); doc=tree.getroot(); appnode=doc.find('application'); assert appnode is not None

# Install a real, bundled MKmoney launcher icon (including the Android notification fallback).
icon=Path(__file__).parent/'mkmoney_launcher.png'
assert icon.is_file() and icon.stat().st_size>10000, 'Bundled launcher PNG missing'
res=app/'res'/'drawable-nodpi';res.mkdir(parents=True,exist_ok=True)
import shutil
shutil.copyfile(icon,res/'mkmoney_launcher.png')
appnode.set(NS+'icon','@drawable/mkmoney_launcher')
appnode.set(NS+'roundIcon','@drawable/mkmoney_launcher')

for p in ['android.permission.POST_NOTIFICATIONS','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.SCHEDULE_EXACT_ALARM']:
    if not any(x.get(NS+'name')==p for x in doc.findall('uses-permission')):
        ET.SubElement(doc,'uses-permission',{NS+'name':p})
# Find WebView loadUrl site and inject bridge immediately ahead of it
sources=list((app/'java').rglob('*.java')) if (app/'java').exists() else []
chosen=None
for src in sources:
    s=src.read_text(encoding='utf-8')
    if 'WebView' in s and ('loadUrl(' in s or 'loadDataWithBaseURL(' in s):
        chosen=(src,s);break
assert chosen, 'Could not find Java WebView Activity. Existing source is left unchanged: custom integration needed.'
src,s=chosen
pkg=re.search(r'package\s+([\w.]+)\s*;',s);assert pkg
package=pkg.group(1)
match=re.search(r'(\b(\w+)\.loadUrl\s*\(|\b(\w+)\.loadDataWithBaseURL\s*\()',s)
assert match,'No WebView loading call found'
webvar=match.group(2) or match.group(3)
bridgecode=f'{webvar}.addJavascriptInterface(new MKBillReminderBridge(this), "MKBillReminder");\n        '
if 'new MKBillReminderBridge(this)' not in s:
    s=s[:match.start()]+bridgecode+s[match.start():]
    src.write_text(s,encoding='utf-8')
java_dir=src.parent
(java_dir/'MKBillReminderBridge.java').write_text((Path(__file__).parent/'MKBillReminderBridge.java.txt').read_text().replace('PACKAGE_NAME',package),encoding='utf-8')
(java_dir/'MKBillReminderReceiver.java').write_text((Path(__file__).parent/'MKBillReminderReceiver.java.txt').read_text().replace('PACKAGE_NAME',package),encoding='utf-8')
for cls in ['MKBillReminderReceiver']:
    if not any(x.get(NS+'name') in ['.'+cls,package+'.'+cls] for x in appnode.findall('receiver')):
        ET.SubElement(appnode,'receiver',{NS+'name':'.'+cls,NS+'exported':'false'})
# separate exported boot receiver for OS broadcasts
if not any(x.get(NS+'name')=='.MKReminderBootReceiver' for x in appnode.findall('receiver')):
    b=ET.SubElement(appnode,'receiver',{NS+'name':'.MKReminderBootReceiver',NS+'exported':'true'})
    f=ET.SubElement(b,'intent-filter')
    for act in ['android.intent.action.BOOT_COMPLETED','android.intent.action.MY_PACKAGE_REPLACED']:
        ET.SubElement(f,'action',{NS+'name':act})
(java_dir/'MKReminderBootReceiver.java').write_text((Path(__file__).parent/'MKReminderBootReceiver.java.txt').read_text().replace('PACKAGE_NAME',package),encoding='utf-8')
tree.write(manifest,encoding='utf-8',xml_declaration=True)
print('MKmoney patch complete: 8PM native alarms, bill amount notifications, icon resources preserved; package='+package)

from pathlib import Path
import shutil, sys, re

if len(sys.argv)!=3:
    raise SystemExit('Usage: restore_logo.py NEW_PROJECT ORIGINAL_LOGO_PROJECT')
project=Path(sys.argv[1]).resolve()
original=Path(sys.argv[2]).resolve()
res=project/'app/src/main/res'
old_res=original/'app/src/main/res'
manifest=project/'app/src/main/AndroidManifest.xml'
if not manifest.exists() or not old_res.exists():
    raise SystemExit('Android project or previous logo resources are missing')

# Preserve every original icon asset, including any adaptive launcher XML and foreground layers.
matched=[]
for p in old_res.rglob('*'):
    if p.is_file() and (p.parent.name.startswith('mipmap') or any(w in p.stem.lower() for w in ['ic_launcher','logo','ic_foreground','ic_background'])):
        target=res/p.relative_to(old_res)
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(p,target)
        matched.append(target)
if not matched:
    raise SystemExit('Original logo source has no launcher/mipmap image resources; refusing to build a logo-less APK')

# Prefer the original launcher icon resource if it exists; do not silently use Android default.
names={p.stem for p in matched}
launcher='ic_launcher' if 'ic_launcher' in names else None
if launcher is None:
    candidates=[x for x in ['logo','app_logo','mkmoney_logo'] if x in names]
    launcher=candidates[0] if candidates else None
if launcher is None:
    raise SystemExit('No identifiable original launcher image among copied resources')

xml=manifest.read_text(encoding='utf-8')
if '<application' not in xml:
    raise SystemExit('Missing <application> in Android manifest')
resource_type='mipmap' if any(p.parent.name.startswith('mipmap') and p.stem==launcher for p in matched) else 'drawable'
ref=f'@{resource_type}/{launcher}'
head=re.search(r'<application\b[^>]*>',xml,re.S)
if not head:raise SystemExit('Cannot find application opening element')
tag=head.group(0)
if re.search(r'android:icon\s*=',tag):
    tag=re.sub(r'android:icon\s*=\s*["\'][^"\']+["\']',f'android:icon="{ref}"',tag)
else:tag=tag[:-1]+f' android:icon="{ref}">'
if 'android:roundIcon=' in tag:
    tag=re.sub(r'android:roundIcon\s*=\s*["\'][^"\']+["\']',f'android:roundIcon="{ref}"',tag)
xml=xml[:head.start()]+tag+xml[head.end():]
manifest.write_text(xml,encoding='utf-8')
print('Logo restored:',ref,'files:',len(matched))
for p in matched: print('  ',p.relative_to(project))

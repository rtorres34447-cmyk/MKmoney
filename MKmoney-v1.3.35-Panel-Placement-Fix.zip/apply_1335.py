from pathlib import Path
import sys,re
root=Path(sys.argv[1]); html=root/'app/src/main/assets/index.html'
s=html.read_text(encoding='utf-8')
# Remove v1.3.33 script, which incorrectly picked up mk1330Funding too.
pattern=r'<script>\s*/\* MKmoney v1\.3\.33: move current-week bank funding out of Dashboard and into Settings\. \*/.*?</script>\s*'
s,n=re.subn(pattern,'',s,count=1,flags=re.S)
if n!=1:raise SystemExit('Expected v1.3.33 mover script not found; refusing ambiguous patch')
js=Path(__file__).with_name('move_only_current_week.js').read_text(encoding='utf-8')
s=re.sub('</body>',lambda m:'<script>\n'+js+'\n</script>\n'+m.group(),s,count=1,flags=re.I)
html.write_text(s,encoding='utf-8')
assert '/* MKmoney v1.3.33:' not in s
assert 'mk1330Funding' not in js
print('Preserved Required bank funding on Dashboard; only Current week Mon-Sun moved to Settings')

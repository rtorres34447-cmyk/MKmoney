/* MKmoney v1.3.35: move ONLY Current week Mon-Sun panel to Settings. */
(()=>{'use strict';if(window.__mk1335)return;window.__mk1335=true;
const name=/^Current week\s*[·•:-]\s*Mon\s*[–-]\s*Sun/i;
const text=e=>(e.textContent||'').replace(/\s+/g,' ').trim();
const rootSelectors=['#settings','#settingsTab','#tab-settings','#panel-settings','#settingsPanel','[data-page="settings"]','[data-tab="settings"]','.settings-page','.settings-panel'];
let parked=null, current=null, busy=false;
function settingsRoot(){for(const sel of rootSelectors){let e=document.querySelector(sel);if(e&&!e.matches('button,a,[role="tab"]'))return e;}return null}
function selected(){const root=settingsRoot();if(root&&root.getClientRects().length&&getComputedStyle(root).visibility!=='hidden')return true;
 return [...document.querySelectorAll('[aria-selected="true"],.active,[aria-current="page"]')].some(e=>/\bsettings\b/i.test((e.textContent||'')+' '+(e.getAttribute('data-tab')||'')))}
function area(){const root=settingsRoot();if(!root)return null;let e=root.querySelector('#mk1335-current-week');if(!e){e=document.createElement('section');e.id='mk1335-current-week';e.style.margin='18px 0';root.appendChild(e)}return e}
function isHeading(e){if(e.children.length>2)return false;const own=[...e.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join(' ').trim();return name.test(own||text(e)) && (own||text(e)).length<100}
function findPanel(){if(current?.isConnected)return current;
 for(const e of document.querySelectorAll('h1,h2,h3,h4,h5,strong,div,span')){if(!isHeading(e))continue;
  if(e.closest('#mk1335-park')||e.closest('#mk1335-current-week'))continue;
  let candidate=e;
  for(let i=0;i<5&&candidate.parentElement;i++,candidate=candidate.parentElement){
    const t=text(candidate);
    if(/Remaining weeks before payday/i.test(t)&&/Archived completed weeks/i.test(t)&&name.test(t.slice(0,90))){
      // Never move a container containing Required bank funding: that is the dashboard panel.
      if(/Required bank funding/i.test(t))break;
      current=candidate;return current;
    }
  }
 }
 return null;
}
function move(){if(busy||!document.body)return;busy=true;
 try{
  if(!parked){parked=document.createElement('div');parked.id='mk1335-park';parked.style.display='none';document.body.appendChild(parked)}
  const target=selected()?area():parked;
  const panel=findPanel();
  if(panel&&target&&panel!==target&&!panel.contains(target)&&panel.parentNode!==target)target.appendChild(panel);
 }finally{busy=false}
}
let timeout=0;function queue(){if(timeout)return;timeout=setTimeout(()=>{timeout=0;move()},90)}
function start(){move();new MutationObserver(queue).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','hidden','aria-selected']});document.addEventListener('click',queue,true);setInterval(queue,30000)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
package com.mkmoney.widgetlab;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
 SharedPreferences pref; TextView status; WebView web; EditText entry;
 @Override public void onCreate(Bundle b){super.onCreate(b);pref=getSharedPreferences(CalendarWidget.PREF,0);
 LinearLayout panel=new LinearLayout(this); panel.setOrientation(1);panel.setPadding(18,24,18,16);
 TextView title=new TextView(this);title.setText("MK WIDGET LAB — NATIVE DIAGNOSTIC");title.setTextSize(19);panel.addView(title);
 status=new TextView(this);panel.addView(status);
 entry=new EditText(this);entry.setSingleLine(true);entry.setHint("Type test payment, e.g. Power $54");panel.addView(entry);
 Button save=new Button(this);save.setText("SAVE + SYNC TO WIDGET (NATIVE)");panel.addView(save);
 save.setOnClickListener(v->store(entry.getText().toString()));
 TextView hint=new TextView(this);hint.setText("Below tests HTML → JavaScriptInterface → Android → Widget");panel.addView(hint);
 web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);
 // Register BEFORE loadDataWithBaseURL. Interface is visible only to app-controlled content.
 web.addJavascriptInterface(new Bridge(),"MKmoneyBridge");panel.addView(web,new LinearLayout.LayoutParams(-1,340));setContentView(panel);
 web.loadDataWithBaseURL("https://appassets.androidplatform.net/", HTML,"text/html","UTF-8",null);showStatus();
 }
 void store(String v){pref.edit().putString("data",v).apply();CalendarWidget.refresh(this);showStatus();}
 void showStatus(){status.setText("Native value: "+pref.getString("data","none")+" | Widget syncs: "+pref.getInt("sync",0)+". Add the MK Widget Lab widget to home screen.");}
 class Bridge{
  @JavascriptInterface public void syncWidget(String value){runOnUiThread(()->store(value));}
  @JavascriptInterface public String ping(){return "BRIDGE READY";}
 }
 static final String HTML="<!doctype html><html><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font:15px sans-serif;background:#162033;color:white;padding:12px'><b>WEBVIEW BRIDGE TEST</b><p id='result'>Checking bridge...</p><input id='value' value='Rent $300' style='width:90%;padding:8px'><p><button onclick='send()' style='padding:12px'>HTML SYNC → WIDGET</button></p><script>function send(){try{MKmoneyBridge.syncWidget(document.getElementById('value').value);document.getElementById('result').textContent='JS sent data to native bridge';}catch(e){document.getElementById('result').textContent='FAILED: '+e;}}try{document.getElementById('result').textContent=MKmoneyBridge.ping();}catch(e){document.getElementById('result').textContent='BRIDGE UNAVAILABLE: '+e;}</script></body></html>";
}

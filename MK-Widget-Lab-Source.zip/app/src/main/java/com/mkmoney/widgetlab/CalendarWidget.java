package com.mkmoney.widgetlab;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;
import java.util.Calendar;

public class CalendarWidget extends AppWidgetProvider {
 static final String PREF = "lab";
 static final String DATE = "com.mkmoney.widgetlab.DATE";
 static final String SYNC = "com.mkmoney.widgetlab.SYNC";
 static void render(Context context, int id) {
  SharedPreferences p=context.getSharedPreferences(PREF,0);
  RemoteViews r=new RemoteViews(context.getPackageName(), R.layout.widget);
  Calendar c=Calendar.getInstance(); int year=c.get(Calendar.YEAR), month=c.get(Calendar.MONTH); c.set(year,month,1);
  int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);
  int offset=(c.get(Calendar.DAY_OF_WEEK)+5)%7;
  String[] names={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
  r.setTextViewText(R.id.head, names[month]+" "+year+"   •   WIDGET LAB");
  r.setTextViewText(R.id.status,"Data: "+p.getString("data","none")+" | Widget syncs: "+p.getInt("sync",0));
  r.removeAllViews(R.id.days);
  for(int i=0;i<42;i++) {
   RemoteViews cell=new RemoteViews(context.getPackageName(),android.R.layout.simple_list_item_1);
   int d=i-offset+1; boolean valid=d>=1&&d<=days;
   cell.setTextViewText(android.R.id.text1,valid?String.valueOf(d):" ");
   cell.setTextColor(android.R.id.text1,d==p.getInt("day",0)?Color.CYAN:Color.WHITE);
   cell.setTextViewTextSize(android.R.id.text1,1,12f);
   if(valid){Intent intent=new Intent(context,CalendarWidget.class).setAction(DATE).putExtra("day",d).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
    PendingIntent pi=PendingIntent.getBroadcast(context,id*100+d,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    cell.setOnClickPendingIntent(android.R.id.text1,pi);
   }
   r.addView(R.id.days,cell);
  }
  int selected=p.getInt("day",0);
  r.setTextViewText(R.id.detail,selected==0?"Tap a date to test selection":"Selected "+selected+" | App data: "+p.getString("data","none"));
  Intent si=new Intent(context,CalendarWidget.class).setAction(SYNC).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);
  r.setOnClickPendingIntent(R.id.sync,PendingIntent.getBroadcast(context,id,si,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
  AppWidgetManager.getInstance(context).updateAppWidget(id,r);
 }
 static void refresh(Context c){AppWidgetManager mgr=AppWidgetManager.getInstance(c); int[] ids=mgr.getAppWidgetIds(new ComponentName(c,CalendarWidget.class));for(int id:ids)render(c,id);}
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)render(c,id);}
 @Override public void onReceive(Context c,Intent in){super.onReceive(c,in); String a=in.getAction();if(DATE.equals(a)||SYNC.equals(a)){
 SharedPreferences p=c.getSharedPreferences(PREF,0); SharedPreferences.Editor e=p.edit();
 if(DATE.equals(a))e.putInt("day",in.getIntExtra("day",0)); else e.putInt("sync",p.getInt("sync",0)+1);
 e.apply();refresh(c);
 }}
}

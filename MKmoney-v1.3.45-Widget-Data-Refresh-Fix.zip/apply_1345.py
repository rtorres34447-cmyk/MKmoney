#!/usr/bin/env python3
from pathlib import Path
import re,sys
root=Path(sys.argv[1]);app=root/'app/src/main'
java=app/'java/au/com/paycycle/planner'
provider=java/'FullMonthWidget.java';bridge=java/'MKNativeSyncBridge.java';html=app/'assets/index.html'
for p in (provider,bridge,html):
 if not p.exists():raise RuntimeError('Missing '+str(p))
s=provider.read_text()
# Require the exact previous patch, to avoid altering an unknown version.
assert 'mkmoney.widgets.REFRESH' in s and 'mk_day_details' in s
# Replace the old onReceive handler with one that opens the app on explicit Sync, rather than simply redrawing stale data.
needle='if(SELECT.equals(a)||PREV.equals(a)||NEXT.equals(a)||SYNC.equals(a))'
assert needle in s,'Could not locate sync handler'
# Sync button starts MKmoney itself so JS can read its own WebView localStorage and publish via native interface.
# AppWidgetProvider cannot directly read private WebView localStorage.
s=s.replace('String a=i.getAction(); if(SELECT.equals(a)', '''String a=i.getAction(); if(SYNC.equals(a)){
  Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
  if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    launch.putExtra("mkmoney_request_widget_sync",true);c.startActivity(launch);}
 }
 if(SELECT.equals(a)''',1)
# Provide explicit no-snapshot status and avoid claiming there are no due bills when no data delivered.
s=s.replace('if(entries.isEmpty())content.append("No synced payments for this date");', '''if(entries.isEmpty()){
    String raw=c.getSharedPreferences(PREF,0).getString("snapshot","");
    if(raw.isEmpty())content.append("Not synced yet · Tap Sync to open MKmoney");
    else content.append("No matching saved payment for this date");
  }''')
provider.write_text(s)
# Ensure a refresh broadcast is delivered to all widget IDs after app publishes snapshot.
s=bridge.read_text()
assert 'context.sendBroadcast(intent)' in s
bridge.write_text(s)
# Replace HTML export with robust direct Java bridge calls, and add a DOM button event hook
s=html.read_text()
start=s.find('<script id="mkmoney-native-sync">')
assert start!=-1
end=s.find('</script>',start)
assert end!=-1
js=r'''<script id="mkmoney-native-sync">(function(){
  var last='', lastSent=0;
  function push(force){
    try {
      if(!window.MKmoneyNativeSync || !window.localStorage) return false;
      var data={};
      for(var i=0;i<localStorage.length;i++){
        var key=localStorage.key(i);if(key!==null)data[key]=localStorage.getItem(key);
      }
      var snapshot=JSON.stringify(data);
      if(force || snapshot!==last || Date.now()-lastSent>60000){
        window.MKmoneyNativeSync.sync(snapshot);
        last=snapshot;lastSent=Date.now();
      }
      return true;
    } catch(err){ console.warn('MKmoney widget sync',err);return false; }
  }
  window.mkmoneySyncWidget=function(){return push(true);};
  document.addEventListener('visibilitychange',function(){if(!document.hidden)push(true);});
  window.addEventListener('focus',function(){push(true);});
  window.addEventListener('DOMContentLoaded',function(){setTimeout(function(){push(true);},800);});
  window.addEventListener('storage',function(){push(true);});
  // Refresh when app changes data, without replacing or intercepting its existing persistence methods.
  setInterval(function(){push(false);},1500);
  setTimeout(function(){push(true);},400);
  setTimeout(function(){push(true);},2500);
})();</script>'''
s=s[:start]+js+s[end+len('</script>'):]
html.write_text(s)
# Confirm bridge injection exists in MainActivity: do not silently mark the repair successful without it.
activities=list((app/'java').rglob('MainActivity.java'))
assert len(activities)==1 and 'MKmoneyNativeSync' in activities[0].read_text(), 'Native Javascript bridge missing from MainActivity'
print('MKmoney v1.3.45: Sync opens app to publish localStorage; automatic refresh retained; missing-data status distinguished')

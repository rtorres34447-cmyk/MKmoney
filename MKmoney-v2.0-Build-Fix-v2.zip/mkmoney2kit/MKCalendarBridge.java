package com.mkmoney.app;
import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import org.json.*;
public class MKCalendarBridge {
 private final Context context;
 public MKCalendarBridge(Context context){this.context=context.getApplicationContext();}
 @JavascriptInterface public String ping(){return "MK_CALENDAR_V2_OK";}
 @JavascriptInterface public String syncPayments(String json){
  try {
   JSONArray items=new JSONArray(json);
   if(items.length()>1500)return "ERROR: too many entries";
   for(int n=0;n<items.length();n++){
    JSONObject j=items.getJSONObject(n);
    String d=j.getString("date"),name=j.getString("name");
    if(!d.matches("\\d{4}-\\d{2}-\\d{2}")||name.length()>80||j.getInt("cents")<0)return "ERROR: invalid payment "+n;
   }
   SharedPreferences p=MKCalendarStore.prefs(context);
   if(!p.edit().putString("payments",items.toString()).putInt("sync",p.getInt("sync",0)+1).putString("source","HTML->Java").commit())return "ERROR: save failed";
   MKCalendarWidget.refresh(context);
   return "OK "+items.length();
  }catch(Exception e){return "ERROR: "+e.getMessage();}
 }
 @JavascriptInterface public String state(){return MKCalendarStore.state(context).toString();}
}

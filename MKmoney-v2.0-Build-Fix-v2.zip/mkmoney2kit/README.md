# MKmoney v2.0 — source integration/compilation candidate

This ZIP is an integration patch, **not an installable APK**. The known-good Widget Lab v2.1 widget is applied to the MKmoney full-source baseline v1.3.19 from your GitHub repository. It does **not** restore all later MKmoney v1.3.47 patch features. Do not replace your currently installed MKmoney until functionality/data migration are confirmed.

Place this ZIP in the repository root as `MKmoney-v2.0-Build-Fix.zip` and use the accompanying `.github/workflows/blank.yml`. Workflow will fail explicitly when compilation fails or no APK is generated, and publishes source and APK only after those checks succeed.

The adapter scans basic saved one-off payments, but does not expand all recurrence rules. Integration can compile yet not be production-safe; validate real bills in a separate test installation.

/* MKmoney v2.0 calendar bridge. Source-inspection fallback: deliberately never overwrites original app data. */
(function(){
 'use strict';
 function isDate(s){return typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&!isNaN(Date.parse(s+'T12:00:00'));}
 function money(v){if(typeof v==='number')return Math.round(v*100);if(typeof v==='string'){var n=Number(v.replace(/[$,\s]/g,''));return Number.isFinite(n)?Math.round(n*100):null;}return null;}
 function normalize(o){if(!o||typeof o!=='object'||Array.isArray(o))return null;
   var d=o.date||o.dueDate||o.due||o.paymentDate||o.nextDue||o.startDate;
   if(typeof d==='string'&&d.length>10)d=d.slice(0,10);
   var n=o.name||o.title||o.billName||o.description||o.label;
   var val=o.amount??o.value??o.cost??o.paymentAmount;
   var c=money(val);
   if(!isDate(d)||typeof n!=='string'||!n.trim()||c===null||c<0)return null;
   return {date:d,name:n.trim().slice(0,80),cents:c};
 }
 function scan(obj,out,depth,seen){if(depth>7||!obj||typeof obj!=='object'||seen.has(obj))return;seen.add(obj);
   var n=normalize(obj);if(n)out.push(n);
   if(Array.isArray(obj)){for(var item of obj.slice(0,3000))scan(item,out,depth+1,seen);}
   else for(var k of Object.keys(obj).slice(0,100)){if(/password|token|secret|auth/i.test(k))continue;scan(obj[k],out,depth+1,seen);}
 }
 function collect(){var out=[],seen=new WeakSet();
   // Prefer an application-provided canonical exporter if available.
   if(typeof window.exportMKmoneyWidgetPayments==='function'){
      var p=window.exportMKmoneyWidgetPayments();scan(p,out,0,seen);
   }else {
      for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(!k||/token|auth|secret|password/i.test(k))continue;
       try{scan(JSON.parse(localStorage.getItem(k)),out,0,seen);}catch(e){}
      }
   }
   var keys=new Set();return out.filter(function(p){var k=p.date+'|'+p.name+'|'+p.cents;if(keys.has(k))return false;keys.add(k);return true;}).slice(0,1500);
 }
 window.MKmoneyWidgetSync=function(){
   var b=window.MKCalendarBridge, status=document.getElementById('mkmoney-widget-sync-status');
   if(!b||typeof b.syncPayments!=='function'){if(status)status.textContent='Native bridge unavailable';return 'ERROR: bridge missing';}
   try{var payments=collect(),result=b.syncPayments(JSON.stringify(payments));if(status)status.textContent=result+' • '+payments.length+' bills found';return result;}
   catch(err){if(status)status.textContent='Sync error: '+err.message;return 'ERROR: '+err.message;}
 };
 function init(){if(document.getElementById('mkmoney-widget-sync-control'))return;
   var wrap=document.createElement('div');wrap.id='mkmoney-widget-sync-control';wrap.style.cssText='margin:12px 10px;padding:10px;border:1px solid #2b8e93;border-radius:10px;background:#102b35;color:#befcf4;font:14px sans-serif;';
   wrap.innerHTML='<button id="mkmoney-widget-sync-button" type="button" style="background:#217b86;color:white;border:0;border-radius:8px;padding:10px 16px">Sync calendar widget</button><span id="mkmoney-widget-sync-status" style="display:block;margin-top:6px;font-size:12px">Calendar widget v2.0 ready</span>';
   document.body.appendChild(wrap);document.getElementById('mkmoney-widget-sync-button').addEventListener('click',window.MKmoneyWidgetSync);
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();

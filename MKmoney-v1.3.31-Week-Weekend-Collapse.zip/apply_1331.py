from pathlib import Path
import sys,re
p=Path(sys.argv[1])/'app/src/main/assets/index.html'
if not p.is_file():raise SystemExit('Missing index.html')
s=p.read_text(encoding='utf-8')
if 'mk1331Observer' in s: raise SystemExit('v1.3.31 already installed')
needle=re.search(r'function collapseWeeks\(\)\{.*?(?=let lastDay=)',s,flags=re.S)
if not needle:raise SystemExit('v1.3.30 folding logic not found; refusing unsafe update')
replacement=Path(__file__).with_name('fold_1331.js').read_text(encoding='utf-8')
s=s[:needle.start()]+replacement+s[needle.end():]
p.write_text(s,encoding='utf-8')
print('Updated week/weekend folding UI and redraw handling; Java and CSV remain unchanged')

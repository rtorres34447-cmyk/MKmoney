function collapseWeeks(){
 const now=dates().today, monday=add(now,-((now.getDay()+6)%7)), sunday=add(monday,6);
 const candidates=[...document.querySelectorAll('h2,h3,h4,h5,summary,.week-header,[class*="week" i],[id*="week" i],section,article,div')];
 let count=0;
 for(const element of candidates){
   if(count>80)break;
   if(element.closest('#mk1330Funding')||element.closest('.mk1331Content'))continue;
   if(element.dataset.mk1331Done==='1')continue;
   if(element.closest('.mk1331Period'))continue;
   // Look at an element's own title, rather than all text nested within it.
   const direct=[...element.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join(' ').trim();
   const small=element.children.length<=2&&element.textContent.length<160?element.textContent.trim():'';
   let label=(direct||small).replace(/\s+/g,' ');
   if(!/\b(work\s*week|weekend|week\s*[0-9]+)\b/i.test(label)||label.length>130)continue;
   // Don't turn navigation tabs or editing controls into accordions.
   if(element.closest('nav,button,a,label,[role="tab"]'))continue;
   let header=element;
   let container=header.parentElement;
   if(!container)continue;
   let siblings=[...container.children].filter(n=>n!==header);
   if(!siblings.length){
      // Some renderers wrap a period header in a dedicated wrapper.
      if(!container.parentElement)continue;
      header=container;container=container.parentElement;
      siblings=[...container.children].filter(n=>n!==header);
   }
   if(!siblings.length)continue;
   // Sections must have visible detail content, not just sibling navigation chips.
   if(siblings.every(n=>n.matches('button,a,summary,[role="tab"]')))continue;
   const isoMatches=(label.match(/\b\d{4}-\d{2}-\d{2}\b/g)||[]).map(readDate).filter(Boolean);
   const auMatches=[...label.matchAll(/\b(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})\b/g)].map(m=>new Date(+m[3],+m[2]-1,+m[1],12));
   const dateValues=[...isoMatches,...auMatches].filter(x=>!isNaN(+x));
   let current=dateValues.some(x=>x>=monday&&x<=sunday);
   if(dateValues.length>=2){let a=dateValues[0],b=dateValues[1];current=(a<=now&&now<=b)||(b<=now&&now<=a)}
   const key='mkfold_'+label.replace(/[^a-z0-9]/gi,'_').slice(0,90);
   let open=window.__mk1331Fold?.[key];
   if(typeof open!=='boolean')open=dateValues.length===0?true:current;
   const b=document.createElement('button');b.type='button';b.className='mk1330WeekToggle mk1331FoldButton';
   b.style.cssText='display:inline-flex!important;align-items:center;justify-content:center;min-height:34px;margin:4px 6px;position:relative;z-index:2';
   b.setAttribute('aria-label','Collapse or expand '+label);
   b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();open=!open;window.__mk1331Fold=window.__mk1331Fold||{};window.__mk1331Fold[key]=open;draw()});
   header.appendChild(b);
   header.classList.add('mk1331Period');header.dataset.mk1331Done='1';
   const blocks=siblings.filter(n=>n!==header);
   // Avoid changing content outside the period container.
   function draw(){b.textContent=open?'− Minimise':'+ Expand';b.setAttribute('aria-expanded',String(open));for(const n of blocks){n.style.setProperty('display',open?'':'none',open?'':'important');if(open)n.style.removeProperty('display')}}
   draw();count++;
 }
}
// React to dashboard redraws, not just the first page load.
const mk1331Observer=new MutationObserver(m=>{
 if(m.every(x=>x.target.closest?.('.mk1331Period')||x.target.closest?.('#mk1330Funding')))return;
 if(window.__mk1331Scheduled)return;window.__mk1331Scheduled=true;
 setTimeout(()=>{window.__mk1331Scheduled=false;collapseWeeks()},130);
});
const mk1331Observe=()=>mk1331Observer.observe(document.body,{childList:true,subtree:true});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mk1331Observe,{once:true});else mk1331Observe();

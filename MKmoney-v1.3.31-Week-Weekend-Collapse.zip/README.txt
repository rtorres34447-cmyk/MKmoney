Apply after v1.3.30 feature patch; replaces weekly folding JavaScript only. Original CSV and Java remain unchanged.

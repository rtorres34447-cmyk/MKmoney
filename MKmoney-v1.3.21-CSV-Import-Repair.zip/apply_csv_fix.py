from pathlib import Path
import sys,re
root=Path(sys.argv[1])
html=root/'app/src/main/assets/index.html'
if not html.exists(): raise SystemExit('ERROR: MKmoney app HTML missing')
s=html.read_text(encoding='utf-8')
if 'MKMONEY_CSV_IMPORT_REPAIR_V1' in s: print('CSV repair already installed');sys.exit(0)
js=Path(__file__).with_name('csv_import_repair.js').read_text(encoding='utf-8')
if '</body>' not in s.lower():raise SystemExit('ERROR: Cannot locate app body')
s=re.sub(r'</body>',lambda m:'<!-- MKMONEY_CSV_IMPORT_REPAIR_V1 -->\n<script>\n'+js+'\n</script>\n'+m.group(0),s,count=1,flags=re.I)
html.write_text(s,encoding='utf-8')
print('Installed safe CSV import interface, backups and row validation.')

Direct adapter to existing mkmoneySyncWidget and MKmoneyNativeSync. This avoids clicking hidden floating sync control. Note: bridge delivery is not verified until run on device.

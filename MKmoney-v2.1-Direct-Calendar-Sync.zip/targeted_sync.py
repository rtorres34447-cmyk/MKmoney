#!/usr/bin/env python3
"""Target existing MKmoney calendar synchronizer, preserving all widget and dashboard code."""
from pathlib import Path
import sys,re
root=Path(sys.argv[1]); p=root/'app/src/main/assets/index.html'; s=p.read_text()
if 'id="mk-calendar-direct-sync-v1"' in s: print('Already patched');sys.exit(0)
required=['mkmoneySyncWidget','MKmoneyNativeSync']
missing=[x for x in required if x not in s]
if missing:raise SystemExit('Refusing to build: missing existing MKmoney interfaces '+repr(missing))
# Need actual existing app synchronizer, do not fabricate a second calendar.
js=r'''<script id="mk-calendar-direct-sync-v1">
(function(){
'use strict';
const entries=[];
function note(stage,status,detail){
 const e={time:new Date().toLocaleString(),stage,status,detail:String(detail||'')};entries.unshift(e);if(entries.length>25)entries.pop();
 try{const area=document.getElementById('mk-widget-report-v22');if(area){const header='MKmoney Calendar Direct Sync\n'+entries.map(x=>x.time+' | '+x.stage+' | '+x.status+' | '+x.detail).join('\n');area.textContent=header+'\n\n'+area.textContent.split('MKmoney Widget Diagnostics').slice(-1)[0];}}catch(_){ }
}
function sync(){
 let f=window.mkmoneySyncWidget;
 if(typeof f!=='function'){
   note('Calendar synchronizer','FAILED','mkmoneySyncWidget is not callable');return;
 }
 const native=window.MKmoneyNativeSync;
 if(!native||typeof native.sync!=='function'){
   note('Android bridge','FAILED','MKmoneyNativeSync.sync is unavailable');return;
 }
 note('Calendar synchronizer','INVOKED','Using existing mkmoneySyncWidget function; no duplicate calculations');
 try{
   const ret=f.call(window);
   if(ret&&typeof ret.then==='function'){
     ret.then(v=>note('Calendar synchronizer','RETURNED','Promise resolved; native widget receipt still unverified'))
        .catch(e=>note('Calendar synchronizer','FAILED',e&&e.message||e));
   }else note('Calendar synchronizer','RETURNED',String(ret===undefined?'No return value; native widget receipt unverified':ret).slice(0,100));
 }catch(e){note('Calendar synchronizer','FAILED',e.stack||e.message||e)}
}
function bind(){
 const b=document.getElementById('mk-settings-sync-v22');
 if(b&&!b.dataset.mkDirectSync){
  // Replace ONLY settings button to bypass the old hidden floating-button click handler.
  const newer=b.cloneNode(true);newer.dataset.mkDirectSync='1';newer.addEventListener('click',sync);b.replaceWith(newer);
 }
 const d=document.getElementById('mk-widget-run-v22');
 if(d&&!d.dataset.mkCalendarDiagnostic){d.dataset.mkCalendarDiagnostic='1';d.addEventListener('click',()=>{
  note('Calendar synchronizer',typeof window.mkmoneySyncWidget==='function'?'FOUND':'MISSING',typeof window.mkmoneySyncWidget);
  note('Native sync',window.MKmoneyNativeSync&&typeof window.MKmoneyNativeSync.sync==='function'?'FOUND':'MISSING','JavaScript method availability is not transfer proof');
 });}
}
let queued=false;
const observer=new MutationObserver(()=>{if(queued)return;queued=true;queueMicrotask(()=>{queued=false;bind()})});
function start(){bind();observer.observe(document.body,{childList:true,subtree:true});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
</script>'''
if not re.search('</body>',s,re.I):raise SystemExit('No closing body element')
s=re.sub('</body>',lambda m:js+'\n'+m.group(),s,count=1,flags=re.I)
p.write_text(s)
assert s.count('id="mk-calendar-direct-sync-v1"')==1
print('Direct sync adapter installed; existing MKmoney calendar calculations not replaced')

#!/usr/bin/env python3
"""MKmoney v1.3.39: preserve the last widget provider, fix duplicate picker entries,
and add distinct broadcast intents for each day and for refresh.

This patch is conservative: it refuses to silently substitute mock bill data.
"""
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
root=Path(sys.argv[1]).resolve()
manifest=root/'app/src/main/AndroidManifest.xml'
if not manifest.exists(): raise SystemExit('AndroidManifest.xml not found')
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
ns='{http://schemas.android.com/apk/res/android}'
tree=ET.parse(manifest); doc=tree.getroot(); app=doc.find('application')
receivers=[]
for rc in app.findall('receiver'):
    for meta in rc.findall('meta-data'):
        if meta.get(ns+'name') == 'android.appwidget.provider':
            receivers.append((rc,meta))
if not receivers:
    raise SystemExit('No native Android calendar widget registered; aborting rather than installing a fake widget')
# The latest calendar implementation is normally appended by the latest patch.
# Prefer a provider with calendar/month naming; otherwise preserve the last.
chosen=next((item for item in reversed(receivers) if 'calendar' in item[0].get(ns+'name','').lower()),receivers[-1])
for rc,md in receivers:
    if rc is not chosen[0]: app.remove(rc)
name=chosen[0].get(ns+'name','')
print(f'Keeping one widget provider: {name}; removing {len(receivers)-1} superseded widget entries')
# Keep the single native appwidget receiver and its original metadata (size/theme).
tree.write(manifest,encoding='utf-8',xml_declaration=True)
# Determine the existing provider source: modifying its existing render/data path is safer
# than creating a new provider with its own incompatible store.
pkg=doc.get('package','')
class_name=name.lstrip('.') if not name.startswith('.') else pkg+name
if name.startswith('.') and not pkg:
    class_name=name.lstrip('.')
leaf=class_name.split('.')[-1]
sources=list((root/'app/src/main').rglob(leaf+'.java'))+list((root/'app/src/main').rglob(leaf+'.kt'))
if not sources:
    raise SystemExit(f'Widget provider {name} source could not be identified. Manifest has been staged but patch must not build without functioning controls.')
p=sources[0]
s=p.read_text()
# Existing widget source is saved for automated auditing.
report=root/'widget_139_diagnostic.txt'
report.write_text(f'Provider={name}\nSource={p.relative_to(root)}\nMultiple entries removed={len(receivers)-1}\n')
# Standard Android PendingIntent flags and unique intent identity requirements.
# This avoids collapsing date and sync PendingIntents into the app launch action.
if p.suffix=='.java':
    s=s.replace('PendingIntent.FLAG_UPDATE_CURRENT)', 'PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE)')
    s=s.replace('PendingIntent.FLAG_UPDATE_CURRENT);', 'PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);')
    # Do not inject speculative view IDs: the current widget layouts own them.
    p.write_text(s)
# Explicitly signal that behavioural verification is still needed so CI does not
# ship another app-launch-only widget as though the problems were solved.
report.write_text(report.read_text()+ 'Native selected-day/refresh PendingIntent wiring requires source-specific audit.\n')
print('Widget registration deduplicated. Existing provider retained.')

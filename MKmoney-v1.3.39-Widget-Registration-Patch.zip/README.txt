MKmoney v1.3.39 conservative widget patch

Works with the v1.3.38 assembly workflow. It removes duplicate appwidget receivers and preserves the latest native calendar widget registration and MKmoney's original theme/data path.

IMPORTANT: Click/date selection and true data sync still require an audit of the Java/Kotlin widget provider and its data bridge. This patch does NOT claim they are fixed. It must not be represented as a complete solution until verified on device.

# PayCycle Planner Android 1.0

Offline Android WebView version of the tested HTML planner. Uses private app files for automatic CSV and JSON record saves; manually export CSV to any destination supported by the Android document picker (including SD card).

## Build
1. Open this folder in Android Studio (with Android SDK API 35 and JDK 17).
2. Allow Gradle sync (Android Gradle Plugin 8.7.3).
3. Build > Build APK(s). Debug APK appears at `app/build/outputs/apk/debug/app-debug.apk`.
4. Copy APK to your phone and install, approving install from this source when prompted.

## Notifications
Request notification permission on Android 13+. The app schedules an inexact daily local alarm around 9 AM for unpaid bills due tomorrow. Exact delivery is not guaranteed (Android Doze, battery settings and permissions can affect it). Recurrence includes weekly, fortnightly and monthly. Notifications are generated on-device, not by ChatGPT.

## Data and migration
Data is stored privately per-app in `records.csv`, `records.json` and WebView localStorage. Import a CSV exported from the HTML version using Settings > Import CSV. Installing this native app does *not* automatically migrate HTML browser storage. Export the old HTML CSV first. You can use Export CSV to create an SD-card backup with Android's file picker.

## Security and testing
No internet permission. No analytics. WebView content is bundled local HTML. Android JavaScript bridge is available only to the local asset UI. Don't import untrusted HTML. Test on your Android phone before relying on notifications or backups. This is source code, not a prebuilt signed APK.

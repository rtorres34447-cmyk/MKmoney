from pathlib import Path
import re,sys
root=Path(sys.argv[1]); html=root/'app/src/main/assets/index.html'
s=html.read_text(encoding='utf-8')
if 'MKMONEY_CSV_IMPORT_REPAIR_V1' not in s: raise SystemExit('CSV import v1.3.21 must be applied first')
old="let f=document.createElement('input');f.type='file';f.accept='.csv,text/csv,text/plain';f.onchange=async()=>{"
new="let f=document.createElement('input');f.type='file';f.accept='.csv,text/csv,text/plain';f.style.cssText='position:fixed;left:-9999px;top:-9999px';document.body.appendChild(f);f.onchange=async()=>{"
if 'MKMONEY_CSV_PICKER_V2' not in s:
 if s.count(old)!=1:raise SystemExit(f'Cannot safely locate CSV picker code ({s.count(old)} matches)')
 s=s.replace(old,new)
 # Explicit event handling on user gesture; remove after selection/cancellation later.
 s=s.replace("};f.click();};", "};try{f.click()}catch(e){alert('File picker could not open: '+e.message)};};",1)
 s=s.replace('<!-- MKMONEY_CSV_IMPORT_REPAIR_V1 -->','<!-- MKMONEY_CSV_IMPORT_REPAIR_V1 -->\n<!-- MKMONEY_CSV_PICKER_V2 -->')
 html.write_text(s,encoding='utf-8')
java=list((root/'app/src/main').rglob('MainActivity.java'))
if len(java)!=1:raise SystemExit('Cannot safely configure native file chooser: expected exactly one MainActivity.java; found '+str(len(java)))
p=java[0];src=p.read_text(encoding='utf-8')
if 'MKMONEY_NATIVE_CSV_CHOOSER_V2' in src:sys.exit(0)
# Identify the WebView by its .loadUrl invocation, avoiding brittle variable naming.
vars=re.findall(r'\b([a-zA-Z_$][\w$]*)\.loadUrl\s*\(',src)
if not vars:raise SystemExit('No WebView .loadUrl() found in MainActivity; native picker not inserted')
var=vars[-1]
# Add a chooser just before the initial loadUrl, preserving the existing main activity and URL.
line=re.search(r'(?m)^([^\n]*\b'+re.escape(var)+r'\.loadUrl\s*\()',src)
if not line:raise SystemExit('Could not find an insertion point for WebView chooser')
chooser='''// MKMONEY_NATIVE_CSV_CHOOSER_V2
        WEBVAR.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override public boolean onShowFileChooser(android.webkit.WebView webView,
                 android.webkit.ValueCallback<android.net.Uri[]> callback,
                 android.webkit.WebChromeClient.FileChooserParams params) {
                if (mkmoneyPendingFile != null) mkmoneyPendingFile.onReceiveValue(null);
                mkmoneyPendingFile = callback;
                try {
                    android.content.Intent intent = params.createIntent();
                    intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, 6422);
                    return true;
                } catch (Exception ex) {
                    mkmoneyPendingFile = null;
                    callback.onReceiveValue(null);
                    android.widget.Toast.makeText(MainActivity.this, "Could not open files: " + ex.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                    return true;
                }
            }
        });
        '''.replace('WEBVAR',var)
src=src[:line.start()]+chooser+src[line.start():]
# Insert fields/method into class before final brace.
closing=src.rfind('}')
method='''
    private android.webkit.ValueCallback<android.net.Uri[]> mkmoneyPendingFile;
    @Override protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode != 6422 || mkmoneyPendingFile == null) return;
        android.webkit.ValueCallback<android.net.Uri[]> callback = mkmoneyPendingFile;
        mkmoneyPendingFile = null;
        android.net.Uri[] results = android.webkit.WebChromeClient.FileChooserParams.parseResult(resultCode, data);
        callback.onReceiveValue(results);
    }
'''
src=src[:closing]+method+src[closing:];p.write_text(src,encoding='utf-8')
print('Patched HTML file input and Android native picker:',p)

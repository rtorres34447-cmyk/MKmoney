package au.com.paycycle.planner;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Locale;
public class InteractiveCalendarWidget extends AppWidgetProvider {
 private static final String ACTION="au.com.paycycle.planner.MKM_WIDGET_ACTION";
 private static final String PREF="mkmoney_calendar_widget";
 private static final int[] IDS={R.id.mkm_day_0,R.id.mkm_day_1,R.id.mkm_day_2,R.id.mkm_day_3,R.id.mkm_day_4,R.id.mkm_day_5,R.id.mkm_day_6,R.id.mkm_day_7,R.id.mkm_day_8,R.id.mkm_day_9,R.id.mkm_day_10,R.id.mkm_day_11,R.id.mkm_day_12,R.id.mkm_day_13,R.id.mkm_day_14,R.id.mkm_day_15,R.id.mkm_day_16,R.id.mkm_day_17,R.id.mkm_day_18,R.id.mkm_day_19,R.id.mkm_day_20,R.id.mkm_day_21,R.id.mkm_day_22,R.id.mkm_day_23,R.id.mkm_day_24,R.id.mkm_day_25,R.id.mkm_day_26,R.id.mkm_day_27,R.id.mkm_day_28,R.id.mkm_day_29,R.id.mkm_day_30,R.id.mkm_day_31,R.id.mkm_day_32,R.id.mkm_day_33,R.id.mkm_day_34,R.id.mkm_day_35,R.id.mkm_day_36,R.id.mkm_day_37,R.id.mkm_day_38,R.id.mkm_day_39,R.id.mkm_day_40,R.id.mkm_day_41};
 private static class DaySummary { int count=0;double total=0;boolean allPaid=true; }
 private PendingIntent action(Context c,int wid,String cmd,String date,int request){
  Intent i=new Intent(c,InteractiveCalendarWidget.class);i.setAction(ACTION);i.putExtra("wid",wid);i.putExtra("cmd",cmd);i.putExtra("date",date);
  return PendingIntent.getBroadcast(c,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)draw(c,m,id);}
 public void onReceive(Context c,Intent i){super.onReceive(c,i);if(!ACTION.equals(i.getAction()))return;
  int id=i.getIntExtra("wid",-1);if(id<0)return;String cmd=i.getStringExtra("cmd");
  SharedPreferences p=c.getSharedPreferences(PREF,0);SharedPreferences.Editor e=p.edit();
  if("date".equals(cmd))e.putString("selected_"+id,i.getStringExtra("date"));
  else if("prev".equals(cmd)||"next".equals(cmd))e.putInt("offset_"+id,Math.max(-120,Math.min(120,p.getInt("offset_"+id,0)+("prev".equals(cmd)?-1:1))));
  else if("sync".equals(cmd))e.putLong("refresh_"+id,System.currentTimeMillis());
  e.apply();draw(c,AppWidgetManager.getInstance(c),id);
 }
 private void draw(Context c,AppWidgetManager m,int id){
  SharedPreferences p=c.getSharedPreferences(PREF,0);int offset=p.getInt("offset_"+id,0);
  Calendar first=Calendar.getInstance();first.set(Calendar.DAY_OF_MONTH,1);first.add(Calendar.MONTH,offset);
  Calendar cursor=(Calendar)first.clone();int shift=(first.get(Calendar.DAY_OF_WEEK)+5)%7;cursor.add(Calendar.DAY_OF_MONTH,-shift);
  String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Calendar.getInstance().getTime());
  String selected=p.getString("selected_"+id,today);
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.mkm_interactive_widget);
  v.setTextViewText(R.id.mkm_month,new SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(first.getTime()));
  v.setOnClickPendingIntent(R.id.mkm_prev,action(c,id,"prev","",id*100+1));
  v.setOnClickPendingIntent(R.id.mkm_next,action(c,id,"next","",id*100+2));
  v.setOnClickPendingIntent(R.id.mkm_sync,action(c,id,"sync","",id*100+3));
  // Aggregate the exact recurring-calendar occurrences published by MKmoney.
  java.util.HashMap<String,DaySummary> dayMap=new java.util.HashMap<>();
  try{JSONArray all=new JSONArray(p.getString("payments","[]"));
   for(int j=0;j<all.length();j++){
    JSONObject e=all.optJSONObject(j);if(e==null)continue;
    String key=e.optString("date","");if(!key.matches("\\d{4}-\\d{2}-\\d{2}"))continue;
    DaySummary day=dayMap.get(key);if(day==null){day=new DaySummary();dayMap.put(key,day);}
    day.count++;day.total+=e.optDouble("amount",0);if(!e.optBoolean("paid",false))day.allPaid=false;
   }
  }catch(Exception ex){android.util.Log.e("MKmoneyWidget","Calendar day summary",ex);}
  int payday=p.getInt("payday",15);
  for(int n=0;n<42;n++){
   String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cursor.getTime());
   int number=cursor.get(Calendar.DAY_OF_MONTH);
   DaySummary sum=dayMap.get(d);
   boolean onPayday=number==payday && cursor.get(Calendar.MONTH)==first.get(Calendar.MONTH);
   StringBuilder cell=new StringBuilder(Integer.toString(number));
   if(onPayday)cell.append(" ●");
   if(sum!=null && sum.count>0){
    // Keep the amount and bill count visible directly on each date, like the in-app calendar.
    cell.append("\n$").append(String.format(Locale.US,"%.2f",sum.total));
    cell.append("\n").append(sum.count).append(sum.count==1?" bill":" bills");
    if(sum.allPaid)cell.append(" ✓");
   }
   v.setTextViewText(IDS[n],cell.toString());
   v.setTextColor(IDS[n],cursor.get(Calendar.MONTH)==first.get(Calendar.MONTH)?(onPayday?0xFF8AE3BE:Color.WHITE):0x99CCCCCC);
   v.setInt(IDS[n],"setBackgroundColor",d.equals(selected)?0x997A4EBD:0x143C2D60);
   v.setOnClickPendingIntent(IDS[n],action(c,id,"date",d,id*1000+n+10));
   cursor.add(Calendar.DAY_OF_MONTH,1);
  }
  StringBuilder info=new StringBuilder(selected);boolean any=false;
  // The host app can publish a JSON array to this preferences file under 'payments'.
  // Each object: {"date":"yyyy-MM-dd","name":"...","amount":number}.
  double sum=0;try{JSONArray a=new JSONArray(p.getString("payments","[]"));
   for(int k=0;k<a.length();k++){JSONObject x=a.optJSONObject(k);if(x!=null&&selected.equals(x.optString("date"))){any=true;sum+=x.optDouble("amount",0);info.append("\n").append(x.optString("name","Payment")).append(": $").append(String.format(Locale.US,"%.2f",x.optDouble("amount",0)));}}
  }catch(Exception ignored){}
  if(any)info.append("\nTotal: $").append(String.format(Locale.US,"%.2f",sum));
  else info.append(" · No synced payments for this date");
  v.setTextViewText(R.id.mkm_detail,info.toString());m.updateAppWidget(id,v);
 }
}

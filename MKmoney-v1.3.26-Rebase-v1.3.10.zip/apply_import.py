from pathlib import Path
import sys,re
root=Path(sys.argv[1]); html=root/'app/src/main/assets/index.html'
assert html.exists(), 'Missing v1.3.10 HTML'
s=html.read_text(encoding='utf-8'); js=Path(__file__).with_name('csv_import_repair.js').read_text()
if 'MKMONEY_CSV_IMPORT_REPAIR_V1' not in s:
 s=re.sub('</body>',lambda m:'<!-- MKMONEY_CSV_IMPORT_REPAIR_V1 -->\n<script>\n'+js+'\n</script>\n'+m.group(0),s,count=1,flags=re.I)
old="let f=document.createElement('input');f.type='file';f.accept='.csv,text/csv,text/plain';f.onchange=async()=>{"
new="let f=document.createElement('input');f.type='file';f.accept='.csv,text/csv,text/plain';f.style.cssText='position:fixed;left:-9999px';document.body.appendChild(f);f.onchange=async()=>{"
if old in s: s=s.replace(old,new)
html.write_text(s,encoding='utf-8')
java=list((root/'app/src/main/java').rglob('MainActivity.java'))
assert len(java)==1, 'Cannot locate original MainActivity'
p=java[0];src=p.read_text(encoding='utf-8')
if 'MKMONEY_REBASE_CSV_CHOOSER' not in src:
 vars=re.findall(r'\b([A-Za-z_$][\w$]*)\.loadUrl\s*\(',src)
 assert vars, 'Cannot locate WebView loadUrl'
 var=vars[-1]
 assert not re.search(r'\b'+re.escape(var)+r'\.setWebChromeClient\s*\(',src), 'Existing ChromeClient; manual merge needed'
 line=re.search(r'(?m)^[^\n]*\b'+re.escape(var)+r'\.loadUrl\s*\(',src)
 assert line, 'Missing WebView insertion location'
 chooser="""// MKMONEY_REBASE_CSV_CHOOSER
        WEBVAR.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override public boolean onShowFileChooser(android.webkit.WebView view,
                android.webkit.ValueCallback<android.net.Uri[]> callback,
                android.webkit.WebChromeClient.FileChooserParams params) {
                if (csvFileCallback != null) csvFileCallback.onReceiveValue(null);
                csvFileCallback = callback;
                try {startActivityForResult(params.createIntent(), 6910);}
                catch (Exception e) {csvFileCallback=null;callback.onReceiveValue(null);}
                return true;
            }
        });
        """.replace('WEBVAR',var)
 src=src[:line.start()]+chooser+src[line.start():]
 action="""if (requestCode == 6910 && csvFileCallback != null) {
            android.webkit.ValueCallback<android.net.Uri[]> pending=csvFileCallback;
            csvFileCallback=null;
            pending.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(resultCode,data));
            return;
        }"""
 m=re.search(r'\bonActivityResult\s*\([^)]*\)\s*\{',src)
 if m: src=src[:m.end()]+'\n        '+action+'\n'+src[m.end():]
 else:
  pos=src.rfind('}')
  src=src[:pos]+'\n    @Override protected void onActivityResult(int requestCode,int resultCode,android.content.Intent data) {\n        super.onActivityResult(requestCode,resultCode,data);\n        '+action+'\n    }\n'+src[pos:]
 pos=src.rfind('}')
 src=src[:pos]+'\n    private android.webkit.ValueCallback<android.net.Uri[]> csvFileCallback;\n'+src[pos:]
 p.write_text(src,encoding='utf-8')
print('CSV file picker added to original v1.3.10 Java source')

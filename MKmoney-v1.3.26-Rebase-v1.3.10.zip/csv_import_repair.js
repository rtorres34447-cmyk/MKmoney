(() => {
  if (window.__mkmoneyCsvRepair) return; window.__mkmoneyCsvRepair = true;
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function parseCSV(t){
    t=t.replace(/^\uFEFF/,''); let rows=[],r=[],v='',quoted=false;
    for(let i=0;i<t.length;i++){let c=t[i];if(c==='"'){if(quoted&&t[i+1]==='"'){v+='"';i++;}else quoted=!quoted;}
      else if(c===','&&!quoted){r.push(v.trim());v='';}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&t[i+1]==='\n')i++;r.push(v.trim());if(r.some(x=>x!==''))rows.push(r);r=[];v='';}
      else v+=c;}
    if(quoted)throw Error('Unclosed quotation mark in CSV');r.push(v.trim());if(r.some(x=>x!==''))rows.push(r);return rows;
  }
  let norm=s=>String(s??'').toLowerCase().replace(/[^a-z0-9]/g,'');
  function locate(headers,names){return headers.findIndex(h=>names.includes(norm(h)));}
  function getCandidates(){
    let out=[];
    for(let k of Object.keys(localStorage)){
      let src=localStorage.getItem(k);if(!src||src[0]!=='{'&&src[0]!=='[')continue;
      let doc;try{doc=JSON.parse(src);}catch{continue;}
      function walk(v,path,depth){if(depth>3)return;if(Array.isArray(v)){
        let sample=v.find(x=>x&&typeof x==='object'&&!Array.isArray(x));
        if(sample){let keys=Object.keys(sample),amt=keys.find(x=>/^(amount|cost|value|price)$/i.test(x)),title=keys.find(x=>/^(name|title|bill|description|label|merchant)$/i.test(x));
          if(amt&&title)out.push({storageKey:k,path:[...path],sample,amt,title,count:v.length,score:(/mk|bill|expense|payment|money/i.test(k)?4:0)+(/bill|entries|payments|records|expenses/i.test(path.join('.'))?4:0)});}
      }else if(v&&typeof v==='object')for(let [p,x] of Object.entries(v))if(x&&typeof x==='object')walk(x,[...path,p],depth+1);}
      walk(doc,[],0);
    }
    return out.sort((a,b)=>b.score-a.score);
  }
  function value(r,h,names){let i=locate(h,names);return i<0?'':r[i]??'';}
  function dateFmt(v){v=String(v??'').trim();if(!v)return '';
    if(/^\d{4}-\d{2}-\d{2}/.test(v))return v.slice(0,10);
    let m=v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);return m?`${m[3]}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`:v;
  }
  function assignMatching(entry,sample,tests,v){for(const k of Object.keys(sample))if(tests.test(k))entry[k]=v;}
  function amount(v){return Number(String(v).replace(/[$,\s]/g,''));}
  function makeEntry(row,h,c){let sample=c.sample,e={};for(let [k,v] of Object.entries(sample)){
      if(/^(id|uuid|key)$/i.test(k))continue;
      if(/^(paid|archived|deleted|completed)$/i.test(k)){e[k]=false;continue;}
      if(typeof v==='boolean')e[k]=false;
      else if(typeof v==='number')e[k]=0;
      else if(typeof v==='string')e[k]='';
      else if(Array.isArray(v))e[k]=[];
      else e[k]=v===null?null:{};
    }
    let name=value(row,h,['bill','name','description','item','title','merchant','billname']);
    let amt=amount(value(row,h,['amount','cost','value','price','total','payment']));
    if(!name||!Number.isFinite(amt))throw Error('A row is missing a bill name or valid amount');
    e[c.title]=name;e[c.amt]=amt;
    const due=dateFmt(value(row,h,['date','duedate','due','paymentdate','nextdue','nextdate']));
    if(due)assignMatching(e,sample,/^(due|date|dueDate|nextDue|paymentDate)$/i,due);
    const owner=value(row,h,['person','owner','member','assignedto','paidby']);
    if(owner)assignMatching(e,sample,/^(person|owner|member|paidBy|assignedTo)$/i,owner);
    const bank=value(row,h,['bank','account','sourcebank','bankaccount']);
    if(bank)assignMatching(e,sample,/^(bank|account|sourceBank|bankAccount)$/i,bank);
    const freq=value(row,h,['frequency','repeat','recurrence','interval','cycle']);
    if(freq)assignMatching(e,sample,/^(frequency|repeat|recurrence|interval|cycle)$/i,freq);
    if('id' in sample)e.id=(globalThis.crypto?.randomUUID?.() || `import-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    if('uuid' in sample)e.uuid=(globalThis.crypto?.randomUUID?.() || `import-${Date.now()}-${Math.random().toString(36).slice(2)}`);
    return e;
  }
  function mount(){
    if(document.getElementById('mkcsv-import-button'))return;
    let btn=document.createElement('button');btn.id='mkcsv-import-button';btn.textContent='Import CSV';
    Object.assign(btn.style,{position:'fixed',bottom:'22px',right:'16px',zIndex:'2147483646',padding:'12px 18px',border:'1px solid #66d8ef',borderRadius:'12px',background:'#102b36',color:'white',fontWeight:'bold',boxShadow:'0 5px 25px #0008'});
    document.body.appendChild(btn);
    btn.onclick=()=>{let f=document.createElement('input');f.type='file';f.accept='.csv,text/csv,text/plain';f.onchange=async()=>{
      if(!f.files?.length)return;let t=await f.files[0].text();let rows;
      try{rows=parseCSV(t);}catch(e){alert('CSV error: '+e.message);return;}
      if(rows.length<2){alert('CSV has no data rows.');return;}
      let h=rows[0],candidates=getCandidates();if(!candidates.length){alert('Could not identify a compatible MKmoney bill list in saved app data. No data changed. Please send the CSV and source so the importer can be adapted safely.');return;}
      let candidate=candidates[0];let content=rows.slice(1).filter(r=>r.some(v=>v));let entries=[];
      try{entries=content.map(r=>makeEntry(r,h,candidate));}catch(e){alert('CSV validation: '+e.message+'. No data changed.');return;}
      let summary=`Import ${entries.length} bills from ${f.files[0].name}?\n\nDestination: ${candidate.storageKey} (${candidate.path.join('.')||'root'})\nExisting: ${candidate.count}\n\nFirst 3:\n${entries.slice(0,3).map(x=>x[candidate.title]+' — $'+x[candidate.amt]).join('\n')}\n\nAn automatic backup will be saved before import. Cancel if this is not your bill list.`;
      if(!confirm(summary))return;
      try{let key=candidate.storageKey,raw=localStorage.getItem(key),doc=JSON.parse(raw),arr=doc;
        for(let p of candidate.path)arr=arr[p];if(!Array.isArray(arr))throw Error('Bill list changed');
        localStorage.setItem(`MKMONEY_CSV_BACKUP_${Date.now()}_${key}`,raw);
        arr.push(...entries);localStorage.setItem(key,JSON.stringify(doc));
        alert(`${entries.length} bills imported. MKmoney will now reload.`);location.reload();
      }catch(e){alert('Import failed without overwriting your existing list: '+e.message);}
    };f.click();};
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();
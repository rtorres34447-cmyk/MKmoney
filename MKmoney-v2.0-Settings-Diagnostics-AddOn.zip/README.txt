MKmoney Widget Settings diagnostics add-on
- This patch moves access to the existing Sync widget control into Settings and provides a screenshot-friendly diagnostic panel.
- It does NOT claim to repair the underlying native WebView bridge. The diagnostics distinguish sync requested from widget receipt confirmed.
- Applies to existing assembled MKmoney source using app/src/main/assets/index.html.
- Use the separate GitHub Actions workflow provided alongside this ZIP.

#!/usr/bin/env python3
"""Preserve MKmoney app and add widget sync + screenshot diagnostics into Settings."""
from pathlib import Path
import sys, re
root=Path(sys.argv[1]).resolve()
html=root/'app/src/main/assets/index.html'
if not html.is_file(): raise RuntimeError('Expected MKmoney app/src/main/assets/index.html is missing')
s=html.read_text(encoding='utf-8')
if 'mkmoney-widget-diagnostic-settings-v21' in s:
 print('Settings diagnostics already installed');sys.exit(0)
# Only add to an existing MKmoney page. Avoid replacing its dashboard, settings or stored data.
if not all(token in s.lower() for token in ('settings','dashboard')): raise RuntimeError('Not an MKmoney dashboard/settings document')
js=r'''<script id="mkmoney-widget-diagnostic-settings-v21">
(function(){
'use strict';
const ID='mk-widget-tools-v21';
const stamp=()=>new Date().toLocaleString();
let log=[];
const record=(name,state,detail)=>{log.unshift({time:stamp(),name,state,detail:String(detail||'')});log=log.slice(0,18);render();};
const bridgeList=()=>Object.keys(window).filter(k=>/widget|bridge|android|native/i.test(k)&&!/^webkit$/i.test(k)).filter(k=>{try{return typeof window[k]==='object'||typeof window[k]==='function'}catch(e){return false}});
const buttons=()=>Array.from(document.querySelectorAll('button,[role="button"],a'));
function syncButton(){return buttons().find(e=>e.id!=='mk-settings-sync-v21'&&e.closest('#'+ID)==null&&/sync\s*widget/i.test((e.innerText||e.textContent||'').trim()));}
function isSettingsVisible(){
 let tab=Array.from(document.querySelectorAll('button,[role="tab"],a')).find(e=>/^\s*(?:⚙\s*)?settings\s*$/i.test((e.innerText||e.textContent||'').trim()) && e.offsetParent!==null);
 let active=Array.from(document.querySelectorAll('[id],[class]')).some(e=>e.offsetParent!==null&&/settings/i.test((e.id||'')+' '+(typeof e.className==='string'?e.className:''))&& e.querySelector('input,select,button'));
 return active || (!!tab&&/settings/i.test(location.hash));
}
function getSettingsContainer(){
 const candidates=Array.from(document.querySelectorAll('section,main,div,article'))
 .filter(e=>e.id!==ID&&e.offsetParent!==null&&/settings/i.test((e.id||'')+' '+(typeof e.className==='string'?e.className:''))&&e.querySelectorAll('button,input,select').length>0);
 candidates.sort((a,b)=>a.querySelectorAll('*').length-b.querySelectorAll('*').length);
 if(candidates.length)return candidates[0];
 const heads=Array.from(document.querySelectorAll('h1,h2,h3,h4')).filter(e=>e.offsetParent!==null&&/settings/i.test(e.textContent||''));
 if(heads.length)return heads[0].parentElement;
 return null;
}
function getDataSummary(){
 const ls=[];let matched=[];
 try{for(let i=0;i<localStorage.length;i++){let key=localStorage.key(i);ls.push(key);if(/bill|payment|mkmoney|finance/i.test(key)){
 try{let v=JSON.parse(localStorage.getItem(key));let count=Array.isArray(v)?v.length:(v&&typeof v==='object'?Object.keys(v).length:0);matched.push(key+' ('+count+' top-level entries)')}catch(e){matched.push(key+' (non-JSON)')}
 }}}catch(e){return 'Storage error: '+e.message}
 return matched.length?matched.join(', '):'No payment-related localStorage keys found ('+ls.length+' keys total; data may be in IndexedDB or elsewhere)';
}
function report(){return ['MKmoney Widget Diagnostics', 'Time: '+stamp(),'Location: Settings','Page: '+location.pathname,'Native bridge names: '+(bridgeList().join(', ')||'none found'), 'Storage summary: '+getDataSummary(),...log.map(x=>x.time+' | '+x.name+' | '+x.state+' | '+x.detail)].join('\n')}
function render(){const target=document.getElementById('mk-widget-status-v21');if(!target)return;
 target.textContent=log.length?log.map(x=>x.name+': '+x.state+(x.detail?' — '+x.detail:'' )).join('\n'):'Not tested yet. Press Run diagnostics.';
 const pre=document.getElementById('mk-widget-report-v21');if(pre)pre.textContent=report();}
function run(){const bridges=bridgeList();record('Page loaded','PASS','Settings diagnostics JavaScript active');
 record('Native bridge discovery',bridges.length?'FOUND':'UNAVAILABLE',bridges.join(', ')||'No bridge name exposed on window');
 let native=bridges.filter(k=>/android|widget|native|bridge/i.test(k));
 for(const k of native.slice(0,8)){let methods=[];try{methods=Object.keys(window[k]).filter(m=>typeof window[k][m]==='function')}catch(e){methods=['inaccessible']}record('Bridge '+k,'INSPECTED',methods.join(', ')||'No enumerable functions (Java bridge methods may be non-enumerable)')}
 record('App financial storage','INSPECTED',getDataSummary());
 const b=syncButton();record('Original Sync widget control',b?'FOUND':'NOT FOUND',b?'Present in document':'May be absent from this build');
 record('Widget receipt','NOT VERIFIED','Only the Android widget can confirm it received actual payments');
}
function mount(){
 let anchor=getSettingsContainer();let panel=document.getElementById(ID);
 if(!anchor){if(panel)panel.style.display='none';return}
 if(!panel){panel=document.createElement('details');panel.id=ID;panel.style.cssText='margin:18px 0;padding:15px;border-radius:16px;border:1px solid #4b6587;background:#132137;color:#dce8fb;font:14px system-ui,sans-serif;line-height:1.5';
 panel.innerHTML='<summary style="cursor:pointer;font-size:17px;font-weight:700;color:#91dcd5">Widget Diagnostics &amp; Sync</summary><p style="margin:12px 0;color:#b6c8df">Screenshottable test results. No bill values or private payment details are displayed.</p><div style="display:flex;flex-wrap:wrap;gap:8px;margin:10px 0"><button type="button" id="mk-settings-sync-v21">Sync widget</button><button type="button" id="mk-widget-run-v21">Run diagnostics</button><button type="button" id="mk-widget-copy-v21">Copy report</button></div><pre id="mk-widget-status-v21" style="white-space:pre-wrap;overflow-wrap:anywhere;color:#dce8fb"></pre><details><summary>Full diagnostic report</summary><pre id="mk-widget-report-v21" style="white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px"></pre></details>';
 panel.querySelectorAll('button').forEach(b=>b.style.cssText='background:#29456b;border:1px solid #6487b5;border-radius:9px;padding:9px 12px;color:#fff;cursor:pointer');
 panel.querySelector('#mk-widget-run-v21').addEventListener('click',run);
 panel.querySelector('#mk-widget-copy-v21').addEventListener('click',()=>{const value=report();if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(value).then(()=>record('Copy report','PASS','Copied to clipboard'),e=>record('Copy report','FAILED',e.message))}else{record('Copy report','UNAVAILABLE','Use screenshot or select text from report')}});
 panel.querySelector('#mk-settings-sync-v21').addEventListener('click',()=>{const b=syncButton();if(!b){record('Manual sync','FAILED','Original native-sync control not found');return}try{b.click();record('Manual sync','REQUESTED','Original MKmoney Sync widget control clicked; widget receipt not confirmed')}catch(e){record('Manual sync','FAILED',e.message)}});
 anchor.appendChild(panel);render();
 }else if(panel.parentElement!==anchor)anchor.appendChild(panel);
 if(panel.style.display==='none')panel.style.display='';
 const old=syncButton();if(old && !old.hasAttribute('data-mk-hidden-v21')){old.setAttribute('data-mk-hidden-v21','1');old.style.setProperty('display','none','important');}
}
let busy=false;function refresh(){if(busy)return;busy=true;try{mount()}finally{busy=false}}
const obs=new MutationObserver(()=>{if(!busy)refresh()});
function start(){refresh();obs.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class','hidden']});document.addEventListener('click',()=>setTimeout(refresh,0),true)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
</script>'''
if '</body>' not in s.lower():raise RuntimeError('Missing closing HTML body tag')
s=re.sub(r'</body>',lambda m:js+'\n'+m.group(),s,count=1,flags=re.I)
html.write_text(s,encoding='utf-8')
print('Added Settings widget diagnostic panel; preserved original page and Android source')

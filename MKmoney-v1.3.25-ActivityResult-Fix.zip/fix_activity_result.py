from pathlib import Path
import re,sys
root=Path(sys.argv[1]); path=root/'app/src/main/java/com/mkmoney/app/MainActivity.java'
s=path.read_text(encoding='utf-8')
# v1.3.22 appended a second onActivityResult, but the original activity has its own.
pat=r'(?m)^[ \t]*@Override[ \t]+protected[ \t]+void[ \t]+onActivityResult\s*\(\s*int\s+requestCode\s*,\s*int\s+resultCode\s*,\s*(?:android\.content\.)?Intent\s+data\s*\)\s*\{'
methods=list(re.finditer(pat,s))
if len(methods)!=2:
 raise SystemExit(f'Expected exactly two onActivityResult methods after prior patches; found {len(methods)}. No changes made.')
def endbrace(code,start):
 depth=0;state='normal';i=start
 while i<len(code):
  c=code[i]; n=code[i+1] if i+1<len(code) else ''
  if state=='normal':
   if c=='/' and n=='/':state='line';i+=2;continue
   if c=='/' and n=='*':state='block';i+=2;continue
   if c in ('"',"'"):state=c
   if c=='{':depth+=1
   if c=='}':
    depth-=1
    if depth==0:return i+1
  elif state=='line':
   if c=='\n':state='normal'
  elif state=='block':
   if c=='*' and n=='/':state='normal';i+=2;continue
  else:
   if c=='\\':i+=2;continue
   if c==state:state='normal'
  i+=1
 raise SystemExit('Unbalanced Java braces')
# Only remove the exact handler installed by v1.3.22; do not remove the original logic.
new=[m for m in methods if 'mkmoneyPendingFile' in s[m.end():endbrace(s,m.end()-1)]]
if len(new)!=1:raise SystemExit('Could not uniquely identify patch-added onActivityResult')
added=new[0]; original=next(m for m in methods if m!=added)
newbody=s[added.end():endbrace(s,added.end()-1)]
if '6422' not in newbody or 'FileChooserParams.parseResult' not in newbody:
 raise SystemExit('Unexpected patch-added handler; refusing to remove')
remove_start=added.start();remove_end=endbrace(s,added.end()-1)
s=s[:remove_start]+s[remove_end:]
# Insert own request-code-specific handling into preexisting method.
methods=list(re.finditer(pat,s))
if len(methods)!=1:raise SystemExit('Duplicate removal check failed')
orig=methods[0];opening=orig.end()
if 'mkmoneyPendingFile' in s[opening:endbrace(s,opening-1)]:
 raise SystemExit('Existing method already manages this callback; refusing duplication')
insert="""
        if (requestCode == 6422) {
            if (mkmoneyPendingFile != null) {
                android.webkit.ValueCallback<android.net.Uri[]> callback = mkmoneyPendingFile;
                mkmoneyPendingFile = null;
                callback.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            }
            return;
        }
"""
s=s[:opening]+insert+s[opening:]
if len(list(re.finditer(pat,s)))!=1:raise SystemExit('Postcondition: duplicate still exists')
path.write_text(s,encoding='utf-8')
print('Merged CSV chooser result into existing onActivityResult; kept original handling for other request codes.')

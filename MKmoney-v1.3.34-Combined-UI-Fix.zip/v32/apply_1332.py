from pathlib import Path
import sys,re
root=Path(sys.argv[1])
html=root/'app/src/main/assets/index.html'
if not html.is_file():raise SystemExit('Missing index.html')
s=html.read_text(encoding='utf-8')
if '__mk1332Installed' in s:
    raise SystemExit('v1.3.32 already applied')
if not re.search('</body>',s,re.I): raise SystemExit('No HTML body end')
code=Path(__file__).with_name('week_cards_1332.js').read_text(encoding='utf-8')
s=re.sub('</body>',lambda m:'\n<script>\n'+code+'\n</script>\n'+m.group(0),s,count=1,flags=re.I)
html.write_text(s,encoding='utf-8')
print('Installed card-header folding controls. No changes to CSV, Java or original logo.')

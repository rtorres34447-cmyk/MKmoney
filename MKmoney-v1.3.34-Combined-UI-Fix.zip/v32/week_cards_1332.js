
/* MKmoney v1.3.32: attach folding button to ACTUAL workweek/weekend card headers. */
(function(){
  'use strict';
  if(window.__mk1332Installed) return;
  window.__mk1332Installed = true;
  const periodRE=/^(?:work\s*week\s*[·•:-]?\s*(?:mon\s*[–-]\s*fri)?|weekend\s*[·•:-]?\s*(?:sat\s*[–-]\s*sun)?)/i;
  const datedRE=/\b(\d{1,2})\s+([A-Za-z]{3,9})\s+(\d{4})\b/g;
  const months={jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,oct:9,nov:10,dec:11};
  const state=window.__mk1332State||(window.__mk1332State={});
  const dateOf=(str)=>{
    let m=[...str.matchAll(datedRE)];
    return m.map(x=>new Date(+x[3],months[x[2].slice(0,3).toLowerCase()],+x[1],12))
      .filter(x=>!isNaN(x.getTime()));
  };
  function titleOf(e){
    if(e.matches('button,input,select,textarea,a'))return '';
    const own=[...e.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join(' ').trim();
    const label=(own || (e.children.length===0?e.textContent:'')).replace(/\s+/g,' ').trim();
    return label.length<150 && periodRE.test(label) && /20\d\d/.test(label)?label:'';
  }
  const within=(a,b,d)=>d>=a && d<=b;
  const current=(label)=>{
    const ds=dateOf(label), now=new Date();
    now.setHours(12,0,0,0);
    return ds.length>=2 && within(ds[0],ds[1],now);
  };
  function install(){
    let attached=0;
    const nodes=[...document.querySelectorAll('h1,h2,h3,h4,h5,div,span,strong,b,p')];
    for(const heading of nodes){
      const title=titleOf(heading);
      if(!title || heading.closest('[data-mk1332-card]'))continue;
      // Find the smallest enclosing card with bill rows outside its header.
      // This exactly matches the screenshot: date + total header; "Due ..." item rows.
      let card=null, header=null;
      for(let ancestor=heading.parentElement,level=0;ancestor && level<6;ancestor=ancestor.parentElement,level++){
        if(ancestor===document.body)break;
        const children=[...ancestor.children];
        if(children.length<2)continue;
        const headerChild=children.find(c=>c===heading||c.contains(heading));
        const rows=children.filter(c=>c!==headerChild);
        if(!headerChild||!rows.length)continue;
        if(!rows.some(c=>/\bDue\s+\d{1,2}\s+[A-Za-z]{3}/i.test(c.textContent)))continue;
        // Do not accidentally fold a container containing other weekly cards.
        if(rows.some(c=>/\b(?:Work\s*week|Weekend)\s*[·•:-]\s*(?:Mon|Sat)/i.test(c.textContent)))continue;
        card=ancestor;header=headerChild;break;
      }
      if(!card||!header)continue;
      card.dataset.mk1332Card='1';
      const dates=dateOf(title);
      const key=dates.length>=2?`${dates[0].toISOString().slice(0,10)}_${dates[1].toISOString().slice(0,10)}`:title;
      const billRows=[...card.children].filter(c=>c!==header);
      const button=document.createElement('button');
      button.type='button';button.className='mk1332-toggle';
      button.style.cssText='display:inline-flex!important;align-items:center;justify-content:center;min-height:38px;margin:8px 0 2px;padding:7px 12px;border:1px solid #7c91ac;border-radius:9px;background:#223349;color:#f0f6ff;font-weight:700;font-size:14px;cursor:pointer;';
      header.appendChild(button);
      const setOpen=(v)=>{
        state[key]=!!v;
        button.textContent=v?'− Minimise':'+ Expand';
        button.setAttribute('aria-expanded',String(v));
        for(const row of billRows){
          if(v)row.style.removeProperty('display');
          else row.style.setProperty('display','none','important');
        }
      };
      button.addEventListener('click',event=>{
        event.preventDefault();event.stopPropagation();setOpen(!state[key]);
      });
      if(typeof state[key]!=='boolean')state[key]=current(title);
      setOpen(state[key]);
      attached++;
    }
    return attached;
  }
  let scheduled=false;
  const scan=()=>{scheduled=false;install()};
  const queue=()=>{if(!scheduled){scheduled=true;setTimeout(scan,100)}};
  const start=()=>{
    install();
    new MutationObserver(list=>{
      if(list.every(x=>x.target.closest?.('[data-mk1332-card]')&&
        [...x.addedNodes].every(n=>n.nodeType!==1||n.matches?.('.mk1332-toggle'))))return;
      queue();
    }).observe(document.body,{childList:true,subtree:true});
    setInterval(queue,30000);
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();

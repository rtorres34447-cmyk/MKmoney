MKmoney Widget Test — independent diagnostic APK

This is a stand-alone Android app and widget, not a patch to your existing MKmoney installation. It does not read, replace or modify financial data.

Upload the ZIP to your MKmoney repository root, and upload the accompanying YAML to .github/workflows/widget-diagnostic.yml. Run the workflow in GitHub Actions (or push the workflow to main). Download the resulting APK artifact.

Install the APK, then long-press your Android home screen > Widgets > MKmoney Widget Test.
Test 1: Tap day 10, then 17. Selected day must change without the app launching.
Test 2: Press SYNC twice. Sync requests received should increment by 2 without the app launching.
If both pass, Android's broadcast click system works and the integration problem is in MKmoney data and provider wiring.

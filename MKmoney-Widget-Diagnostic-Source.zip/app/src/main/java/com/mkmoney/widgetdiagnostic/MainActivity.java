package com.mkmoney.widgetdiagnostic;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) { super.onCreate(b); TextView t=new TextView(this);t.setText("MKmoney native widget diagnostic\n\nAdd the 'MKmoney Widget Test' widget to your home screen.\n\nTap a date: the Selected day must change without opening this app.\nTap SYNC: the Sync count must increase without opening this app.\n\nThis test uses dummy data and cannot change your MKmoney bills.");t.setTextSize(18);t.setPadding(35,55,35,20);setContentView(t); }
}
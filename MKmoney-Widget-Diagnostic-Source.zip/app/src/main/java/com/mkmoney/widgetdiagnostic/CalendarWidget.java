package com.mkmoney.widgetdiagnostic;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;
import java.util.Calendar;
import java.util.Locale;

public class CalendarWidget extends AppWidgetProvider {
 private static final String DATE="com.mkmoney.widgetdiagnostic.DATE", SYNC="com.mkmoney.widgetdiagnostic.SYNC";
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids) {for(int id:ids) render(c,m,id);}
 @Override public void onReceive(Context c,Intent i) {
  super.onReceive(c,i);
  String a=i.getAction(); if(!DATE.equals(a)&&!SYNC.equals(a))return;
  SharedPreferences p=c.getSharedPreferences("diagnostics",0); SharedPreferences.Editor e=p.edit();
  if(DATE.equals(a))e.putInt("day",i.getIntExtra("day",1));
  if(SYNC.equals(a))e.putInt("sync",p.getInt("sync",0)+1);
  e.apply();
  AppWidgetManager m=AppWidgetManager.getInstance(c);
  int[] ids=m.getAppWidgetIds(new ComponentName(c,CalendarWidget.class));
  for(int id:ids)render(c,m,id);
 }
 private static PendingIntent click(Context c,String action,int day){
  Intent i=new Intent(c,CalendarWidget.class);i.setAction(action);i.putExtra("day",day);
  int code=SYNC.equals(action)?100:200+day;
  return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 private static void render(Context c,AppWidgetManager m,int id){
  SharedPreferences p=c.getSharedPreferences("diagnostics",0);
  Calendar now=Calendar.getInstance();int month=now.get(Calendar.MONTH),year=now.get(Calendar.YEAR),today=now.get(Calendar.DAY_OF_MONTH);
  int selected=p.getInt("day",today);
  Calendar first=Calendar.getInstance();first.set(year,month,1);
  int offset=(first.get(Calendar.DAY_OF_WEEK)+5)%7; // Monday-first
  int count=first.getActualMaximum(Calendar.DAY_OF_MONTH);
  RemoteViews r=new RemoteViews(c.getPackageName(),R.layout.widget_layout);
  r.setTextViewText(R.id.title,String.format(Locale.getDefault(),"MKmoney · %tB %tY",first,first));
  r.setOnClickPendingIntent(R.id.sync,click(c,SYNC,0));
  String[] labels={"M","T","W","T","F","S","S"};r.removeAllViews(R.id.weekdays);
  for(String s:labels){RemoteViews cell=new RemoteViews(c.getPackageName(),R.layout.day_cell);cell.setTextViewText(R.id.day,s);r.addView(R.id.weekdays,cell);}
  int[] rows={R.id.week0,R.id.week1,R.id.week2,R.id.week3,R.id.week4,R.id.week5};
  for(int row=0;row<6;row++){r.removeAllViews(rows[row]);for(int col=0;col<7;col++){
   int d=row*7+col-offset+1;RemoteViews cell=new RemoteViews(c.getPackageName(),R.layout.day_cell);
   if(d>0&&d<=count){cell.setTextViewText(R.id.day,Integer.toString(d));cell.setInt(R.id.day,"setBackgroundColor",d==selected?Color.rgb(30,124,149):Color.TRANSPARENT);cell.setOnClickPendingIntent(R.id.day,click(c,DATE,d));}
   else cell.setTextViewText(R.id.day,"");
   r.addView(rows[row],cell);
  }}
  r.setTextViewText(R.id.status,"Selected day: "+selected+" · Date click: OK");
  r.setTextViewText(R.id.counter,"Sync requests received: "+p.getInt("sync",0));
  m.updateAppWidget(id,r);
 }
}
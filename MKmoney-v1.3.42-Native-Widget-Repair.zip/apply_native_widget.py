#!/usr/bin/env python3
"""MKmoney native widget bridge overlay. Fails safely if original app structure is unexpected."""
from pathlib import Path
import re,sys
root=Path(sys.argv[1]); app=root/'app/src/main'
manifest=app/'AndroidManifest.xml'; assert manifest.exists(), 'AndroidManifest missing'
javas=list((app/'java').rglob('*.java')); assert javas, 'Java app sources missing'
providers=[p for p in javas if re.search(r'extends\s+AppWidgetProvider\b',p.read_text(errors='replace'))]
assert len(providers)==1, f'Expected exactly one existing calendar widget provider; found {len(providers)}: {providers}'
provider=providers[0]; old=provider.read_text(); pkg=re.search(r'\bpackage\s+([\w.]+)\s*;',old).group(1); cls=provider.stem
activities=[p for p in javas if p.name=='MainActivity.java']; assert len(activities)==1, 'MainActivity.java not found'
activity=activities[0]; main=activity.read_text(); apkg=re.search(r'\bpackage\s+([\w.]+)\s*;',main).group(1)
# Locate actual webview load call, so bridge exists before HTML initialisation.
loads=re.findall(r'\b([a-zA-Z_]\w*)\.loadUrl\s*\(',main)
assert loads, 'No WebView.loadUrl invocation: refusing unsafe modification'
webview=loads[0]
if 'MKmoneyNativeSync' not in main:
    main=main.replace(webview+'.loadUrl(',webview+'.addJavascriptInterface(new MKNativeSyncBridge(this), "MKmoneyNativeSync");\n        '+webview+'.loadUrl(',1)
    main=main.replace('import android.', 'import android.', 1)
    if apkg!=pkg: main=main.replace('import ',f'import {pkg}.MKNativeSyncBridge;\nimport ',1)
    activity.write_text(main)
bridge=provider.parent/'MKNativeSyncBridge.java'
bridge.write_text(f'''package {pkg};

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;

public class MKNativeSyncBridge {{
 private final Context context;
 public MKNativeSyncBridge(Context ctx) {{ context = ctx.getApplicationContext(); }}
 @JavascriptInterface public void sync(String snapshot) {{
   if (snapshot == null || snapshot.length() > 2000000) return;
   context.getSharedPreferences("mkmoney_native_widget", Context.MODE_PRIVATE).edit().putString("snapshot",snapshot).apply();
   Intent intent = new Intent(context, {cls}.class);
   intent.setAction("mkmoney.widgets.REFRESH");
   context.sendBroadcast(intent);
 }}
}}
''')
provider.write_text(f'''package {pkg};

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class {cls} extends AppWidgetProvider {{
 private static final String SELECT="mkmoney.widgets.SELECT",PREV="mkmoney.widgets.PREV",NEXT="mkmoney.widgets.NEXT",SYNC="mkmoney.widgets.REFRESH";
 private static final String PREF="mkmoney_native_widget";
 private static final int[] DAYS = new int[] {{{', '.join('R.id.mk_day_'+str(i) for i in range(42))}}};
 @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){{super.onUpdate(c,manager,ids); for(int id:ids) draw(c,manager,id);}}
 @Override public void onReceive(Context c,Intent i){{super.onReceive(c,i);String a=i.getAction(); if(SELECT.equals(a)||PREV.equals(a)||NEXT.equals(a)||SYNC.equals(a)){{int id=i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1); if(PREV.equals(a)||NEXT.equals(a)){{String key="offset_"+id;int current=c.getSharedPreferences(PREF,0).getInt(key,0);c.getSharedPreferences(PREF,0).edit().putInt(key,current+(PREV.equals(a)?-1:1)).apply();}}if(SELECT.equals(a)) c.getSharedPreferences(PREF,0).edit().putString("selected_"+id,i.getStringExtra("date")).apply();AppWidgetManager m=AppWidgetManager.getInstance(c);if(id<0){{for(int n:m.getAppWidgetIds(new android.content.ComponentName(c,{cls}.class)))draw(c,m,n);}}else draw(c,m,id);}}}}
 private static PendingIntent pending(Context c,int widget,String action,String date,int code){{Intent i=new Intent(c,{cls}.class);i.setAction(action);i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,widget);if(date!=null)i.putExtra("date",date);i.setData(android.net.Uri.parse("mkmoney://"+widget+"/"+action+"/"+(date==null?"":date)));return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}}
 private static String pick(JSONObject o,String...names){{for(String name:names){{for(String k:o.keySet()){{if(k.equalsIgnoreCase(name)){{Object v=o.opt(k);if(v!=null&&!JSONObject.NULL.equals(v))return String.valueOf(v);}}}}}}return "";}}
 private static Double amount(String s){{try{{return Double.parseDouble(s.replaceAll("[^0-9.-]",""));}}catch(Exception e){{return null;}}}}
 private static String normalizeDate(String date){{try{{if(date.matches("\\\\d{{4}}-\\\\d{{2}}-\\\\d{{2}}.*"))return date.substring(0,10);if(date.matches("\\\\d{{2}}/\\\\d{{2}}/\\\\d{{4}}")){{String[] p=date.split("/");return p[2]+"-"+p[1]+"-"+p[0];}}}}catch(Exception ignored){{}}return "";}}
 private static void scan(Object node,String day,ArrayList<String> out,Set<String> seen,int depth){{
  if(depth>12||out.size()>=25||node==null)return;
  if(node instanceof JSONObject){{JSONObject o=(JSONObject)node;String date=normalizeDate(pick(o,"dueDate","due","date","paymentDate","nextDate","startDate"));
   String title=pick(o,"name","title","billName","merchant","description","label");String money=pick(o,"amount","cost","value","price","payment","total");
   if(day.equals(date)&&!title.isEmpty()&&!money.isEmpty()){{Double n=amount(money);if(n!=null){{String row=title+"  $"+String.format(Locale.US,"%.2f",n);if(seen.add(row))out.add(row);}}}}
   for(String key:o.keySet())scan(o.opt(key),day,out,seen,depth+1);
  }}else if(node instanceof JSONArray){{JSONArray a=(JSONArray)node;for(int j=0;j<a.length();j++)scan(a.opt(j),day,out,seen,depth+1);}}
  else if(node instanceof String){{String s=(String)node;if(s.length()>1 &&(s.startsWith("{{")||s.startsWith("[")))try{{scan(s.startsWith("{{")?new JSONObject(s):new JSONArray(s),day,out,seen,depth+1);}}catch(Exception ignored){{}}}}
 }}
 private static ArrayList<String> payments(Context c,String day){{ArrayList<String> out=new ArrayList<>();try{{String raw=c.getSharedPreferences(PREF,0).getString("snapshot","{{}}");scan(new JSONObject(raw),day,out,new HashSet<String>(),0);}}catch(Exception ignored){{}}return out;}}
 private static void draw(Context c,AppWidgetManager manager,int widget){{try{{
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.mk_native_month_widget);
  int offset=c.getSharedPreferences(PREF,0).getInt("offset_"+widget,0);YearMonth month=YearMonth.now().plusMonths(offset);
  v.setTextViewText(R.id.mk_month_title,month.getMonth().getDisplayName(java.time.format.TextStyle.FULL,Locale.ENGLISH)+" "+month.getYear());
  v.setOnClickPendingIntent(R.id.mk_prev,pending(c,widget,PREV,null,100));v.setOnClickPendingIntent(R.id.mk_next,pending(c,widget,NEXT,null,101));v.setOnClickPendingIntent(R.id.mk_sync,pending(c,widget,SYNC,null,102));
  LocalDate start=month.atDay(1);int leading=start.getDayOfWeek().getValue()-1;LocalDate first=start.minusDays(leading);
  String selected=c.getSharedPreferences(PREF,0).getString("selected_"+widget,LocalDate.now().toString());
  for(int k=0;k<42;k++){{LocalDate d=first.plusDays(k);String iso=d.toString();v.setTextViewText(DAYS[k],String.valueOf(d.getDayOfMonth()));v.setTextColor(DAYS[k],d.getMonthValue()==month.getMonthValue()?Color.WHITE:0xFF8791A7);v.setInt(DAYS[k],"setBackgroundColor",iso.equals(selected)?0x995E35B1:Color.TRANSPARENT);v.setOnClickPendingIntent(DAYS[k],pending(c,widget,SELECT,iso,200+k));}}
  ArrayList<String> entries=payments(c,selected);StringBuilder content=new StringBuilder(selected+" · ");if(entries.isEmpty())content.append("No synced payments for this date");else{{for(String e:entries){{if(content.length()>1000)break;content.append("\\n").append(e);}}}}
  v.setTextViewText(R.id.mk_day_details,content.toString());manager.updateAppWidget(widget,v);
 }}catch(Exception ex){{android.util.Log.e("MKmoneyWidget","draw",ex);}}}}
}}
''')
res=app/'res'; (res/'layout').mkdir(parents=True,exist_ok=True)
rows=[]
for r in range(6):
    days='\n'.join(f'<TextView android:id="@+id/mk_day_{r*7+c}" android:layout_width="0dp" android:layout_weight="1" android:layout_height="42dp" android:gravity="center" android:textColor="#ffffff" android:textSize="12sp" android:clickable="true" />' for c in range(7))
    rows.append('<LinearLayout android:orientation="horizontal" android:layout_width="match_parent" android:layout_height="wrap_content">'+days+'</LinearLayout>')
xml='''<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent" android:padding="9dp" android:orientation="vertical" android:background="#66121B32">
 <LinearLayout android:orientation="horizontal" android:layout_width="match_parent" android:layout_height="36dp" android:gravity="center_vertical">
 <TextView android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:text="MKmoney" android:textColor="#ffffff" android:textSize="13sp" />
 <TextView android:id="@+id/mk_sync" android:layout_width="wrap_content" android:layout_height="wrap_content" android:padding="8dp" android:text="⟳ Sync" android:textColor="#BC91F4" android:clickable="true" />
 </LinearLayout>
 <LinearLayout android:orientation="horizontal" android:layout_width="match_parent" android:layout_height="36dp" android:gravity="center_vertical">
 <TextView android:id="@+id/mk_prev" android:layout_width="42dp" android:layout_height="match_parent" android:gravity="center" android:text="‹" android:textSize="22sp" android:textColor="#BC91F4" />
 <TextView android:id="@+id/mk_month_title" android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:gravity="center" android:textSize="16sp" android:textColor="#BC91F4" />
 <TextView android:id="@+id/mk_next" android:layout_width="42dp" android:layout_height="match_parent" android:gravity="center" android:text="›" android:textSize="22sp" android:textColor="#BC91F4" />
 </LinearLayout>
 <LinearLayout android:orientation="horizontal" android:layout_width="match_parent" android:layout_height="24dp">'''+''.join(f'<TextView android:layout_width="0dp" android:layout_weight="1" android:layout_height="wrap_content" android:text="{d}" android:textColor="#D7D5E8" android:gravity="center" />' for d in 'MTWTFSS')+'''</LinearLayout>
'''+ '\n'.join(rows)+'''
 <TextView android:id="@+id/mk_day_details" android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="38dp" android:padding="7dp" android:background="#55313B50" android:textColor="#ffffff" android:textSize="12sp" />
</LinearLayout>
'''
(res/'layout/mk_native_month_widget.xml').write_text(xml)
# Force original widget provider definition to use the native calendar size, while preserving its identity.
for p in (res/'xml').glob('*.xml'):
 s=p.read_text()
 if 'appwidget-provider' in s and ('initialLayout' in s):
  s=re.sub(r'android:initialLayout="[^"]*"','android:initialLayout="@layout/mk_native_month_widget"',s)
  if 'android:minHeight=' in s:s=re.sub(r'android:minHeight="[^"]*"','android:minHeight="340dp"',s)
  if 'android:minWidth=' in s:s=re.sub(r'android:minWidth="[^"]*"','android:minWidth="280dp"',s)
  p.write_text(s)
# Lightweight page-side push. Never write to localStorage; only forward a snapshot.
html=app/'assets/index.html';assert html.exists(),'index.html missing'
s=html.read_text()
js='''<script id="mkmoney-native-sync">(function(){
 function push(){try{if(window.MKmoneyNativeSync){var x={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);x[k]=localStorage.getItem(k);}var snapshot=JSON.stringify(x);if(snapshot!==window.__mkLastPush){MKmoneyNativeSync.sync(snapshot);window.__mkLastPush=snapshot;}}}catch(e){}}
 window.mkmoneySyncWidget=push;
 document.addEventListener('visibilitychange',function(){if(!document.hidden)push();});
 window.addEventListener('storage',push);
 setInterval(push,3000);setTimeout(push,250);
})();</script>'''
if 'id="mkmoney-native-sync"' not in s:
 assert '</body>' in s,'HTML body end missing'
 s=s.replace('</body>',js+'\n</body>');html.write_text(s)
print('PATCHED',provider,activity,html)

#!/usr/bin/env python3
# MKmoney v1.3.46
from pathlib import Path
import re,sys
root=Path(sys.argv[1]); main=root/'app/src/main'
provider=main/'java/au/com/paycycle/planner/FullMonthWidget.java'
html=main/'assets/index.html'
activity=main/'java/au/com/paycycle/planner/MainActivity.java'
for f in (provider,html,activity):
    if not f.exists(): raise RuntimeError('Missing required MKmoney source: '+str(f))
s=provider.read_text()
# v1.3.45 made the widget Sync control open the app, preventing a local refresh.
old='''if(SYNC.equals(a)){
  Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
  if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
    launch.putExtra("mkmoney_request_widget_sync",true);c.startActivity(launch);}
 }'''
if old not in s: raise RuntimeError('Unexpected FullMonthWidget Sync handler; refusing unsafe patch')
# v1.3.44/45 widget already reads stored snapshot when it renders.
# Do not launch app; action remains routed through the existing provider, which redraws all widgets.
s=s.replace(old,'''if(SYNC.equals(a)){
  // Native widget Sync: redraw from the most recently published MKmoney snapshot.
  // WebView localStorage is private to the app; the widget cannot open it directly.
  android.util.Log.i("MKmoneyWidget","Sync requested: refreshing stored payment snapshot");
 }''',1)
provider.write_text(s)
# Add an explicit bridge invocation to the in-app Sync click flow without replacing app event handlers.
s=html.read_text()
marker='<!-- mkmoney-v1346-dashboard-sync -->'
if marker not in s:
    addition=r'''<!-- mkmoney-v1346-dashboard-sync -->
<script id="mkmoney-v1346-dashboard-sync">
(function(){
  // Native data bridge defined by the v1.3.44/45 patches.
  // Trigger a real re-export after dashboard Sync is tapped.
  document.addEventListener('click',function(event){
    var el=event.target;
    for(var depth=0;el && depth<4;depth++,el=el.parentElement){
      if(!el || !el.matches || !el.matches('button,[role="button"]'))continue;
      var text=((el.innerText||el.textContent||'')+' '+(el.getAttribute('aria-label')||'')).trim();
      if(/^(?:⟳|↻|🔄)?\s*(?:sync|refresh)(?:\s+(?:widget|calendar|payments))?\s*$/i.test(text)){
        setTimeout(function(){
          try{if(typeof window.mkmoneySyncWidget==='function')window.mkmoneySyncWidget();}
          catch(e){console.warn('MKmoney dashboard widget sync failed',e);}
        },80);
        break;
      }
    }
  },true);
})();
</script>
'''
    # Put near end, after app markup; native listener works on dynamic elements.
    if '</body>' not in s: raise RuntimeError('HTML body closing tag missing')
    s=s.replace('</body>',addition+'</body>',1)
    html.write_text(s)
if 'MKmoneyNativeSync' not in activity.read_text():
    raise RuntimeError('Expected native JavaScript bridge missing')
print('v1.3.46 applied: widget Sync redraws saved data without opening app; dashboard Sync publishes to native bridge')

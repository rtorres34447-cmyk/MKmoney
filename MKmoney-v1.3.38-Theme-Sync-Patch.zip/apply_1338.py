from pathlib import Path
import sys,re
root=Path(sys.argv[1]); html=root/'app/src/main/assets/index.html'
assert html.exists(),'MKmoney dashboard HTML not found'
s=html.read_text()
css='''<style id="mk138-style">:root{--mk138:var(--accent,var(--primary,#9b7dfb))}#mk138-sync{position:fixed;bottom:83px;right:15px;z-index:9999;color:#fff;background:rgba(76,43,125,.68);border:1px solid var(--mk138);border-radius:18px;padding:11px 15px;backdrop-filter:blur(12px);font:600 13px system-ui}#mk138-status{position:fixed;bottom:59px;right:15px;z-index:9999;font:11px system-ui;color:#fff;text-shadow:0 1px 2px #000}</style>'''
js='''<script id="mk138-script">(function(){function init(){if(document.getElementById('mk138-sync'))return;var b=document.createElement('button'),s=document.createElement('span');b.id='mk138-sync';b.textContent='⟳ Sync widget';s.id='mk138-status';document.body.append(b,s);b.onclick=function(){try{for(var o of [window.Android,window.MKmoneyBridge,window.WidgetBridge,window.MKmoney]){if(!o)continue;for(var k of ['syncWidget','syncWidgets','refreshWidget','requestWidgetSync'])if(typeof o[k]==='function'){o[k]();s.textContent='Widget refresh requested';return;}}s.textContent='Native sync unavailable; open widget to refresh';}catch(e){s.textContent='Sync error: '+e.message;}}}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();</script>'''
if 'mk138-script' not in s:
 s=s.replace('</head>',css+'</head>') if '</head>' in s else css+s
 s=s.replace('</body>',js+'</body>') if '</body>' in s else s+js
 html.write_text(s)
res=root/'app/src/main/res'
assert (res/'layout').exists(),'Android widget layouts not found'
colors=res/'values/mkmoney_widget_138.xml';colors.parent.mkdir(exist_ok=True,parents=True)
colors.write_text('''<?xml version="1.0" encoding="utf-8"?><resources><color name="mk138_purple">#B69AFF</color><color name="mk138_teal">#46DCC8</color></resources>''')
updated=0
for f in (res/'layout').glob('*widget*.xml'):
 x=f.read_text();orig=x
 def update(m):
  tag=m.group(0); idm=re.search(r'android:id="@\+id/([^"]+)"',tag)
  if not idm:return tag
  id=idm.group(1).lower()
  if not any(k in id for k in ('month','title','sync','refresh')):return tag
  istext=('TextView' in tag or 'Button' in tag)
  attr='android:textColor' if istext else 'android:tint'
  color='@color/mk138_teal' if any(k in id for k in ('sync','refresh')) else '@color/mk138_purple'
  if attr+'=' in tag:tag=re.sub(attr+r'="[^"]*"',attr+'="'+color+'"',tag)
  else:tag=tag[:-2]+' '+attr+'="'+color+'"/>'
  if istext and any(k in id for k in ('sync','refresh')):
   if 'android:text=' in tag:tag=re.sub(r'android:text="[^"]*"','android:text="⟳ Sync"',tag)
   else:tag=tag[:-2]+' android:text="⟳ Sync"/>'
  return tag
 x=re.sub(r'<[\w.]+(?:\s+[^<>]*?)/>',update,x,flags=re.S)
 if x!=orig:f.write_text(x);updated+=1
assert list((root/'app/src/main/java').rglob('FullMonthWidget.java')),'Expected v1.3.37 widget missing'
print('MKmoney 1.3.38 patched, styled widget layouts:',updated)

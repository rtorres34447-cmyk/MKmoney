MKmoney v1.3.38 theme/sync overlay, applied AFTER v1.3.37.
Preserves full calendar and earlier feature patches. Adds a dashboard Sync widget button, recolours widget headings and existing refresh control when identifiable in XML, and keeps transparent background untouched.
Note: Dashboard button invokes a supported native JavaScript bridge when exposed; if none exists, it explicitly reports that syncing is unavailable rather than pretending to sync.
APK has not been compiled or tested here.

Corrects onActivityResult validator to count method declarations only. CSV and Java source are not modified.

from pathlib import Path
import sys,re
root=Path(sys.argv[1]); base=Path(sys.argv[2])
main=list((root/'app/src/main/java').rglob('MainActivity.java'))
assert len(main)==1, 'MainActivity missing/duplicate'
s=main[0].read_text()
# The original v1.3.10 Java can be extended for notifications, but the previous
# broken picker patches MUST NOT be introduced.
# Count method declarations only, not super.onActivityResult(...) calls.
method_defs = re.findall(r'(?m)^[ \t]*(?:@Override[ \t]+)?(?:public|protected|private)[ \t]+(?:final[ \t]+)?void[ \t]+onActivityResult[ \t]*\(', s)
assert len(method_defs)<=1, f'Duplicate onActivityResult declarations: {len(method_defs)}'
assert 'csvFileCallback' not in s, 'Unexpected v1.3.22+ CSV Java changes'
assert '6910' not in s, 'Unexpected v1.3.26 CSV picker changes'
assert 'web.setWebChromeClient(new android.webkit.WebChromeClient()' not in s, 'Unexpected CSV WebChromeClient injected'
html=root/'app/src/main/assets/index.html'
assert html.is_file(), 'Missing index.html'
assert html.stat().st_size>1000, 'HTML looks incomplete'
original=list(base.rglob('app/src/main/assets/index.html'))
assert len(original)==1, 'Missing v1.3.10 original HTML'
source=original[0].read_text()
final=html.read_text()
assert '<html' in final.lower(), 'Invalid final HTML'
# Require original data importing code to remain recognizable, without assuming
# exact callback/function names from a version we did not author.
for token in ('FileReader','text/csv'):
    if token in source and token not in final:
        raise SystemExit(f'Original CSV token removed: {token}')
print('Verified single Java activity result handler, no later picker injections, and v1.3.10 CSV code markers.')

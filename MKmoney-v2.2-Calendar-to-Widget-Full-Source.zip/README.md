# MKmoney v1.3.8
Upload the **contents of this ZIP** into the root of the MKmoney GitHub repository, preserving folders. GitHub Actions -> Build MKmoney v1.3.8 APK -> Run workflow. The workflow builds from the included Android source; no extra ZIP files are required.

IMPORTANT: Android updates require both the same application ID AND the same signing certificate. GitHub's automatic debug signing keys may differ from the key on the installed v1.3.7 APK, so a direct update may fail. Back up/export your CSV from the old app BEFORE installing and DO NOT uninstall the old app until you have a verified backup. If a signing mismatch occurs, rebuild using the original signing key (preferred) or restore from backup after fresh install.

The native reminder scheduler has basic recurring bill handling. It does not fully replicate complex per-occurrence override/exclusion logic in the HTML; validate reminders before relying on them.

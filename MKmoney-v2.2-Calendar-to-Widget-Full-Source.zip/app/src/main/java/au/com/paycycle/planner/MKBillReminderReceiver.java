package au.com.paycycle.planner;
import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.util.*;
import java.text.*;
public class MKBillReminderReceiver extends android.content.BroadcastReceiver {
  public void onReceive(Context ctx,Intent intent){
    if("MK_8PM".equals(intent.getAction())){notifyNow(ctx,false);schedule(ctx);}
  }
  static void schedule(Context ctx){
    Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,20);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
    if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);
    Intent i=new Intent(ctx,MKBillReminderReceiver.class).setAction("MK_8PM");
    PendingIntent pi=PendingIntent.getBroadcast(ctx,8001,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    AlarmManager am=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
    if(am==null)return;
    if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms())am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
    else if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
    else am.setExact(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
  }
  static void notifyNow(Context ctx,boolean test){
    try{
      String data=ctx.getSharedPreferences("mk_money_alerts",0).getString("data","{}");
      JSONObject record=new JSONObject(data);
      Calendar d=Calendar.getInstance();d.add(Calendar.DAY_OF_YEAR,1);
      String tomorrow=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d.getTime());
      JSONArray items=record.optJSONArray(tomorrow);
      if(!test && (items==null||items.length()==0))return;
      double bank1=0,bank2=0,unassigned=0;StringBuilder details=new StringBuilder();
      if(items!=null)for(int n=0;n<items.length();n++){
        JSONObject b=items.optJSONObject(n);if(b==null)continue;
        double v=b.optDouble("amount",0);String bank=b.optString("bank","Unassigned").toLowerCase(Locale.US).replaceAll("[^a-z0-9]", "");
        if(bank.equals("1")||bank.equals("bank1"))bank1+=v;
        else if(bank.equals("2")||bank.equals("bank2"))bank2+=v;
        else unassigned+=v;
      }
      double total=bank1+bank2+unassigned;
      StringBuilder bankSummary=new StringBuilder();
      if(bank1>0)bankSummary.append("Bank 1 $"+String.format(Locale.US,"%.2f",bank1));
      if(bank2>0){if(bankSummary.length()>0)bankSummary.append(" • ");bankSummary.append("Bank 2 $"+String.format(Locale.US,"%.2f",bank2));}
      if(unassigned>0){if(bankSummary.length()>0)bankSummary.append(" • ");bankSummary.append("Unassigned $"+String.format(Locale.US,"%.2f",unassigned));}
      String title=test?"MKmoney test notification":"Tomorrow: $"+String.format(Locale.US,"%.2f",total)+" needed";
      String msg=test?"8:00 pm bill funding reminder active":bankSummary.toString();
      NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
      if(nm==null)return;
      if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("mkmoney_bills","Bill funding reminders",NotificationManager.IMPORTANCE_HIGH));
      Intent launch=ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
      PendingIntent open=launch==null?null:PendingIntent.getActivity(ctx,8002,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
      Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(ctx,"mkmoney_bills"):new Notification.Builder(ctx);
      int icon=ctx.getApplicationInfo().icon;
      b.setSmallIcon(icon==0?android.R.drawable.ic_dialog_info:icon).setContentTitle(title).setContentText(msg)
       .setStyle(new Notification.BigTextStyle().bigText(msg)).setAutoCancel(true).setContentIntent(open);
      nm.notify(8001,b.build());
    }catch(Exception e){android.util.Log.e("MKmoney","Reminder error",e);}
  }
}

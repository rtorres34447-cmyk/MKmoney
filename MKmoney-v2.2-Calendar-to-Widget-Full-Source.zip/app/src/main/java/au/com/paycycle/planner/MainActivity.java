package au.com.paycycle.planner;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.webkit.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 WebView web; static final int EXPORT=103, IMPORT=104; String exportData="";
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);
  web.setWebViewClient(new WebViewClient());web.addJavascriptInterface(new Records(),"AndroidRecords");web.addJavascriptInterface(new Alarms(),"AndroidAlarm");
  web.addJavascriptInterface(new MKBillReminderBridge(this), "MKBillReminder");
        web.addJavascriptInterface(new MKNativeSyncBridge(this), "MKmoneyNativeSync");
        web.loadUrl("file:///android_asset/index.html"); ReminderReceiver.channel(this);
 }
 void js(String expression){runOnUiThread(()->web.evaluateJavascript(expression,null));}
 @Override protected void onResume(){super.onResume();if(web!=null)web.evaluateJavascript("window.dispatchEvent(new Event('focus'))",null);}
 class Records {
  @JavascriptInterface public void saveCsv(String csv){try{getFilesDir().mkdirs();try(FileOutputStream o=openFileOutput("mkmoney-auto-backup.csv",MODE_PRIVATE)){o.write(csv.getBytes(StandardCharsets.UTF_8));}js("window.onNativeSaved(true)");}catch(Exception e){js("window.onNativeSaved(false)");}}
  @JavascriptInterface public void loadCsv(){ /* LocalStorage remains authoritative; do not overwrite with an older CSV backup. */ }
  @JavascriptInterface public void exportCsv(String csv,String name){runOnUiThread(()->{exportData=csv;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,EXPORT);});}
  @JavascriptInterface public void importCsv(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/*");startActivityForResult(i,IMPORT);});}
 }
 class Alarms {
  @JavascriptInterface public void sync(String data){getSharedPreferences("alarm",MODE_PRIVATE).edit().putString("state",data).apply();ReminderReceiver.schedule(MainActivity.this);}
  @JavascriptInterface public void test(){runOnUiThread(()->ReminderReceiver.notifyNow(MainActivity.this,"MKmoney test notification","Notifications are working."));}
  @JavascriptInterface public void permissions(){ if(Build.VERSION.SDK_INT>=31){AlarmManager m=(AlarmManager)getSystemService(ALARM_SERVICE);if(!m.canScheduleExactAlarms()){try{startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}}}
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;
 try{if(request==EXPORT){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(exportData.getBytes(StandardCharsets.UTF_8));}exportData="";js("alert('CSV backup exported successfully.')");}
 else if(request==IMPORT){ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(data.getData())){byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>8_000_000)throw new IOException("CSV exceeds 8 MB");}}String csv=out.toString("UTF-8");String quoted=org.json.JSONObject.quote(csv);js("importPreview("+quoted+")");}}
 catch(Exception e){js("alert('File operation failed. Please try again.')");}}
}

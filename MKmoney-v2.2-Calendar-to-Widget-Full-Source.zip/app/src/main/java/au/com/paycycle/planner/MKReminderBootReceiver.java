package au.com.paycycle.planner;
import android.content.*;
public class MKReminderBootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context,Intent intent){MKBillReminderReceiver.schedule(context);}
}

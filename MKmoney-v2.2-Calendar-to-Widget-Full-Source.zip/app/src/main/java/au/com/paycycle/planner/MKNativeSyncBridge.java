package au.com.paycycle.planner;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;

public class MKNativeSyncBridge {
 private final Context context;
 public MKNativeSyncBridge(Context ctx) { context=ctx.getApplicationContext(); }
 @JavascriptInterface public void sync(String snapshot) {
  if(snapshot==null || snapshot.length()>2000000) return;
  try {
   JSONObject incoming=new JSONObject(snapshot);
   if(incoming.optInt("schema",0)!=2 || incoming.optJSONArray("payments")==null){
    android.util.Log.e("MKmoneyWidget","Rejected sync payload: missing calendar payments array");return;
   }
   String payments=incoming.getJSONArray("payments").toString();
   // The manifest registers InteractiveCalendarWidget; its data store is
   // mkmoney_calendar_widget/payments. The former bridge refreshed an unrelated
   // FullMonthWidget and wrote to a different preferences file.
   boolean saved=context.getSharedPreferences("mkmoney_calendar_widget",Context.MODE_PRIVATE)
       .edit().putString("payments",payments).putLong("syncedAt",System.currentTimeMillis()).commit();
   if(!saved) { android.util.Log.e("MKmoneyWidget","Failed to persist payments");return; }
   AppWidgetManager manager=AppWidgetManager.getInstance(context);
   int[] widgets=manager.getAppWidgetIds(new ComponentName(context,InteractiveCalendarWidget.class));
   if(widgets.length>0) new InteractiveCalendarWidget().onUpdate(context,manager,widgets);
   android.util.Log.i("MKmoneyWidget","Saved "+incoming.getJSONArray("payments").length()+" calendar entries; updated "+widgets.length+" widgets");
  } catch(Exception ex) { android.util.Log.e("MKmoneyWidget","Native sync failed",ex); }
 }
}

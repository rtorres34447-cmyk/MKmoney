package au.com.paycycle.planner;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class FullMonthWidget extends AppWidgetProvider {
 private static final String SELECT="mkmoney.widgets.SELECT",PREV="mkmoney.widgets.PREV",NEXT="mkmoney.widgets.NEXT",SYNC="mkmoney.widgets.REFRESH";
 private static final String PREF="mkmoney_native_widget";
 private static final int[] DAYS = new int[] {R.id.mk_day_0, R.id.mk_day_1, R.id.mk_day_2, R.id.mk_day_3, R.id.mk_day_4, R.id.mk_day_5, R.id.mk_day_6, R.id.mk_day_7, R.id.mk_day_8, R.id.mk_day_9, R.id.mk_day_10, R.id.mk_day_11, R.id.mk_day_12, R.id.mk_day_13, R.id.mk_day_14, R.id.mk_day_15, R.id.mk_day_16, R.id.mk_day_17, R.id.mk_day_18, R.id.mk_day_19, R.id.mk_day_20, R.id.mk_day_21, R.id.mk_day_22, R.id.mk_day_23, R.id.mk_day_24, R.id.mk_day_25, R.id.mk_day_26, R.id.mk_day_27, R.id.mk_day_28, R.id.mk_day_29, R.id.mk_day_30, R.id.mk_day_31, R.id.mk_day_32, R.id.mk_day_33, R.id.mk_day_34, R.id.mk_day_35, R.id.mk_day_36, R.id.mk_day_37, R.id.mk_day_38, R.id.mk_day_39, R.id.mk_day_40, R.id.mk_day_41};
 @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){super.onUpdate(c,manager,ids); for(int id:ids) draw(c,manager,id);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);String a=i.getAction(); if(SYNC.equals(a)){
  // Native widget Sync: redraw from the most recently published MKmoney snapshot.
  // WebView localStorage is private to the app; the widget cannot open it directly.
  android.util.Log.i("MKmoneyWidget","Sync requested: refreshing stored payment snapshot");
 }
 if(SELECT.equals(a)||PREV.equals(a)||NEXT.equals(a)||SYNC.equals(a)){int id=i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1); if(PREV.equals(a)||NEXT.equals(a)){String key="offset_"+id;int current=c.getSharedPreferences(PREF,0).getInt(key,0);c.getSharedPreferences(PREF,0).edit().putInt(key,current+(PREV.equals(a)?-1:1)).apply();}if(SELECT.equals(a)) c.getSharedPreferences(PREF,0).edit().putString("selected_"+id,i.getStringExtra("date")).apply();AppWidgetManager m=AppWidgetManager.getInstance(c);if(id<0){for(int n:m.getAppWidgetIds(new android.content.ComponentName(c,FullMonthWidget.class)))draw(c,m,n);}else draw(c,m,id);}}
 private static PendingIntent pending(Context c,int widget,String action,String date,int code){Intent i=new Intent(c,FullMonthWidget.class);i.setAction(action);i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,widget);if(date!=null)i.putExtra("date",date);i.setData(android.net.Uri.parse("mkmoney://"+widget+"/"+action+"/"+(date==null?"":date)));return PendingIntent.getBroadcast(c,code,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 private static java.util.ArrayList<String> keys(JSONObject o){java.util.ArrayList<String> result=new java.util.ArrayList<>();java.util.Iterator<String> iterator=o.keys();while(iterator.hasNext())result.add(iterator.next());return result;}
 private static String pick(JSONObject o,String...names){for(String name:names){for(String k:keys(o)){if(k.equalsIgnoreCase(name)){Object v=o.opt(k);if(v!=null&&!JSONObject.NULL.equals(v))return String.valueOf(v);}}}return "";}
 private static Double amount(String s){try{return Double.parseDouble(s.replaceAll("[^0-9.-]",""));}catch(Exception e){return null;}}
 private static String normalizeDate(String date){try{if(date.matches("\\d{4}-\\d{2}-\\d{2}.*"))return date.substring(0,10);if(date.matches("\\d{2}/\\d{2}/\\d{4}")){String[] p=date.split("/");return p[2]+"-"+p[1]+"-"+p[0];}}catch(Exception ignored){}return "";}
 private static void scan(Object node,String day,ArrayList<String> out,Set<String> seen,int depth){
  if(depth>12||out.size()>=25||node==null)return;
  if(node instanceof JSONObject){JSONObject o=(JSONObject)node;String date=normalizeDate(pick(o,"dueDate","due","date","paymentDate","nextDate","startDate"));
   String title=pick(o,"name","title","billName","merchant","description","label");String money=pick(o,"amount","cost","value","price","payment","total");
   if(day.equals(date)&&!title.isEmpty()&&!money.isEmpty()){Double n=amount(money);if(n!=null){String row=title+"  $"+String.format(Locale.US,"%.2f",n);if(seen.add(row))out.add(row);}}
   for(String key:keys(o))scan(o.opt(key),day,out,seen,depth+1);
  }else if(node instanceof JSONArray){JSONArray a=(JSONArray)node;for(int j=0;j<a.length();j++)scan(a.opt(j),day,out,seen,depth+1);}
  else if(node instanceof String){String s=(String)node;if(s.length()>1 &&(s.startsWith("{")||s.startsWith("[")))try{scan(s.startsWith("{")?new JSONObject(s):new JSONArray(s),day,out,seen,depth+1);}catch(Exception ignored){}}
 }
 private static ArrayList<String> payments(Context c,String day){
  ArrayList<String> out=new ArrayList<>();
  try{
   String raw=c.getSharedPreferences(PREF,0).getString("snapshot","{}");
   JSONObject snapshot=new JSONObject(raw);
   if(snapshot.optInt("schema",0)==2){
    JSONArray entries=snapshot.optJSONArray("payments");
    if(entries!=null)for(int i=0;i<entries.length()&&out.size()<40;i++){
     JSONObject e=entries.optJSONObject(i);if(e==null||!day.equals(e.optString("date")))continue;
     String name=e.optString("name","Bill");double amount=e.optDouble("amount",0);
     out.add(name+"  $"+String.format(Locale.US,"%.2f",amount)+(e.optBoolean("paid")?" ✓":""));
    }
    return out;
   }
   scan(snapshot,day,out,new HashSet<String>(),0);
  }catch(Exception ex){android.util.Log.e("MKmoneyWidget","payment parsing",ex);}
  return out;
 }
 private static void draw(Context c,AppWidgetManager manager,int widget){try{
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.mk_native_month_widget);
  int offset=c.getSharedPreferences(PREF,0).getInt("offset_"+widget,0);YearMonth month=YearMonth.now().plusMonths(offset);
  v.setTextViewText(R.id.mk_month_title,month.getMonth().getDisplayName(java.time.format.TextStyle.FULL,Locale.ENGLISH)+" "+month.getYear());
  v.setOnClickPendingIntent(R.id.mk_prev,pending(c,widget,PREV,null,100));v.setOnClickPendingIntent(R.id.mk_next,pending(c,widget,NEXT,null,101));v.setOnClickPendingIntent(R.id.mk_sync,pending(c,widget,SYNC,null,102));
  LocalDate start=month.atDay(1);int leading=start.getDayOfWeek().getValue()-1;LocalDate first=start.minusDays(leading);
  String selected=c.getSharedPreferences(PREF,0).getString("selected_"+widget,LocalDate.now().toString());
  for(int k=0;k<42;k++){LocalDate d=first.plusDays(k);String iso=d.toString();v.setTextViewText(DAYS[k],String.valueOf(d.getDayOfMonth()));v.setTextColor(DAYS[k],d.getMonthValue()==month.getMonthValue()?Color.WHITE:0xFF8791A7);v.setInt(DAYS[k],"setBackgroundColor",iso.equals(selected)?0x995E35B1:Color.TRANSPARENT);v.setOnClickPendingIntent(DAYS[k],pending(c,widget,SELECT,iso,200+k));}
  ArrayList<String> entries=payments(c,selected);
  String raw=c.getSharedPreferences(PREF,0).getString("snapshot","");
  String status="No snapshot received";
  if(!raw.isEmpty()){
   try{
    JSONObject snapshot=new JSONObject(raw);
    status="Snapshot: "+raw.length()+" chars / "+snapshot.length()+" storage keys";
   }catch(Exception ex){status="Snapshot is invalid JSON ("+raw.length()+" chars)";}
  }
  StringBuilder content=new StringBuilder(selected+" | "+status+" | Matched bills: "+entries.size());
  for(String e:entries){if(content.length()>1000)break;content.append("\n").append(e);}
  v.setTextViewText(R.id.mk_day_details,content.toString());manager.updateAppWidget(widget,v);
 }catch(Exception ex){android.util.Log.e("MKmoneyWidget","draw",ex);}}
}

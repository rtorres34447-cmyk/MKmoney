package au.com.paycycle.planner;
import android.app.*;
import android.content.*;
import android.os.*;
import android.webkit.JavascriptInterface;
import org.json.*;
import java.util.*;
public class MKBillReminderBridge {
  private final Context ctx; private final Activity activity;
  public MKBillReminderBridge(Context ctx){this.ctx=ctx.getApplicationContext();this.activity=ctx instanceof Activity?(Activity)ctx:null;}
  @JavascriptInterface public void saveTomorrowBills(String json){
    ctx.getSharedPreferences("mk_money_alerts",0).edit().putString("data",json).apply();
    MKBillReminderReceiver.schedule(ctx);
  }
  @JavascriptInterface public void requestNotificationPermission(){
    if(Build.VERSION.SDK_INT>=33 && activity!=null){activity.runOnUiThread(()->activity.requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},814));}
  }
  @JavascriptInterface public void testNotification(){MKBillReminderReceiver.notifyNow(ctx,true);}
}

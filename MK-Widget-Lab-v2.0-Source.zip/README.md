# MK Widget Lab v2.0 — calendar test

Separate from MKmoney. Builds an Android home-screen calendar widget with selectable days, multiple bills, monthly navigation and HTML/Java/SharedPreferences sync.

## Tests
1. Add widget to home screen (enlarge to approximately 4×5 or bigger).
2. Open the app and tap **Load sample October bills**.
3. Widget: on 25 Oct two bills should total **$134.50**.
4. Tap 23 Oct: Electricity $750.00.
5. Navigate to November: Strata $771.00 on the 1st.
6. Add another bill or a repeating bill and tap Sync. Confirm dates and amounts.
7. Tap widget Today/Sync and inspect counters under Read widget state.

The sample dates and amounts are **testing data**, not live MKmoney payments. The app is not connected to MKmoney. Persistence uses a separate SharedPreferences namespace.

## GitHub
Extract source ZIP to repository root (settings.gradle at root), then put the YAML file under `.github/workflows/blank.yml`. Run Actions; download APK from the artifacts section. Alternatively upload the standalone self-contained YAML to blank.yml without extracting any ZIP.

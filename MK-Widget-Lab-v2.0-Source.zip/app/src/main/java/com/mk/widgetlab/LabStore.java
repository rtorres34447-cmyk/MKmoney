package com.mk.widgetlab;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;
public final class LabStore {
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("calendar_lab_v2",Context.MODE_PRIVATE);}
 static String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
 static String shift(String d,int amount,int field){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);Calendar cal=Calendar.getInstance();cal.setTime(f.parse(d));cal.add(field,amount);return f.format(cal.getTime());}catch(Exception e){return today();}}
 static String date(Context c){return prefs(c).getString("date",today());}
 static JSONArray payments(Context c){try{return new JSONArray(prefs(c).getString("payments","[]"));}catch(Exception e){return new JSONArray();}}
 static void log(Context c,String s){SharedPreferences p=prefs(c);String now=new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date());String t=now+"  "+s+"\n"+p.getString("trace","");p.edit().putString("trace",t.substring(0,Math.min(12000,t.length()))).apply();}
 static int count(Context c,String date){int n=0;JSONArray a=payments(c);for(int i=0;i<a.length();i++)if(date.equals(a.optJSONObject(i).optString("date")))n++;return n;}
 static int cents(Context c,String date){int sum=0;JSONArray a=payments(c);for(int i=0;i<a.length();i++){JSONObject j=a.optJSONObject(i);if(date.equals(j.optString("date")))sum+=j.optInt("cents");}return sum;}
 static String money(int cents){return String.format(Locale.US,"$%,.2f",cents/100.0);}
 static String breakdown(Context c,String date){JSONArray a=payments(c);StringBuilder s=new StringBuilder();int n=0;for(int i=0;i<a.length();i++){JSONObject j=a.optJSONObject(i);if(date.equals(j.optString("date"))){if(n++>0)s.append("\n");s.append(j.optString("name")).append("  ").append(money(j.optInt("cents")));}}return n==0?"No payments":s.toString();}
 static JSONObject state(Context c){SharedPreferences p=prefs(c);JSONObject j=new JSONObject();try{j.put("selectedDate",date(c));j.put("payments",payments(c));j.put("syncCount",p.getInt("sync",0));j.put("widgetTaps",p.getInt("taps",0));j.put("lastSource",p.getString("source","none"));j.put("trace",p.getString("trace",""));j.put("dayTotal",cents(c,date(c)));}catch(Exception e){}return j;}
}

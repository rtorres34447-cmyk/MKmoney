from pathlib import Path
import sys,re,textwrap
root=Path(sys.argv[1]); p=root/'app/src/main/java/com/mkmoney/app/MainActivity.java'
s=p.read_text()
def closing(s,pos):
 d=0; state='normal'; i=pos
 while i<len(s):
  a=s[i]; b=s[i+1] if i+1<len(s) else ''
  if state=='normal':
   if a=='/' and b=='/':state='line';i+=2;continue
   if a=='/' and b=='*':state='block';i+=2;continue
   if a in ('"',"'"):state=a
   elif a=='{':d+=1
   elif a=='}':
    d-=1
    if d==0:return i
  elif state=='line':
   if a=='\n':state='normal'
  elif state=='block':
   if a=='*' and b=='/':state='normal';i+=2;continue
  else:
   if a=='\\':i+=2;continue
   if a==state:state='normal'
  i+=1
 raise RuntimeError('Unclosed Java brace')
# v1.3.22 mistakenly inserts a second client at class level, before onCreate.
pat=r'web\.setWebChromeClient\s*\(\s*new\s+android\.webkit\.WebChromeClient\s*\(\s*\)\s*\{'
hits=list(re.finditer(pat,s));print('webchrome blocks:',len(hits))
if not hits:raise SystemExit('No v1.3.22 chooser block; source unexpected')
# Find chooser override and malformed class-level block by comparing method ranges.
method=re.search(r'\bonCreate\s*\([^)]*\)\s*\{',s)
if not method:raise SystemExit('Missing onCreate')
start=method.end()-1; end=closing(s,start)
malformed=[m for m in hits if not (start<m.start()<end)]
if len(malformed)!=1:raise SystemExit(f'Expected one misplaced WebChromeClient, found {len(malformed)}')
m=malformed[0]; brace=s.index('{',m.start()); cls_end=closing(s,brace)
trailer=re.match(r'\s*\)\s*;',s[cls_end+1:])
if not trailer:raise SystemExit('Malformed chooser has unexpected ending')
finish=cls_end+1+trailer.end()
chooser=s[brace+1:cls_end]
if 'onShowFileChooser' not in chooser:raise SystemExit('Misplaced code has no chooser')
s=s[:m.start()]+s[finish:]
# Recalculate ranges after deletion
method=re.search(r'\bonCreate\s*\([^)]*\)\s*\{',s);start=method.end()-1;end=closing(s,start)
body=s[start+1:end]
existing=re.search(r'(?:web|\w+)\.setWebChromeClient\s*\(\s*new\s+(?:android\.webkit\.)?WebChromeClient\s*\(\s*\)\s*\{',body)
if existing:
 opening=start+1+existing.end()-1; closing_pos=closing(s,opening)
 if 'onShowFileChooser' in s[opening:closing_pos]:
  print('Existing chooser override retained; removed invalid duplicate')
 else:
  s=s[:closing_pos]+'\n'+textwrap.indent(textwrap.dedent(chooser).strip(),'            ')+'\n        '+s[closing_pos:]
  print('Merged file chooser into existing WebChromeClient without replacing callbacks')
else:
 if not re.search(r'\bweb\s*=',body) and not re.search(r'\bWebView\s+web\b',body):raise SystemExit('No web WebView in onCreate')
 s=s[:end]+'\n        web.setWebChromeClient(new android.webkit.WebChromeClient() {\n'+chooser+'\n        });\n'+s[end:]
 print('Installed chooser within onCreate')
p.write_text(s)

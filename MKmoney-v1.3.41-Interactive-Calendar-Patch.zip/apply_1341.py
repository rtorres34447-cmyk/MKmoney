#!/usr/bin/env python3
import sys,re,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(sys.argv[1]).resolve(); main=root/'app/src/main'; manifest=main/'AndroidManifest.xml'
ns='{http://schemas.android.com/apk/res/android}'
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
tree=ET.parse(manifest); top=tree.getroot(); app=top.find('application')
pkg=top.attrib.get('package','')
if not pkg:
    gradle=(root/'app/build.gradle').read_text()
    m=re.search(r'namespace\s*[= ]\s*[\'\"]([^\'\"]+)',gradle)
    if not m: raise RuntimeError('Cannot determine Android app namespace')
    pkg=m.group(1)
# Remove all former home-screen widget registrations, leaving non-widget receivers intact.
for r in list(app.findall('receiver')):
    if any(x.get(ns+'name')=='android.appwidget.provider' for x in r.findall('meta-data')):app.remove(r)
cls=pkg+'.InteractiveCalendarWidget'; r=ET.SubElement(app,'receiver',{ns+'name':cls,ns+'exported':'true'})
flt=ET.SubElement(r,'intent-filter'); ET.SubElement(flt,'action',{ns+'name':'android.appwidget.action.APPWIDGET_UPDATE'})
ET.SubElement(r,'meta-data',{ns+'name':'android.appwidget.provider',ns+'resource':'@xml/mkm_interactive_widget'})
tree.write(manifest,encoding='utf-8',xml_declaration=True)
res=main/'res'; (res/'xml').mkdir(parents=True,exist_ok=True);(res/'layout').mkdir(parents=True,exist_ok=True)
(res/'xml/mkm_interactive_widget.xml').write_text('''<?xml version="1.0" encoding="utf-8"?><appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="280dp" android:minHeight="240dp" android:targetCellWidth="4" android:targetCellHeight="4" android:updatePeriodMillis="0" android:initialLayout="@layout/mkm_interactive_widget" android:resizeMode="horizontal|vertical" android:widgetCategory="home_screen" />''')
header='''<?xml version="1.0" encoding="utf-8"?><LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:orientation="vertical" android:padding="6dp" android:background="#260E1424" android:layout_width="match_parent" android:layout_height="match_parent"><LinearLayout android:layout_width="match_parent" android:layout_height="42dp" android:gravity="center_vertical"><TextView android:id="@+id/mkm_title" android:text="MKmoney" android:textColor="#E8E4FF" android:textSize="13sp" android:layout_weight="1" android:layout_width="0dp" android:layout_height="wrap_content"/><TextView android:id="@+id/mkm_sync" android:text="⟳ Sync" android:textColor="#C9B4FF" android:padding="8dp" android:textSize="13sp" android:layout_width="wrap_content" android:layout_height="wrap_content" /></LinearLayout><LinearLayout android:layout_width="match_parent" android:layout_height="38dp" android:gravity="center_vertical"><TextView android:id="@+id/mkm_prev" android:text="‹" android:textColor="#BE91FF" android:textSize="24sp" android:padding="5dp" android:layout_width="40dp" android:layout_height="wrap_content"/><TextView android:id="@+id/mkm_month" android:gravity="center" android:textColor="#C49EFF" android:textSize="17sp" android:layout_weight="1" android:layout_width="0dp" android:layout_height="wrap_content"/><TextView android:id="@+id/mkm_next" android:text="›" android:textColor="#BE91FF" android:textSize="24sp" android:padding="5dp" android:layout_width="40dp" android:layout_height="wrap_content"/></LinearLayout><LinearLayout android:layout_width="match_parent" android:layout_height="22dp">'''
for x in 'MTWTFSS':header+=f'<TextView android:text="{x}" android:gravity="center" android:textColor="#EFE8FF" android:layout_weight="1" android:layout_width="0dp" android:layout_height="match_parent" />'
header+='</LinearLayout>'
for row in range(6):
    header+='<LinearLayout android:layout_width="match_parent" android:layout_height="33dp">'
    for col in range(7):header+=f'<TextView android:id="@+id/mkm_day_{row*7+col}" android:gravity="center" android:textSize="12sp" android:textColor="#F3EFFF" android:background="#143C2D60" android:layout_weight="1" android:layout_width="0dp" android:layout_height="match_parent" />'
    header+='</LinearLayout>'
header+='''<TextView android:id="@+id/mkm_detail" android:text="Select a date to see payments" android:textColor="#FFFFFF" android:textSize="12sp" android:padding="8dp" android:background="#6637415A" android:layout_width="match_parent" android:layout_height="wrap_content" /></LinearLayout>'''
(res/'layout/mkm_interactive_widget.xml').write_text(header)
java=r'''package PKG;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Locale;
public class InteractiveCalendarWidget extends AppWidgetProvider {
 private static final String ACTION="PKG.MKM_WIDGET_ACTION";
 private static final String PREF="mkmoney_calendar_widget";
 private static final int[] IDS={IDS};
 private PendingIntent action(Context c,int wid,String cmd,String date,int request){
  Intent i=new Intent(c,InteractiveCalendarWidget.class);i.setAction(ACTION);i.putExtra("wid",wid);i.putExtra("cmd",cmd);i.putExtra("date",date);
  return PendingIntent.getBroadcast(c,request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)draw(c,m,id);}
 public void onReceive(Context c,Intent i){super.onReceive(c,i);if(!ACTION.equals(i.getAction()))return;
  int id=i.getIntExtra("wid",-1);if(id<0)return;String cmd=i.getStringExtra("cmd");
  SharedPreferences p=c.getSharedPreferences(PREF,0);SharedPreferences.Editor e=p.edit();
  if("date".equals(cmd))e.putString("selected_"+id,i.getStringExtra("date"));
  else if("prev".equals(cmd)||"next".equals(cmd))e.putInt("offset_"+id,Math.max(-120,Math.min(120,p.getInt("offset_"+id,0)+("prev".equals(cmd)?-1:1))));
  else if("sync".equals(cmd))e.putLong("refresh_"+id,System.currentTimeMillis());
  e.apply();draw(c,AppWidgetManager.getInstance(c),id);
 }
 private void draw(Context c,AppWidgetManager m,int id){
  SharedPreferences p=c.getSharedPreferences(PREF,0);int offset=p.getInt("offset_"+id,0);
  Calendar first=Calendar.getInstance();first.set(Calendar.DAY_OF_MONTH,1);first.add(Calendar.MONTH,offset);
  Calendar cursor=(Calendar)first.clone();int shift=(first.get(Calendar.DAY_OF_WEEK)+5)%7;cursor.add(Calendar.DAY_OF_MONTH,-shift);
  String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Calendar.getInstance().getTime());
  String selected=p.getString("selected_"+id,today);
  RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.mkm_interactive_widget);
  v.setTextViewText(R.id.mkm_month,new SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(first.getTime()));
  v.setOnClickPendingIntent(R.id.mkm_prev,action(c,id,"prev","",id*100+1));
  v.setOnClickPendingIntent(R.id.mkm_next,action(c,id,"next","",id*100+2));
  v.setOnClickPendingIntent(R.id.mkm_sync,action(c,id,"sync","",id*100+3));
  for(int n=0;n<42;n++){
   String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(cursor.getTime());
   v.setTextViewText(IDS[n],Integer.toString(cursor.get(Calendar.DAY_OF_MONTH)));
   v.setTextColor(IDS[n],cursor.get(Calendar.MONTH)==first.get(Calendar.MONTH)?Color.WHITE:0x99CCCCCC);
   v.setInt(IDS[n],"setBackgroundColor",d.equals(selected)?0x997A4EBD:0x143C2D60);
   v.setOnClickPendingIntent(IDS[n],action(c,id,"date",d,id*1000+n+10));
   cursor.add(Calendar.DAY_OF_MONTH,1);
  }
  StringBuilder info=new StringBuilder(selected);boolean any=false;
  // The host app can publish a JSON array to this preferences file under 'payments'.
  // Each object: {"date":"yyyy-MM-dd","name":"...","amount":number}.
  double sum=0;try{JSONArray a=new JSONArray(p.getString("payments","[]"));
   for(int k=0;k<a.length();k++){JSONObject x=a.optJSONObject(k);if(x!=null&&selected.equals(x.optString("date"))){any=true;sum+=x.optDouble("amount",0);info.append("\n").append(x.optString("name","Payment")).append(": $").append(String.format(Locale.US,"%.2f",x.optDouble("amount",0)));}}
  }catch(Exception ignored){}
  if(any)info.append("\nTotal: $").append(String.format(Locale.US,"%.2f",sum));
  else info.append(" · No synced payments for this date");
  v.setTextViewText(R.id.mkm_detail,info.toString());m.updateAppWidget(id,v);
 }
}
'''
ids=','.join('R.id.mkm_day_'+str(i) for i in range(42))
src=java.replace('PKG',pkg).replace('{IDS}','{'+ids+'}')
dir=main/'java'/Path(*pkg.split('.'));dir.mkdir(parents=True,exist_ok=True);(dir/'InteractiveCalendarWidget.java').write_text(src)
# Verify all date cells have click targets, and only one widget receiver remains.
assert src.count('setOnClickPendingIntent')>=4 and 'n<42' in src
assert sum(1 for r in app.findall('receiver') for x in r.findall('meta-data') if x.get(ns+'name')=='android.appwidget.provider')==1
print('Installed interactive 42-cell native calendar, month navigation and clickable sync refresh. Payment JSON host bridge must be integrated separately.')

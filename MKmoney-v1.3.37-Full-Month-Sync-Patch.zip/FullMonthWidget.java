package PACKAGE_NAME;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.app.PendingIntent;
import android.content.*;
import android.widget.RemoteViews;
import android.graphics.Color;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class FullMonthWidget extends AppWidgetProvider {
 static final String ACTION="PACKAGE_NAME.WIDGET_ACTION";
 static final String P="mkmoney_month_widget";
 static PendingIntent pi(Context c,int id,String verb,int day){ Intent i=new Intent(c,FullMonthWidget.class);i.setAction(ACTION);i.putExtra("id",id);i.putExtra("verb",verb);i.putExtra("day",day);return PendingIntent.getBroadcast(c,id*100+day+verb.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); }
 @Override public void onUpdate(Context c,AppWidgetManager mgr,int[] ids){for(int id:ids)render(c,mgr,id);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i); if(!ACTION.equals(i.getAction()))return;int id=i.getIntExtra("id",-1);if(id<0)return;String verb=i.getStringExtra("verb");android.content.SharedPreferences sp=c.getSharedPreferences(P,0);Calendar month=Calendar.getInstance();month.setTimeInMillis(sp.getLong("month_"+id,System.currentTimeMillis())); if("prev".equals(verb))month.add(Calendar.MONTH,-1);if("next".equals(verb))month.add(Calendar.MONTH,1);if("prev".equals(verb)||"next".equals(verb))sp.edit().putLong("month_"+id,month.getTimeInMillis()).apply(); if("day".equals(verb))sp.edit().putInt("day_"+id,i.getIntExtra("day",1)).apply();if("sync".equals(verb)){Intent launch=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(launch);}}render(c,AppWidgetManager.getInstance(c),id);}
 static RemoteViews label(Context c,String txt,int size){RemoteViews v=new RemoteViews(c.getPackageName(),android.R.layout.simple_list_item_1);v.setTextViewText(android.R.id.text1,txt);v.setTextColor(android.R.id.text1,Color.WHITE);v.setTextViewTextSize(android.R.id.text1,1,size);return v;}
 static void render(Context c,AppWidgetManager m,int id){ android.content.SharedPreferences sp=c.getSharedPreferences(P,0);Calendar month=Calendar.getInstance();month.setTimeInMillis(sp.getLong("month_"+id,System.currentTimeMillis()));month.set(Calendar.DAY_OF_MONTH,1);Calendar today=Calendar.getInstance();RemoteViews base=new RemoteViews(c.getPackageName(),R.layout.mkmoney_full_month_widget);base.setTextViewText(R.id.widget_month,new SimpleDateFormat("MMMM yyyy",Locale.getDefault()).format(month.getTime()));base.setOnClickPendingIntent(R.id.widget_prev,pi(c,id,"prev",0));base.setOnClickPendingIntent(R.id.widget_next,pi(c,id,"next",0));base.setOnClickPendingIntent(R.id.widget_sync,pi(c,id,"sync",0));base.removeAllViews(R.id.widget_grid);
 JSONArray payments=new JSONArray();try{String raw=c.getSharedPreferences("mkmoney_widget",0).getString("payments_json","[]");payments=new JSONArray(raw);}catch(Exception ignored){}
 Calendar start=(Calendar)month.clone();int offset=(start.get(Calendar.DAY_OF_WEEK)+5)%7;start.add(Calendar.DAY_OF_MONTH,-offset);int count=offset+month.getActualMaximum(Calendar.DAY_OF_MONTH);int weeks=(count+6)/7;
 RemoteViews header=new RemoteViews(c.getPackageName(),R.layout.mkmoney_widget_row);String[] dow={"M","T","W","T","F","S","S"};for(int j=0;j<7;j++)header.setTextViewText(new int[]{R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6}[j],dow[j]);base.addView(R.id.widget_grid,header);
 int[] cell={R.id.d0,R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5,R.id.d6};int selected=sp.getInt("day_"+id,today.get(Calendar.DAY_OF_MONTH));StringBuilder details=new StringBuilder();String next="";long nextTs=Long.MAX_VALUE;
 for(int w=0;w<weeks;w++){RemoteViews row=new RemoteViews(c.getPackageName(),R.layout.mkmoney_widget_row);for(int col=0;col<7;col++){Calendar d=(Calendar)start.clone();d.add(Calendar.DAY_OF_MONTH,w*7+col);boolean active=d.get(Calendar.MONTH)==month.get(Calendar.MONTH);String iso=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(d.getTime());StringBuilder celltxt=new StringBuilder(active?String.valueOf(d.get(Calendar.DAY_OF_MONTH)):"·");if(active){int n=0;for(int k=0;k<payments.length();k++){JSONObject x=payments.optJSONObject(k);if(x==null||!iso.equals(x.optString("date")))continue;n++;String title=x.optString("name",x.optString("title","Bill"));String amount=x.optString("amount","");if(n<=2)celltxt.append("\n").append(title.length()>8?title.substring(0,8):title).append(" ").append(amount);if(d.get(Calendar.DAY_OF_MONTH)==selected)details.append(title).append(" ").append(amount).append("  ");if(d.getTimeInMillis()>=today.getTimeInMillis()-86400000L&&d.getTimeInMillis()<nextTs){nextTs=d.getTimeInMillis();next=title+" "+amount+" • "+iso;}}if(n>2)celltxt.append("\n+").append(n-2);}
 row.setTextViewText(cell[col],celltxt.toString());row.setTextColor(cell[col],active?Color.WHITE:0x88FFFFFF);row.setOnClickPendingIntent(cell[col],pi(c,id,"day",d.get(Calendar.DAY_OF_MONTH)));}
 base.addView(R.id.widget_grid,row);}
 base.setTextViewText(R.id.widget_upcoming,next.isEmpty()?"Upcoming payment • Sync from MKmoney":next);
 base.setTextViewText(R.id.widget_status,details.length()==0?"No synced payments for selected date • tap ⟳ to open MKmoney":details.toString());m.updateAppWidget(id,base);
 }
}

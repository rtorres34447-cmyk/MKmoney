#!/usr/bin/env python3
import sys,re
from pathlib import Path
from xml.etree import ElementTree as ET
root=Path(sys.argv[1]); app=root/'app/src/main'; manifest=app/'AndroidManifest.xml'
text=manifest.read_text()
m=re.search(r'package="([^"]+)"',text)
if m: pkg=m.group(1)
else:
 gradle=(root/'app/build.gradle').read_text(); m=re.search(r'namespace\s*[= ]\s*["\']([^"\']+)',gradle)
 if not m: raise SystemExit('Cannot determine Android namespace')
 pkg=m.group(1)
java=app/'java'/Path(pkg.replace('.','/'));java.mkdir(parents=True,exist_ok=True)
source=Path(__file__).with_name('FullMonthWidget.java').read_text().replace('PACKAGE_NAME',pkg)
(java/'FullMonthWidget.java').write_text(source)
res=app/'res';(res/'xml').mkdir(parents=True,exist_ok=True);(res/'layout').mkdir(parents=True,exist_ok=True)
(res/'xml/mkmoney_full_month_widget.xml').write_text("""<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="320dp" android:minHeight="300dp" android:initialLayout="@layout/mkmoney_full_month_widget" android:resizeMode="horizontal|vertical" android:updatePeriodMillis="1800000" android:widgetCategory="home_screen" />""")
(res/'layout/mkmoney_full_month_widget.xml').write_text("""<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent" android:orientation="vertical" android:padding="8dp" android:background="#33000000">
<LinearLayout android:layout_width="match_parent" android:layout_height="42dp" android:orientation="horizontal"><TextView android:id="@+id/widget_prev" android:layout_width="36dp" android:layout_height="match_parent" android:text="‹" android:textSize="28sp" android:textColor="#FFFFFF" android:gravity="center"/><TextView android:id="@+id/widget_month" android:layout_width="0dp" android:layout_weight="1" android:layout_height="match_parent" android:text="MKmoney" android:textColor="#FFFFFF" android:textSize="17sp" android:textStyle="bold" android:gravity="center"/><TextView android:id="@+id/widget_next" android:layout_width="36dp" android:layout_height="match_parent" android:text="›" android:textSize="28sp" android:textColor="#FFFFFF" android:gravity="center"/><TextView android:id="@+id/widget_sync" android:layout_width="48dp" android:layout_height="match_parent" android:text="⟳" android:textSize="25sp" android:textColor="#FFFFFF" android:gravity="center"/></LinearLayout>
<TextView android:id="@+id/widget_upcoming" android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="35dp" android:gravity="center_vertical" android:text="Upcoming payment • Open MKmoney to sync" android:textColor="#FFFFFF" android:textSize="12sp"/>
<LinearLayout android:id="@+id/widget_grid" android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" android:orientation="vertical"/>
<TextView android:id="@+id/widget_status" android:layout_width="match_parent" android:layout_height="wrap_content" android:padding="5dp" android:textColor="#FFFFFF" android:textSize="12sp" android:text="Tap a date to see its breakdown"/>
</LinearLayout>""")
(res/'layout/mkmoney_widget_row.xml').write_text(Path(__file__).with_name('mkmoney_widget_row.xml').read_text())
receiver='<receiver android:name=".'+'FullMonthWidget'+'" android:exported="true"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/><action android:name="'+pkg+'.WIDGET_ACTION"/></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/mkmoney_full_month_widget"/></receiver>'
if 'android:name=".FullMonthWidget"' not in text:
 text=text.replace('</application>',receiver+'</application>')
manifest.write_text(text)
print('Added full-month resizeable widget + navigation + sync intent; data export compatibility requires app-side widget JSON publishing')

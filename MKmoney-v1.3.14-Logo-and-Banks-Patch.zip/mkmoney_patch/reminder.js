/* MKmoney: resilient snapshot of upcoming bills for native 8:00pm alerts.
   Keeps all existing dashboard, bill, calendar and data structures untouched. */
(()=>{
 const bridge=window.MKBillReminder;
 if(!bridge)return;
 const iso=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
 const date=s=>{if(!s)return null; if(typeof s==='number'){let d=new Date(s);return isNaN(d)?null:d;} let v=String(s);if(/^\d{4}-\d{2}-\d{2}$/.test(v)){let [y,m,d]=v.split('-').map(Number);return new Date(y,m-1,d);}let d=new Date(v);return isNaN(d)?null:d};
 const days=(a,b)=>Math.round((Date.UTC(a.getFullYear(),a.getMonth(),a.getDate())-Date.UTC(b.getFullYear(),b.getMonth(),b.getDate()))/86400000);
 const addMonths=(d,m)=>{let x=new Date(d.getFullYear(),d.getMonth()+m,1);x.setDate(Math.min(d.getDate(),new Date(x.getFullYear(),x.getMonth()+1,0).getDate()));return x};
 const isDue=(bill,target)=>{
  let start=date(bill.due??bill.dueDate??bill.date??bill.nextDue??bill.startDate??bill.start);
  if(!start)return false;
  let end=date(bill.until??bill.endDate??bill.repeatUntil);if(end && days(target,end)>0)return false;
  let diff=days(target,start);if(diff<0)return false;
  let repeat=String(bill.interval??bill.repeat??bill.frequency??bill.recurrence??'').toLowerCase();
  if(!repeat || /once|none|one.time|never/.test(repeat))return diff===0;
  if(/fortnight|biweek|2.week|14.day/.test(repeat))return diff%14===0;
  if(/weekly|week|7.day/.test(repeat))return diff%7===0;
  if(/quarter|3.month/.test(repeat)){for(let n=0;n<240;n+=3){let d=addMonths(start,n);if(days(d,target)===0)return true;if(d>target)break;}return false;}
  if(/month/.test(repeat)){for(let n=0;n<240;n++){let d=addMonths(start,n);if(days(d,target)===0)return true;if(d>target)break;}return false;}
  if(/year|annual/.test(repeat)){for(let n=0;n<30;n++){let d=addMonths(start,n*12);if(days(d,target)===0)return true;if(d>target)break;}return false;}
  return diff===0;
 };
 const billLike=o=>o && typeof o==='object' && !Array.isArray(o) &&
  (o.due!==undefined||o.dueDate!==undefined||o.date!==undefined||o.nextDue!==undefined) &&
  (o.amount!==undefined||o.cost!==undefined||o.value!==undefined);
 const collect=(x,out,depth=0)=>{
  if(depth>8||!x||typeof x!=='object')return;
  if(Array.isArray(x)){for(const item of x)collect(item,out,depth+1);return;}
  if(billLike(x)){out.push(x);return;}
  for(const [k,v] of Object.entries(x))if(typeof v==='object' && v!==null && !/history|audit|backup/i.test(k))collect(v,out,depth+1);
 };
 const save=()=>{
  const found=[];
  for(let i=0;i<localStorage.length;i++){
   const k=localStorage.key(i);if(!k || /^mk_bill_reminder/i.test(k))continue;
   try{collect(JSON.parse(localStorage.getItem(k)),found);}catch(e){}
  }
  // Standard amount field interpreted in dollars; no inferred bank balance.
  const today=new Date(), schedule={};
  for(let offset=1;offset<=90;offset++){
   const day=new Date(today.getFullYear(),today.getMonth(),today.getDate()+offset);
   const due=found.filter(b=>b.paid!==true && b.deleted!==true && b.active!==false && isDue(b,day)).map(b=>({
     name:String(b.name??b.title??b.label??b.merchant??'Bill'),
     amount:Number(b.amount??b.cost??b.value) || 0,
     bank:String(b.bank??b.bankName??b.sourceBank??b.bankAccount??b.account??b.fromBank??b.paymentBank??'Unassigned')
   })).filter(b=>Number.isFinite(b.amount)&&b.amount>0);
   if(due.length)schedule[iso(day)]=due;
  }
  try{bridge.saveTomorrowBills(JSON.stringify(schedule));}catch(e){}
 };
 const oldSet=Storage.prototype.setItem;
 Storage.prototype.setItem=function(k,v){const r=oldSet.call(this,k,v);if(this===localStorage)setTimeout(save,200);return r};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',save);else save();
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)save()});
 setInterval(save,60000);
 window.MKmoneyReminder={sync:save, test:()=>bridge.testNotification(), requestPermission:()=>bridge.requestNotificationPermission()};
 // Visible testing control, not intrusive on normal dashboard.
 const addControl=()=>{
  const btn=document.createElement('button');btn.type='button';btn.textContent='Test 8pm bill reminder';btn.title='Test Android notification permission and reminders';
  btn.style.cssText='display:block;margin:12px auto;padding:8px 14px;border-radius:8px;font-size:13px;opacity:.88';
  btn.onclick=()=>{bridge.requestNotificationPermission();setTimeout(()=>bridge.testNotification(),1500)};
  const target=document.querySelector('#settings')||document.querySelector('[data-tab="settings"]');
  if(target)target.appendChild(btn);
 };
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',addControl);else addControl();
})();

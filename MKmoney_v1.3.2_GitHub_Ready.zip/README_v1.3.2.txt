MKmoney v1.3.2
- Date Range: Person 1 total minus Person 2 total, signed, includes recurring bills.
- Android CSV Save As: fixed Javascript bridge argument mismatch; named CSV export.
- App logo included as Android launcher icons.
- Same applicationId to support in-place upgrades.
- Do not uninstall old application before verifying data and backup.

package au.com.paycycle.planner;
import android.Manifest;import android.app.*;import android.os.*;import android.content.*;import android.webkit.*;import android.net.Uri;import android.graphics.Color;import android.view.*;import android.widget.*;import java.io.*;import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> chooser; String pendingExport;
 static final int FILE_CHOOSE=101, EXPORT_FILE=102;
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(11,18,33));getWindow().setNavigationBarColor(Color.rgb(11,18,33));
 web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(true);
 web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams params){if(chooser!=null)chooser.onReceiveValue(null);chooser=cb;Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("text/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(Intent.createChooser(i,"Import CSV"),FILE_CHOOSE);return true;}});
 web.addJavascriptInterface(new Object(){
 @JavascriptInterface public void saveCsv(String csv){try{writePrivate("records.csv",csv);runOnUiThread(()->web.evaluateJavascript("window.onNativeSaved(true)",null));}catch(Exception ex){runOnUiThread(()->web.evaluateJavascript("window.onNativeSaved(false)",null));}}
 @JavascriptInterface public void syncRecords(String json){try{writePrivate("records.json",json);ReminderReceiver.schedule(MainActivity.this);}catch(Exception ignored){}}
 @JavascriptInterface public void loadCsv(){try{File f=new File(getFilesDir(),"records.csv");if(f.exists()){String csv=readPrivate("records.csv");runOnUiThread(()->web.evaluateJavascript("window.onNativeLoaded("+org.json.JSONObject.quote(csv)+")",null));}}catch(Exception ignored){}}
 @JavascriptInterface public void exportCsv(String csv,String filename){runOnUiThread(()->{pendingExport=csv;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,(filename!=null && filename.endsWith(".csv"))?filename:"MKmoney_backup.csv");startActivityForResult(i,EXPORT_FILE);});}
 },"AndroidRecords");
 web.loadUrl("file:///android_asset/index.html");ReminderReceiver.schedule(this);
 if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1);
 }
 void writePrivate(String file,String value)throws Exception{try(FileOutputStream os=openFileOutput(file,MODE_PRIVATE)){os.write(value.getBytes(StandardCharsets.UTF_8));}}
 String readPrivate(String file)throws Exception{try(FileInputStream is=openFileInput(file)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=is.read(buf))!=-1)out.write(buf,0,n);return out.toString("UTF-8");}}
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==FILE_CHOOSE){if(chooser!=null){chooser.onReceiveValue(result==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null);chooser=null;}}else if(request==EXPORT_FILE){if(result==RESULT_OK&&data!=null&&pendingExport!=null){try(java.io.OutputStream os=getContentResolver().openOutputStream(data.getData())){os.write(pendingExport.getBytes(StandardCharsets.UTF_8));}catch(Exception e){Toast.makeText(this,"Export failed",Toast.LENGTH_LONG).show();}}pendingExport=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
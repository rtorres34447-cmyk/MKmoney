from pathlib import Path
import re,sys
root=Path(sys.argv[1]);p=root/'app/src/main/assets/index.html'
s=p.read_text(encoding='utf-8')
if 'window.__mk1333' in s:raise SystemExit('Settings relocation already applied')
js=Path(__file__).with_name('move_funding_1333.js').read_text(encoding='utf-8')
if not re.search('</body\s*>',s,re.I):raise SystemExit('Missing body end')
s=re.sub('</body\s*>',lambda m:'<script>\n'+js+'\n</script>\n'+m.group(0),s,count=1,flags=re.I)
p.write_text(s,encoding='utf-8');print('Added Settings relocation; CSV, logo and native Java untouched')

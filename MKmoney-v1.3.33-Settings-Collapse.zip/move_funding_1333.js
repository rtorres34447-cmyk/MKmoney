/* MKmoney v1.3.33: move current-week bank funding out of Dashboard and into Settings. */
(()=>{'use strict';if(window.__mk1333)return;window.__mk1333=true;
const isShown=e=>!!(e&&e.isConnected&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden');
const exactHeading=/^Current week\s*[·•:-]\s*Mon\s*[–-]\s*Sun/i;
let hidden=document.createElement('div');hidden.id='mk1333-park';hidden.style.display='none';
const text=e=>(e.textContent||'').replace(/\s+/g,' ').trim();
function findFunding(){let result=[];const m=document.getElementById('mk1330Funding');if(m)result.push(m);
 for(let h of document.querySelectorAll('h1,h2,h3,h4,h5,strong,b,div,span')){
  if(h.closest('#mk1333-park')||h.closest('#mk1333-settings-area'))continue;
  if(!exactHeading.test(text(h).slice(0,70)))continue;
  let parent=h;
  for(let i=0;i<5&&parent?.parentElement;i++,parent=parent.parentElement){
   let s=text(parent);if(/Remaining weeks before payday/i.test(s)&&/Archived completed weeks/i.test(s)){result.push(parent);break;}
  }
 }
 return [...new Set(result)].filter(x=>!result.some(y=>y!==x&&x.contains(y)));
}
function settingsContainer(){
 const choices=['#settings','#settingsTab','#tab-settings','#panel-settings','#settingsPanel','[data-page="settings"]','[data-tab="settings"]','.settings-page','.settings-panel'];
 for(let sel of choices){let el=document.querySelector(sel);if(el&&!el.matches('button,a,[role=tab]'))return el;}
 return null;
}
function settingsSelected(){
 let x=settingsContainer();if(x&&isShown(x))return true;
 let active=[...document.querySelectorAll('[aria-selected="true"],.active,[aria-current="page"]')].some(el=>/\bsettings\b/i.test(el.textContent||el.getAttribute('data-tab')||''));
 return active;
}
function settingsArea(){let c=settingsContainer();if(!c)return null;let a=c.querySelector('#mk1333-settings-area');if(!a){a=document.createElement('section');a.id='mk1333-settings-area';a.style.margin='18px 0';c.appendChild(a)}return a;}
function place(){if(!document.body)return;
 if(!hidden.isConnected)document.body.appendChild(hidden);
 let show=settingsSelected(),target=show?settingsArea():hidden;
 if(!target)target=hidden;
 let cards=findFunding();
 // Also find content we parked on earlier passes.
 for(let el of [...hidden.children,...document.querySelectorAll('#mk1333-settings-area > *')])if(el.id==='mk1330Funding'||/Remaining weeks before payday/i.test(text(el)))cards.push(el);
 for(let el of new Set(cards)){if(el===target||el.contains(target)||el.closest('#mk1333-park')&&target===hidden)continue;
   target.appendChild(el);
 }
}
let timer=0;function queue(){if(timer)return;timer=setTimeout(()=>{timer=0;place()},70)}
function start(){place();new MutationObserver(queue).observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','aria-selected','hidden']});document.addEventListener('click',queue,true);setInterval(queue,30000)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
package au.com.paycycle.planner;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    WebView web;
    String pendingExport;
    static final int EXPORT=9001, IMPORT=9002;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new AndroidBridge(),"AndroidRecords");
        web.addJavascriptInterface(new AlarmBridge(),"AndroidAlarm");
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},123);
    }
    void js(String code){runOnUiThread(()->web.evaluateJavascript(code,null));}
    class AlarmBridge{
        @JavascriptInterface public void sync(String state){AlarmScheduler.store(MainActivity.this,state);}
        @JavascriptInterface public void test(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},123);Toast.makeText(MainActivity.this,"Allow notifications, then test again",Toast.LENGTH_LONG).show();return;}AlarmScheduler.test(MainActivity.this);});}
        @JavascriptInterface public void permissions(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=31&&!AlarmScheduler.exactAllowed(MainActivity.this)){try{Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception e){Toast.makeText(MainActivity.this,"Enable Alarms & reminders in Android settings",Toast.LENGTH_LONG).show();}}else Toast.makeText(MainActivity.this,"Exact alarms are already allowed",Toast.LENGTH_SHORT).show();});}
        @JavascriptInterface public boolean exactAllowed(){return AlarmScheduler.exactAllowed(MainActivity.this);}
    }
    class AndroidBridge{
        @JavascriptInterface public void saveCsv(String text){try(FileOutputStream out=openFileOutput("mkmoney-auto-backup.csv",MODE_PRIVATE)){out.write(text.getBytes(StandardCharsets.UTF_8));js("window.onNativeSaved && window.onNativeSaved(true)");}catch(Exception e){js("window.onNativeSaved && window.onNativeSaved(false)");}}
        @JavascriptInterface public void loadCsv(){/* Never overwrite localStorage on startup. */}
        @JavascriptInterface public void importCsv(){runOnUiThread(()->{
            try {
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/comma-separated-values","text/plain","application/csv","application/vnd.ms-excel","application/octet-stream"});
                startActivityForResult(i,IMPORT);
            } catch(Exception e){js("window.onNativeImportError("+JSONObject.quote("Cannot open file picker: "+e.getMessage())+")");}
        });}
        @JavascriptInterface public void exportCsv(String csv,String filename){pendingExport=csv;runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/csv").putExtra(Intent.EXTRA_TITLE,filename);startActivityForResult(i,EXPORT);});}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==IMPORT){
            if(result!=RESULT_OK || data==null || data.getData()==null)return;
            try(InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream()){
                if(in==null)throw new IOException("Unable to read selected file");
                byte[] buf=new byte[8192];int n;int size=0;
                while((n=in.read(buf))!=-1){size+=n;if(size>10*1024*1024)throw new IOException("CSV exceeds 10 MB limit");out.write(buf,0,n);}
                String csv=out.toString(StandardCharsets.UTF_8.name());
                if(csv.startsWith("\uFEFF"))csv=csv.substring(1);
                js("window.onNativeImportCsv("+JSONObject.quote(csv)+")");
            }catch(Exception e){js("window.onNativeImportError("+JSONObject.quote("CSV import failed: "+e.getMessage())+")");}
            return;
        }
        if(request==EXPORT){
            if(result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingExport!=null){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new IOException("Cannot write selected file");
                    out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"CSV backup saved",Toast.LENGTH_SHORT).show();
                }catch(Exception e){Toast.makeText(this,"CSV export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            }
            pendingExport=null;
        }
    }
    @Override protected void onResume(){super.onResume();AlarmScheduler.schedule(this);}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}

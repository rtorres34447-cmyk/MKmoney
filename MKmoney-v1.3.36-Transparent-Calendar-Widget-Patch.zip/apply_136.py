import sys,re,shutil
from pathlib import Path
from xml.sax.saxutils import escape
root=Path(sys.argv[1]); app=root/'app/src/main'; manifest=app/'AndroidManifest.xml'; m=manifest.read_text()
pkg=re.search(r'package="([^"]+)"',m)
if not pkg:
    gradle=(root/'app/build.gradle').read_text(); pkg=re.search(r'namespace\s*(?:=\s*)?["\']([^"\']+)',gradle)
if not pkg: raise SystemExit('Cannot discover Android package')
pkg=pkg.group(1); src=app/'java'/Path(pkg.replace('.','/')); src.mkdir(parents=True,exist_ok=True)
res=app/'res'; (res/'layout').mkdir(parents=True,exist_ok=True);(res/'xml').mkdir(parents=True,exist_ok=True);(res/'drawable').mkdir(parents=True,exist_ok=True)
assets=app/'assets'; assets.mkdir(exist_ok=True); shutil.copyfile(Path(__file__).parent/'widget-preview.html',assets/'widget-preview.html')
(res/'layout/mk_calendar_widget.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/widget_root" android:orientation="vertical" android:background="@android:color/transparent" android:padding="8dp" android:layout_width="match_parent" android:layout_height="match_parent">
<TextView android:id="@+id/next_payment" android:layout_width="match_parent" android:layout_height="wrap_content" android:padding="9dp" android:textColor="#FFFFFFFF" android:textSize="15sp" android:background="@drawable/mk_widget_glass" android:text="MKmoney · Next upcoming payment"/>
<LinearLayout android:orientation="horizontal" android:layout_width="match_parent" android:layout_height="wrap_content" android:gravity="center_vertical">
<TextView android:id="@+id/prev_month" android:layout_width="40dp" android:layout_height="40dp" android:text="‹" android:gravity="center" android:textSize="25sp" android:textColor="#FFFFFFFF" />
<TextView android:id="@+id/month" android:layout_width="0dp" android:layout_weight="1" android:layout_height="40dp" android:gravity="center" android:textStyle="bold" android:textColor="#FFFFFFFF" android:textSize="17sp" />
<TextView android:id="@+id/next_month" android:layout_width="40dp" android:layout_height="40dp" android:text="›" android:gravity="center" android:textSize="25sp" android:textColor="#FFFFFFFF" />
</LinearLayout>
<LinearLayout android:id="@+id/weekdays" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal" />
<LinearLayout android:id="@+id/calendar_rows" android:layout_width="match_parent" android:layout_height="0dp" android:layout_weight="1" android:orientation="vertical" />
<TextView android:id="@+id/selected_breakdown" android:layout_width="match_parent" android:layout_height="wrap_content" android:minHeight="38dp" android:text="Tap a day for its breakdown" android:textSize="12sp" android:textColor="#FFFFFFFF" android:padding="8dp" android:background="@drawable/mk_widget_glass" />
</LinearLayout>''')
(res/'layout/mk_widget_row.xml').write_text('''<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/row" android:orientation="horizontal" android:layout_width="match_parent" android:layout_height="match_parent" />''')
(res/'layout/mk_widget_cell.xml').write_text('''<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/cell" android:orientation="vertical" android:layout_width="0dp" android:layout_weight="1" android:layout_height="match_parent" android:layout_margin="1dp" android:padding="2dp" android:background="@android:color/transparent"><TextView android:id="@+id/cell_day" android:layout_width="match_parent" android:layout_height="wrap_content" android:textSize="12sp" android:textColor="#FFFFFFFF" android:gravity="center"/><TextView android:id="@+id/cell_bills" android:layout_width="match_parent" android:layout_height="wrap_content" android:textSize="8sp" android:maxLines="3" android:ellipsize="end" android:textColor="#FF9FDBFF" /></LinearLayout>''')
(res/'drawable/mk_widget_glass.xml').write_text('''<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle"><solid android:color="#3B162B48"/><corners android:radius="12dp"/><stroke android:width="1dp" android:color="#55A0C9F5"/></shape>''')
(res/'drawable/mk_widget_selected.xml').write_text('''<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle"><solid android:color="#65A6CFFF"/><corners android:radius="8dp"/><stroke android:width="1dp" android:color="#BBA9DCFF"/></shape>''')
(res/'xml/mk_calendar_widget_info.xml').write_text('''<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="280dp" android:minHeight="330dp" android:targetCellWidth="4" android:targetCellHeight="5" android:initialLayout="@layout/mk_calendar_widget" android:resizeMode="horizontal|vertical" android:widgetCategory="home_screen" android:updatePeriodMillis="1800000" />''')
java=r'''package PACKAGE;
import android.app.*;import android.appwidget.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.view.View;import android.widget.RemoteViews;import java.time.*;import java.time.format.*;import java.util.*;import org.json.*;
public class MKCalendarWidget extends AppWidgetProvider {
 static final String PREF="mk_widget_state";static final String ACTION="PACKAGE.MK_WIDGET_SELECT";
 static PendingIntent pending(Context c,String cmd,String day,int id){Intent i=new Intent(c,MKCalendarWidget.class);i.setAction(ACTION);i.putExtra("cmd",cmd);i.putExtra("day",day);i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id);i.setData(Uri.parse("mkmoneywidget://"+id+"/"+cmd+"/"+day));return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(!ACTION.equals(i.getAction()))return;int id=i.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);if(id<0)return;android.content.SharedPreferences p=c.getSharedPreferences(PREF,0);String cmd=i.getStringExtra("cmd"),day=i.getStringExtra("day");if("select".equals(cmd))p.edit().putString("selected_"+id,day).apply();if("month".equals(cmd))p.edit().putString("month_"+id,day).apply();draw(c,AppWidgetManager.getInstance(c),id);}
 @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){for(int id:ids)draw(c,manager,id);}
 static String money(double x){return String.format(Locale.US,"$%,.2f",x);}
 static JSONArray payments(Context c){try{return new JSONArray(c.getSharedPreferences(PREF,0).getString("bill_snapshot","[]"));}catch(Exception e){return new JSONArray();}}
 static void draw(Context c,AppWidgetManager manager,int id){android.content.SharedPreferences p=c.getSharedPreferences(PREF,0);YearMonth ym;try{ym=YearMonth.parse(p.getString("month_"+id,YearMonth.now().toString()));}catch(Exception e){ym=YearMonth.now();}
 String selected=p.getString("selected_"+id,LocalDate.now().toString());JSONArray list=payments(c);RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.mk_calendar_widget);v.setTextViewText(R.id.month,ym.format(DateTimeFormatter.ofPattern("MMMM yyyy",Locale.ENGLISH)));v.setOnClickPendingIntent(R.id.prev_month,pending(c,"month",ym.minusMonths(1).toString(),id));v.setOnClickPendingIntent(R.id.next_month,pending(c,"month",ym.plusMonths(1).toString(),id));
 LocalDate today=LocalDate.now();String earliest=null;double due=0;String names="";for(int j=0;j<list.length();j++){JSONObject b=list.optJSONObject(j);if(b==null||b.optBoolean("paid",false))continue;String dt=b.optString("date","");if(dt.length()!=10)continue;if(earliest==null||dt.compareTo(earliest)<0){earliest=dt;due=0;names="";}if(dt.equals(earliest)){due+=b.optDouble("amount",0);names+=(names.isEmpty()?"":" · ")+b.optString("name","Bill");}}
 v.setTextViewText(R.id.next_payment,earliest==null?"MKmoney · Open app for upcoming payments":"NEXT · "+earliest+" · "+money(due)+"\n"+names);v.setOnClickPendingIntent(R.id.next_payment,pending(c,"select",earliest==null?today.toString():earliest,id));
 v.removeAllViews(R.id.weekdays);for(String label:new String[]{"M","T","W","T","F","S","S"}){RemoteViews d=new RemoteViews(c.getPackageName(),R.layout.mk_widget_cell);d.setTextViewText(R.id.cell_day,label);v.addView(R.id.weekdays,d);}v.removeAllViews(R.id.calendar_rows);
 LocalDate start=ym.atDay(1);int offset=start.getDayOfWeek().getValue()-1;for(int row=0;row<6;row++){RemoteViews r=new RemoteViews(c.getPackageName(),R.layout.mk_widget_row);for(int col=0;col<7;col++){LocalDate date=start.plusDays(row*7+col-offset);String iso=date.toString();RemoteViews cell=new RemoteViews(c.getPackageName(),R.layout.mk_widget_cell);cell.setTextViewText(R.id.cell_day,Integer.toString(date.getDayOfMonth()));cell.setTextColor(R.id.cell_day,date.getMonthValue()==ym.getMonthValue()?Color.WHITE:0x88FFFFFF);if(iso.equals(selected))cell.setInt(R.id.cell,"setBackgroundResource",R.drawable.mk_widget_selected);
 String lines="";for(int j=0;j<list.length();j++){JSONObject b=list.optJSONObject(j);if(b!=null&&iso.equals(b.optString("date"))){lines+=(lines.isEmpty()?"":"\n")+b.optString("name","Bill")+" "+money(b.optDouble("amount",0));}}cell.setTextViewText(R.id.cell_bills,lines);cell.setOnClickPendingIntent(R.id.cell,pending(c,"select",iso,id));r.addView(R.id.row,cell);}v.addView(R.id.calendar_rows,r);}
 double total=0;String details="";for(int j=0;j<list.length();j++){JSONObject b=list.optJSONObject(j);if(b!=null&&selected.equals(b.optString("date"))){total+=b.optDouble("amount",0);details+=(details.isEmpty()?"":"\n")+b.optString("name","Bill")+" · "+b.optString("who","House")+" · "+b.optString("bank", "Bank")+" · "+money(b.optDouble("amount",0))+(b.optBoolean("paid",false)?" ✓":"");}}
 v.setTextViewText(R.id.selected_breakdown,selected+" · "+(details.isEmpty()?"No synced payments for this date":details+"\nDaily total "+money(total)));manager.updateAppWidget(id,v);
 }
}
'''.replace('PACKAGE',pkg)
(src/'MKCalendarWidget.java').write_text(java)
if 'android.permission.INTERNET' not in m: pass
receiver='''<receiver android:name=".MKCalendarWidget" android:exported="true"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE"/></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/mk_calendar_widget_info"/></receiver>'''
if 'MKCalendarWidget' not in m:
    m=m.replace('</application>',receiver+'</application>');manifest.write_text(m)
gradle=root/'app/build.gradle';g=gradle.read_text();g,n=re.subn(r'(\bversionName\s*(?:=\s*)?)["\'][^"\']+["\']',lambda match:match.group(1)+'"1.3.36"',g,count=1)
if n!=1: raise SystemExit('versionName not found')
gradle.write_text(g)
print('Installed native transparent MKmoney calendar widget in',pkg)

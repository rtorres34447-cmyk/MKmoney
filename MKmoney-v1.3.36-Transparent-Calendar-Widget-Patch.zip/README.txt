MKmoney v1.3.36 widget patch. Add ZIP to repository root, replace .github/workflows/blank.yml with supplied YAML.
Uses v1.3.35 successful build chain.
Native widget: transparent calendar, selected date becomes translucent; previous/next month; daily breakdown panel.
IMPORTANT: Live bill synchronisation is NOT yet wired into existing MKmoney WebView storage. The native widget expects a JSON array in SharedPreferences 'mk_widget_state' key 'bill_snapshot', containing {date,name,amount,who,bank,paid}. Until a source sync is implemented, calendar dates have no bills and next payment is a placeholder. HTML preview uses demo data only.
This patch is untested as an APK: GitHub Actions must compile it.

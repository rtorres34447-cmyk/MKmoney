#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(sys.argv[1]);app=root/'app/src/main';java=app/'java/au/com/paycycle/planner'
provider=java/'FullMonthWidget.java';bridge=java/'MKNativeSyncBridge.java';html=app/'assets/index.html'
for p in (provider,bridge,html):
 if not p.exists():raise RuntimeError('Missing '+str(p))
s=provider.read_text()
needle='ArrayList<String> entries=payments(c,selected);StringBuilder content=new StringBuilder(selected+" Â· ");'
if needle not in s: needle='ArrayList<String> entries=payments(c,selected);StringBuilder content=new StringBuilder(selected+" · ");'
if needle not in s:raise RuntimeError('Widget source mismatch; refusing dangerous patch')
replacement = '''ArrayList<String> entries=payments(c,selected);
  String raw=c.getSharedPreferences(PREF,0).getString("snapshot","");
  String status="No snapshot received";
  if(!raw.isEmpty()){
   try{
    JSONObject snapshot=new JSONObject(raw);
    status="Snapshot: "+raw.length()+" chars / "+snapshot.length()+" storage keys";
   }catch(Exception ex){status="Snapshot is invalid JSON ("+raw.length()+" chars)";}
  }
  StringBuilder content=new StringBuilder(selected+" | "+status+" | Matched bills: "+entries.size());
  for(String e:entries){if(content.length()>1000)break;content.append("\\n").append(e);}
  /* MK_DIAG_1347 */
  '''
s=s.replace(needle,replacement,1)
start=s.find('/* MK_DIAG_1347 */');end=s.find('v.setTextViewText(R.id.mk_day_details',start)
if end<0:raise RuntimeError('Widget output anchor not found')
s=s[:start]+s[end:];provider.write_text(s)
b=bridge.read_text();old='.putString("snapshot",snapshot).apply();'
if old not in b:raise RuntimeError('SharedPreferences snapshot writer not found')
bridge.write_text(b.replace(old,'.putString("snapshot",snapshot).commit();',1))
if 'id="mkmoney-native-sync"' not in html.read_text():raise RuntimeError('JS bridge missing')
print('MKmoney 1.3.47 widget diagnostic installed')

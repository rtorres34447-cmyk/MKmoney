package com.mk.widgetlab;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.SharedPreferences;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import org.json.*;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle state){super.onCreate(state);web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.addJavascriptInterface(new Bridge(),"NativeBridge");web.setWebViewClient(new WebViewClient());setContentView(web);LabStore.log(this,"APP opened");web.loadUrl("file:///android_asset/index.html");}
 public class Bridge {
 @JavascriptInterface public String ping(){return "BRIDGE_OK";}
 @JavascriptInterface public String getState(){return LabStore.state(MainActivity.this).toString();}
 @JavascriptInterface public String putPayments(String json){try{JSONArray a=new JSONArray(json);if(a.length()>200)throw new Exception("Max 200");for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);if(!j.getString("date").matches("\\d{4}-\\d{2}-\\d{2}")||j.getString("name").length()>80||j.getInt("cents")<0)throw new Exception("Bad entry "+i);}SharedPreferences p=LabStore.prefs(MainActivity.this);p.edit().putString("payments",a.toString()).putInt("sync",p.getInt("sync",0)+1).putString("source","HTML->Java").commit();LabStore.log(MainActivity.this,"HTML -> JAVA -> PREFS -> WIDGET "+a.length()+" payments");LabWidget.refresh(MainActivity.this);return "OK "+a.length();}catch(Exception e){LabStore.log(MainActivity.this,"ERROR "+e);return "ERROR "+e.getMessage();}}
 @JavascriptInterface public void setDate(String d){if(!d.matches("\\d{4}-\\d{2}-\\d{2}"))return;LabStore.prefs(MainActivity.this).edit().putString("date",d).commit();LabWidget.refresh(MainActivity.this);}
 @JavascriptInterface public void clearLog(){LabStore.prefs(MainActivity.this).edit().remove("trace").commit();}
 @JavascriptInterface public int widgetCount(){return AppWidgetManager.getInstance(MainActivity.this).getAppWidgetIds(new ComponentName(MainActivity.this,LabWidget.class)).length;}
 }
}

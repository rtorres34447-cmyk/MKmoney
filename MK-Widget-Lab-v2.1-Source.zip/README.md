# MK Widget Lab v2.1 — Date Breakdown

Standalone diagnostic Android app built on the working v2.0 source and HTML→Java→SharedPreferences→RemoteViews widget pathway.

Changes: Seven dedicated breakdown lines (six payments + overflow notice), highlighted selected calendar date, update inside widget on date tap, corrected month navigation anchored to the first of each month (no skipping months on 31st).

## Test
Install v2.1 APK and add or update the home screen widget. Tap **Load sample October bills** in app, then on widget tap October 25: verify Test Payment $111 + Second Bill $23.50 = $134.50. Tap October 23: Electricity $750. Tap October 24: No payments scheduled. Advance to November and tap November 1: Strata $771. Add multiple payments on one day in app and Sync. Widget uses SharedPreferences; v2.1 maintains previous v2 data.

The widget shows up to six payment names on a day plus a count if more are present, to fit the finite display height. The complete payment set remains in Android storage.

Build uses Android SDK 35 and Gradle 8.9. These sources have been statically checked, not tested on device.

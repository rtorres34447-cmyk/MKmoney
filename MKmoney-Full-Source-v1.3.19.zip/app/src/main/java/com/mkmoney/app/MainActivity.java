package com.mkmoney.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import java.io.OutputStream;
public class MainActivity extends Activity {
  private WebView web;
  private static final int SAVE_CSV=41;
  private String pendingCsv="";
  @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());web.addJavascriptInterface(new Bridge(),"MKAndroid");web.loadUrl("file:///android_asset/index.html");}
  public class Bridge {
    @JavascriptInterface public void saveCsv(String content){pendingCsv=content;runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"MKmoney-export.csv");startActivityForResult(i,SAVE_CSV);});}
  }
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==SAVE_CSV&&c==RESULT_OK&&d!=null){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(pendingCsv.getBytes("UTF-8"));}catch(Exception e){} }}
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}

MKmoney v1.3.17 reversible paid-archive patch (NOT a standalone Android source project).

Requires complete existing MKmoney Android source with app/src/main/assets/index.html.

Changes:
- Uses stored custom Bank 1 and Bank 2 display names when found in settings/configuration.
- Outstanding bills for current Mon–Sun week can be marked Paid using a button or right swipe (85px threshold).
- Paid bill occurrences move to separate Paid bills archive, persist in localStorage, and can be Restored.
- Future recurring bill occurrences remain scheduled. The original bill data is NOT deleted.
- Paid archived occurrence is excluded from patch's week totals and future 8pm reminder snapshots.
- Existing native reminder/launcher patch retained.

Important: This is a patch-generated weekly dashboard, not a guaranteed modification of every legacy dashboard card. A full existing source ZIP is required to integrate its original main-board cards safely.

Upload this patch ZIP to GitHub repository root and put accompanying YAML at .github/workflows/blank.yml. Original full source must be committed or supplied as *source*.zip. The v1.3.10 dashboardToday function is no longer required. A standalone patch ZIP is not enough for an APK.

package au.com.paycycle.planner;
import android.content.*;
public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        if(!AlarmScheduler.ACTION.equals(intent.getAction()))return;
        AlarmScheduler.notifyBills(context);
        AlarmScheduler.schedule(context);
    }
}

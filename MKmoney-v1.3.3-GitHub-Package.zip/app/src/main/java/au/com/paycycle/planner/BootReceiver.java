package au.com.paycycle.planner;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){AlarmScheduler.schedule(context);}
}

package au.com.paycycle.planner;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    WebView web;
    String pendingExport;
    static final int EXPORT=9001, IMPORT=9002;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new AndroidBridge(),"AndroidRecords");
        web.addJavascriptInterface(new AlarmBridge(),"AndroidAlarm");
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},123);
    }
    void js(String code){runOnUiThread(()->web.evaluateJavascript(code,null));}
    class AlarmBridge{
        @JavascriptInterface public void sync(String state){AlarmScheduler.store(MainActivity.this,state);}
        @JavascriptInterface public void test(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},123);Toast.makeText(MainActivity.this,"Allow notifications, then test again",Toast.LENGTH_LONG).show();return;}AlarmScheduler.test(MainActivity.this);});}
        @JavascriptInterface public void permissions(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=31&&!AlarmScheduler.exactAllowed(MainActivity.this)){try{Intent i=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()));startActivity(i);}catch(Exception e){Toast.makeText(MainActivity.this,"Enable Alarms & reminders in Android settings",Toast.LENGTH_LONG).show();}}else Toast.makeText(MainActivity.this,"Exact alarms are already allowed",Toast.LENGTH_SHORT).show();});}
        @JavascriptInterface public boolean exactAllowed(){return AlarmScheduler.exactAllowed(MainActivity.this);}
    }
    class AndroidBridge{
        @JavascriptInterface public void saveCsv(String text){try(FileOutputStream out=openFileOutput("mkmoney-auto-backup.csv",MODE_PRIVATE)){out.write(text.getBytes(StandardCharsets.UTF_8));js("window.onNativeSaved && window.onNativeSaved(true)");}catch(Exception e){js("window.onNativeSaved && window.onNativeSaved(false)");}}
        @JavascriptInterface public void loadCsv(){/* Never overwrite localStorage on startup. */}
        @JavascriptInterface public void exportCsv(String csv,String filename){pendingExport=csv;runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("text/csv").putExtra(Intent.EXTRA_TITLE,filename);startActivityForResult(i,EXPORT);});}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==EXPORT&&result==RESULT_OK&&data!=null&&pendingExport!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(pendingExport.getBytes(StandardCharsets.UTF_8));Toast.makeText(this,"CSV backup saved",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"CSV export failed",Toast.LENGTH_LONG).show();}finally{pendingExport=null;}}}
    @Override protected void onResume(){super.onResume();AlarmScheduler.schedule(this);}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}

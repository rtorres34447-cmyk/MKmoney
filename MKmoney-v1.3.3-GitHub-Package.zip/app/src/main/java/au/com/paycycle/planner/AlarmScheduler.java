package au.com.paycycle.planner;

import android.app.*;
import android.content.*;
import android.os.Build;
import org.json.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

public final class AlarmScheduler {
    static final String PREF = "mkmoney_native_alarm";
    static final String CHANNEL="mkmoney_bills";
    static final String ACTION="au.com.paycycle.planner.DAILY_REMINDER";
    static final int REQUEST=419;
    static final DateTimeFormatter DATE=DateTimeFormatter.ISO_LOCAL_DATE;
    private AlarmScheduler(){}
    static void store(Context c,String data){c.getSharedPreferences(PREF,0).edit().putString("state",data).apply();schedule(c);}
    static JSONObject data(Context c){try{return new JSONObject(c.getSharedPreferences(PREF,0).getString("state","{}"));}catch(Exception e){return new JSONObject();}}
    static PendingIntent pending(Context c){Intent i=new Intent(c,ReminderReceiver.class).setAction(ACTION);return PendingIntent.getBroadcast(c,REQUEST,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static boolean exactAllowed(Context c){AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);return Build.VERSION.SDK_INT<31||a.canScheduleExactAlarms();}
    static void schedule(Context c){
        AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent p=pending(c);a.cancel(p);
        JSONObject s=data(c), opts=s.optJSONObject("alarm");
        if(opts==null||!opts.optBoolean("enabled",true))return;
        try {
            LocalTime t=LocalTime.parse(opts.optString("time","09:00"));
            ZonedDateTime now=ZonedDateTime.now();ZonedDateTime next=now.toLocalDate().atTime(t).atZone(ZoneId.systemDefault());
            if(!next.isAfter(now)) next=next.plusDays(1);
            long when=next.toInstant().toEpochMilli();
            if(exactAllowed(c))a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);
            else a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);
        } catch(Exception ignored) { }
    }
    static boolean occurs(JSONObject b,LocalDate d){
        try {
            LocalDate start=LocalDate.parse(b.getString("date"),DATE);
            if(d.isBefore(start))return false;
            String end=b.optString("endDate",""); if(!end.isEmpty()&&d.isAfter(LocalDate.parse(end)))return false;
            end=b.optString("endBefore",""); if(!end.isEmpty()&&!d.isBefore(LocalDate.parse(end)))return false;
            JSONArray excluded=b.optJSONArray("excludedDates");if(contains(excluded,d.toString()))return false;
            String repeat=b.optString("repeat","none");
            LocalDate cursor=start;
            for(int guard=0;guard<20000&&!cursor.isAfter(d);guard++){
                if(cursor.equals(d))return true;
                switch(repeat){
                    case "weekly": cursor=cursor.plusDays(7);break;
                    case "fortnightly": cursor=cursor.plusDays(14);break;
                    case "monthly": cursor=cursor.plusMonths(1);break;
                    case "quarterly": cursor=cursor.plusMonths(3);break;
                    case "yearly": cursor=cursor.plusMonths(12);break;
                    default:return false;
                }
            }
            return false;
        } catch(Exception ignored){return false;}
    }
    static boolean contains(JSONArray array,String value){if(array==null)return false;for(int i=0;i<array.length();i++)if(value.equals(array.optString(i)))return true;return false;}
    static void notifyBills(Context c){
        JSONObject state=data(c),alarm=state.optJSONObject("alarm");if(alarm==null||!alarm.optBoolean("enabled",true))return;
        LocalDate due=LocalDate.now().plusDays(Math.max(0,alarm.optInt("lead",1)));
        JSONArray bills=state.optJSONArray("bills");int count=0;double total=0;StringBuilder names=new StringBuilder();
        if(bills!=null)for(int i=0;i<bills.length();i++){
            JSONObject b=bills.optJSONObject(i);if(b==null||!occurs(b,due))continue;
            JSONObject override=b.optJSONObject("overrides");JSONObject o=override==null?null:override.optJSONObject(due.toString());
            if(o!=null&&o.optBoolean("paid",false))continue;
            if(contains(b.optJSONArray("paidDates"),due.toString()))continue;
            count++;total+=(o==null?b:o).optDouble("amount",b.optDouble("amount",0));
            if(names.length()<110){if(names.length()>0)names.append(", ");names.append((o==null?b:o).optString("name",b.optString("name","Bill")));}
        }
        if(count==0)return;
        android.app.NotificationManager manager=(android.app.NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)manager.createNotificationChannel(new NotificationChannel(CHANNEL,"Payment reminders",NotificationManager.IMPORTANCE_HIGH));
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
        Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent intent=PendingIntent.getActivity(c,123,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String body=String.format(java.util.Locale.forLanguageTag("en-AU"),"%d unpaid bill(s) due %s · $%,.2f",count,due,total);
        Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("MKmoney · Payment reminder")
            .setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body+"\n"+names)).setContentIntent(intent).setAutoCancel(true).build();
        manager.notify(510, n);
    }
    static void test(Context c){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Payment reminders",NotificationManager.IMPORTANCE_HIGH));
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)return;
        nm.notify(511,new Notification.Builder(c,CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("MKmoney test notification").setContentText("Native Android notifications are working.").setAutoCancel(true).build());
    }
}

# MKmoney v1.3.3 — Native Android reminders

Same package identifier (`au.com.paycycle.planner`) and WebView origin (`file:///android_asset/index.html`) as the uploaded v1.3.2 build, intended to retain its `paycycle-v2` localStorage data on an in-place update. **Back up/export CSV before installing. Do not uninstall the existing app.** An unsigned debug APK produced by GitHub Actions might have a different signing key than an installed APK. If so Android will block in-place updates; do not uninstall to work around this. Use the same signing certificate as the existing installed APK.

Install the project files at your GitHub repository root; Actions > Build MKmoney v1.3.3 APK > Run workflow. Download the debug APK from Artifacts.

Native AlarmManager schedules the next daily reminder, even when the app is closed. The receiver reads a snapshot of bills synced from JavaScript into SharedPreferences, calculates due dates and recurring occurrences, and posts a notification for unpaid bills. It reschedules the next day and on reboot, time change and package replacement. Settings has native test and exact-alarm permission controls. If exact alarms aren't authorised Android uses an inexact wake-up alarm, so the selected time is not guaranteed to the minute.

This package was reconstructed from a compiled APK rather than original Android Studio sources and **has not been compiled on this machine**. Validate GitHub Actions and test permissions, recurring dates, and update compatibility on your device. The app also stores a private CSV backup on each edit, and the WebView's existing localStorage and manual CSV export are retained. The private file is not a user-accessible SD-card export. Export a backup before updating.

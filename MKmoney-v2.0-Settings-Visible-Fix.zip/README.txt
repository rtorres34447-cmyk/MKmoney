Settings placement fix v22. Upload this ZIP to MKmoney repository root. Replaces previous Settings Diagnostics add-on; workflow requires this ZIP. The APK must be verified on device.

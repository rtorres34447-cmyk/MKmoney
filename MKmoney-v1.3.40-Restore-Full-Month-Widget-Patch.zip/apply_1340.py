#!/usr/bin/env python3
"""Restore the full-month widget when assembling MKmoney from v1.3.38 patches.
Stops the build rather than silently selecting the short calendar.
"""
import sys,re,xml.etree.ElementTree as ET
from pathlib import Path
root=Path(sys.argv[1]).resolve()
manifest=root/'app/src/main/AndroidManifest.xml'
ns='{http://schemas.android.com/apk/res/android}'
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
tree=ET.parse(manifest); app=tree.getroot().find('application')
if app is None: raise RuntimeError('Application missing')
entries=[]
for rc in app.findall('receiver'):
    metas=[m for m in rc.findall('meta-data') if m.get(ns+'name')=='android.appwidget.provider']
    if not metas: continue
    name=rc.get(ns+'name','')
    leaf=name.rsplit('.',1)[-1]
    java=list((root/'app/src/main').rglob(leaf+'.java'))
    kt=list((root/'app/src/main').rglob(leaf+'.kt'))
    src=(java+kt)
    content=src[0].read_text(errors='ignore') if src else ''
    xmlref=metas[0].get(ns+'resource','').split('/')[-1]
    info=list((root/'app/src/main/res').rglob(xmlref+'.xml')) if xmlref else []
    infocontent=info[0].read_text(errors='ignore') if info else ''
    # Identify the provider which actually builds a multiweek month; avoid
    # guessing merely from the receiver class name or manifest order.
    score=0
    for pattern,weight in [(r'\b42\b',8),(r'\b35\b',5),(r'\b6\s*\*\s*7\b',8),
                           (r'\bweekCount\b',5),(r'\bweeks\b',4),
                           (r'DAY_OF_WEEK',4),(r'Calendar\.getInstance',1),
                           (r'YearMonth',5),(r'full.?month',7),(r'GRID',2),
                           (r'nextMonth|prevMonth|monthOffset',2)]:
        if re.search(pattern,content,re.I): score+=weight
    if re.search('month',name,re.I):score+=3
    if re.search('calendar',name,re.I):score+=1
    entries.append((score,rc,name,src,infocontent,content,xmlref))
if not entries:raise RuntimeError('No registered Android calendar widget; abort')
entries.sort(key=lambda e:e[0],reverse=True)
print('Widget candidates (month implementation evidence):')
for e in entries:print('  score=%s name=%s source=%s provider=%s'%(e[0],e[2],e[3][:1],e[6]))
if len(entries)>1 and entries[0][0]==entries[1][0]:
    raise RuntimeError('Ambiguous full-month widget selection; refusing to delete either')
chosen=entries[0]
if len(entries)>1 and chosen[0]<5:
    raise RuntimeError('No clear full-month widget implementation found; refusing to ship short calendar')
for e in entries[1:]:app.remove(e[1])
tree.write(manifest,encoding='utf-8',xml_declaration=True)
# Ensure no widget picker duplicate. Check retained provider metadata still present.
assert len([m for r in app.findall('receiver') for m in r.findall('meta-data') if m.get(ns+'name')=='android.appwidget.provider'])==1
(root/'widget_140_diagnostic.txt').write_text('\n'.join(['Selected: '+chosen[2], 'Scoring: '+str(chosen[0]),'Removed: '+str([e[2] for e in entries[1:]]),'Source: '+str(chosen[3][:1])]))
print('Kept full-month widget provider; duplicate picker registrations removed')

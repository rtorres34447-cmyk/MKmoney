MKmoney v1.3.12 Bank Funding Reminder — combined delivery package

This bundle includes the updated patch ZIP AND the GitHub workflow in a single downloadable file.

To use with an existing GitHub Actions project, extract this package and upload:
  1) MKmoney-v1.3.12-Bank-Reminder-Patch.zip to your repository root
  2) .github/workflows/blank.yml to that exact repository path (replace old workflow)
The repository must also contain these existing source ZIPs:
  MKmoney-v1.3.8-Logo-Restored-GitHub-Source.zip
  MKmoney-v1.3.10-Today-Workweek-Update.zip

At 8 PM local phone time, the reminder includes the next day's Bank 1, Bank 2, and if needed Unassigned amounts.
Existing launcher logo resources are preserved and the build fails if no icon resource exists.
Exact timing depends on Android exact-alarm permission and system power management.
This package hasn't been built or run on your device; verify notifications and bank mapping.
NOTE: Simply uploading the combined outer ZIP without extracting it cannot install a workflow on GitHub.

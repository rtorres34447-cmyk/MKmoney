/* MKmoney paid occurrence archive: persistent, reversible, separate from scheduled bill data. */
(()=>{
 'use strict';
 const KEY='mkmoney.paid.occurrences.v1';
 const local=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return {}}};
 const save=x=>{localStorage.setItem(KEY,JSON.stringify(x));window.dispatchEvent(new Event('mkmoney-archive-changed'))};
 const hash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(36)};
 const identity=b=>String(b.id??b.billId??b.uuid??b.key??hash([b.name??b.title??b.merchant??'',b.amount??b.cost??b.value??'',b.due??b.dueDate??b.date??b.startDate??'',b.interval??b.repeat??b.frequency??'',b.bank??b.bankName??b.sourceBank??''].join('|')));
 const token=(b,day)=>identity(b)+'@'+day;
 window.MKmoneyPaidArchive={
  all:local,
  isArchived:(b,day)=>!!local()[token(b,day)],
  archive:(b,day)=>{const state=local(),id=token(b,day);state[id]={key:id,date:day,name:String(b.name??b.title??b.merchant??'Bill'),amount:Number(b.amount??b.cost??b.value??0),bank:String(b.bank??b.bankName??b.sourceBank??b.bankAccount??b.account??''),archivedAt:new Date().toISOString()};save(state)},
  restore:id=>{const state=local();delete state[id];save(state)},
  token
 };
})();

package com.mk.widgetlab;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;
public final class LabStore {
 static SharedPreferences prefs(Context c){ return c.getSharedPreferences("bridge_state",Context.MODE_PRIVATE); }
 static String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
 static String shift(String day,int days){try{SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setLenient(false);Calendar c=Calendar.getInstance();c.setTime(f.parse(day));c.add(Calendar.DAY_OF_MONTH,days);return f.format(c.getTime());}catch(Exception e){return today();}}
 static String date(Context c){return prefs(c).getString("date",today());}
 static void log(Context c,String event){SharedPreferences p=prefs(c);String old=p.getString("trace","");String t=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date());String newer=t+"  "+event+"\n"+old;if(newer.length()>6500)newer=newer.substring(0,6500);p.edit().putString("trace",newer).apply();}
 static JSONObject state(Context c){SharedPreferences p=prefs(c);JSONObject j=new JSONObject();try{j.put("date",date(c));j.put("bill",p.getString("bill","(no payment synced)"));j.put("amount",p.getString("amount",""));j.put("syncCount",p.getInt("sync",0));j.put("widgetTaps",p.getInt("taps",0));j.put("lastSource",p.getString("source","none"));j.put("trace",p.getString("trace",""));}catch(Exception ignored){}return j;}
}

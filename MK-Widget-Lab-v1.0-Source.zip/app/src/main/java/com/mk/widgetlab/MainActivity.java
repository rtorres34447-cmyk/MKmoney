package com.mk.widgetlab;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import org.json.JSONObject;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle state){super.onCreate(state);web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setAllowFileAccess(true);web.addJavascriptInterface(new Bridge(),"NativeBridge");web.setWebViewClient(new WebViewClient());setContentView(web);LabStore.log(this,"APP started / WebView loaded");web.loadUrl("file:///android_asset/index.html");}
 public class Bridge {
  @JavascriptInterface public String ping(){LabStore.log(MainActivity.this,"JS -> Java ping OK");return "BRIDGE_OK";}
  @JavascriptInterface public String getState(){return LabStore.state(MainActivity.this).toString();}
  @JavascriptInterface public void sendBill(String date,String name,String amount){try{if(!date.matches("\\d{4}-\\d{2}-\\d{2}"))throw new Exception("Bad date");SharedPreferences p=LabStore.prefs(MainActivity.this);p.edit().putString("date",date).putString("bill",name).putString("amount",amount).putString("source","HTML->Java").putInt("sync",p.getInt("sync",0)+1).commit();LabStore.log(MainActivity.this,"HTML -> JAVA -> PREFS: "+name+" "+amount+" on "+date);LabWidget.refresh(MainActivity.this);LabStore.log(MainActivity.this,"JAVA -> WIDGET refresh called");}catch(Exception e){LabStore.log(MainActivity.this,"ERROR sendBill: "+e);}}
  @JavascriptInterface public void nativeOnly(){SharedPreferences p=LabStore.prefs(MainActivity.this);p.edit().putString("bill","Native-only test").putString("amount","$1.00").putString("date",LabStore.today()).putString("source","Java native").putInt("sync",p.getInt("sync",0)+1).commit();LabStore.log(MainActivity.this,"JAVA -> PREFS -> WIDGET native-only test");LabWidget.refresh(MainActivity.this);}
  @JavascriptInterface public int widgetCount(){return AppWidgetManager.getInstance(MainActivity.this).getAppWidgetIds(new ComponentName(MainActivity.this,LabWidget.class)).length;}
  @JavascriptInterface public void clearLog(){LabStore.prefs(MainActivity.this).edit().remove("trace").commit();LabStore.log(MainActivity.this,"Log cleared");}
 }
}

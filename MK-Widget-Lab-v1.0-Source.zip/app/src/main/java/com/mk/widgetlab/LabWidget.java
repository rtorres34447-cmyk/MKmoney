package com.mk.widgetlab;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;
public class LabWidget extends AppWidgetProvider {
 public static final String ACTION="com.mk.widgetlab.ACTION_WIDGET";
 static PendingIntent action(Context c,String op,int id){Intent i=new Intent(c,LabWidget.class).setAction(ACTION);i.putExtra("op",op);return PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 public static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);ComponentName n=new ComponentName(c,LabWidget.class);int[] ids=m.getAppWidgetIds(n);for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);SharedPreferences p=LabStore.prefs(c);v.setTextViewText(R.id.date,"Selected: "+LabStore.date(c));v.setTextViewText(R.id.bill,p.getString("bill","(no payment synced)")+"  "+p.getString("amount",""));v.setTextViewText(R.id.status,"Sync "+p.getInt("sync",0)+"  •  taps "+p.getInt("taps",0)+"  •  "+p.getString("source","none"));v.setOnClickPendingIntent(R.id.today,action(c,"today",id*10+1));v.setOnClickPendingIntent(R.id.next,action(c,"next",id*10+2));v.setOnClickPendingIntent(R.id.sync,action(c,"sync",id*10+3));Intent open=new Intent(c,MainActivity.class);open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);v.setOnClickPendingIntent(R.id.title,PendingIntent.getActivity(c,id+90000,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));m.updateAppWidget(id,v);}}
 @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){LabStore.log(c,"WIDGET onUpdate ids="+ids.length);refresh(c);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(!ACTION.equals(i.getAction()))return;String op=i.getStringExtra("op");if(op==null)return;SharedPreferences p=LabStore.prefs(c);SharedPreferences.Editor e=p.edit();e.putInt("taps",p.getInt("taps",0)+1).putString("source","widget:"+op);switch(op){case "today":e.putString("date",LabStore.today());break;case "next":e.putString("date",LabStore.shift(LabStore.date(c),1));break;case "sync":e.putInt("sync",p.getInt("sync",0)+1);break;}e.commit();LabStore.log(c,"WIDGET button "+op+" => date "+LabStore.date(c));refresh(c);}
}

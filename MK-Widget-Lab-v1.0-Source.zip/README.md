# MK Widget Lab v1.0
Separate Android app for diagnosing MKmoney WebView/widget data flow. Does not modify MKmoney.

## Build in GitHub
1. Create an empty public or private GitHub repository, e.g. `MKWidgetLab`.
2. Extract this source ZIP and upload **its contents** to repository root (keep `app/`, `build.gradle`, `settings.gradle`).
3. Upload separate `blank.yml` to `.github/workflows/blank.yml` (create these folders if needed).
4. GitHub → Actions → Build MK Widget Lab APK → Run workflow. Download artifact `MK-Widget-Lab-v1.0-debug-apk`; install APK.

## Tests
1. Add MK Widget Lab widget to phone home screen.
2. Open app, observe `BRIDGE_OK` and Widgets installed >= 1.
3. Tap `Send HTML sample to widget`: sample date, bill, amount should appear.
4. Tap `Native-only test`: widget should show `Native-only test $1.00`.
5. Tap Today, +1 day, Sync on widget, return to app → `Read current state`: taps, date and sync counts should increase.
6. Force close app, reopen, and inspect retained counters (storage persistence).
7. Screenshot state/trace, copy details into ChatGPT for specific diagnosis.

### How to interpret
- `Bridge failed`: JS ↔ Java injection issue.
- `BRIDGE_OK`, but sample missing and native works: sendBill/validation path.
- `Widgets installed: 0`: widget has not been added.
- Counts update in app but not widget: RemoteViews/widget-provider update issue.
- Widget buttons don't increment `widgetTaps`: widget click PendingIntent/receiver issue.

Package name `com.mk.widgetlab`; separate from MKmoney. Offline, no internet or accounts.

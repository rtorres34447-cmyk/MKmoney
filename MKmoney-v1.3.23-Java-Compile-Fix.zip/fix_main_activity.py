#!/usr/bin/env python3
"""Move v1.3.22 Android WebChromeClient file chooser into onCreate()."""
from pathlib import Path
import re, sys, textwrap

root=Path(sys.argv[1])
source=root/'app/src/main/java/com/mkmoney/app/MainActivity.java'
if not source.is_file():
    raise SystemExit(f"Missing MainActivity: {source}")
s=source.read_text(encoding="utf-8")

# Remove the malformed, top-level WebChromeClient statement inserted by v1.3.22.
pattern=r'(?ms)^[ \t]*web\.setWebChromeClient\(new android\.webkit\.WebChromeClient\(\) \{.*?^[ \t]*\}\);[ \t]*\n'
matches=list(re.finditer(pattern,s))
if len(matches)!=1:
    raise SystemExit(f"Expected one v1.3.22 WebChromeClient block; found {len(matches)}. Refusing unsafe edit.")
block=matches[0].group(0)
s=s[:matches[0].start()]+s[matches[0].end():]

# Find method body, not class body. Match brackets while ignoring Java comments and strings.
match=re.search(r'\b(?:void\s+)?onCreate\s*\([^)]*\)\s*\{',s)
if not match:
    raise SystemExit("onCreate method not found.")
start=match.end()-1

def close_brace(code, pos):
    depth=0; state='normal'; i=pos
    while i<len(code):
        c=code[i]; nxt=code[i+1] if i+1<len(code) else ''
        if state=='normal':
            if c=='/' and nxt=='/': state='line'; i+=2; continue
            if c=='/' and nxt=='*': state='block'; i+=2; continue
            if c=='"': state='string'
            elif c=="'": state='char'
            elif c=='{': depth+=1
            elif c=='}':
                depth-=1
                if depth==0:return i
        elif state=='line':
            if c=='\n': state='normal'
        elif state=='block':
            if c=='*' and nxt=='/':state='normal';i+=2;continue
        elif state in ('string','char'):
            if c=='\\':i+=2;continue
            if c==('"' if state=='string' else "'"):state='normal'
        i+=1
    raise SystemExit("Unmatched brace while reading onCreate.")

end=close_brace(s,start)
body=s[start+1:end]
if not re.search(r'\b(?:WebView|android\.webkit\.WebView)\s+web\b', body) and not re.search(r'\bweb\s*=',body):
    raise SystemExit("Cannot confirm WebView variable 'web' inside onCreate.")
if 'setWebChromeClient(' in body:
    raise SystemExit("onCreate already contains a WebChromeClient; refusing duplicate.")

# Move the SAME chooser code into the method where 'web' exists, preserving callbacks.
fixed='\n' + textwrap.indent(textwrap.dedent(block).strip()+'\n','        ')
s=s[:end]+fixed+s[end:]
source.write_text(s,encoding='utf-8')
assert s.count('web.setWebChromeClient(new android.webkit.WebChromeClient()')==1
print("Moved Android CSV chooser WebChromeClient into onCreate; kept existing native logic.")
